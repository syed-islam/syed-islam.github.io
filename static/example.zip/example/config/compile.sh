#!/bin/sh

# The compilation script.
#
# This script is called from ORBS to actually compile (build) the system.
#
# The script must return a generated signature if compilation was
# successful and must return "FAIL" if compilation was not
# successful. The signature should be, for example, an md5 hash over
# the generated binary.

cd $1 

# cleanup from previous run (just to make sure)
rm -f reader checker.class

# The actual compilation.  This can be replaced by any mechanism to
# build the system, e.g. by invoking make.

gcc $CFLAGS -o reader reader.c 2> compile.log
javac checker.java 2>> compile.log

# check successful compilation and create signature
if [ -f reader -a -f checker.class ]; then

    # The signature must be created from anything that actually
    # influences the execution which is affected by the slicing
    # operation. Usually it is any executed part, binaries and
    # scripts.
    echo `md5sum reader` `md5sum checker.class` `md5sum glue.py`
else
    # In case compilation fails, "FAIL" must be returned.
    echo FAIL
fi