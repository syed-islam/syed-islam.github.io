#!/bin/sh

# The execution script.
#
# This script is called from ORBS to actually execute the system.
#
# This script will have to run the system with any input that belong
# to the criterion.  It also has to generate the trajectory which is
# usually just a print of the value of the criterion. Therefore it
# usually has to just filter the output with respect to a given marker
# as passed in parameter $1.

cd $1 

rm -rf test1 test2

# The actual execution. Capture the output and any error message.
LC_ALL="en_US" python glue.py 1 00 > test1 2> execute.log
time LC_ALL="en_US" python glue.py 10 00 > test2 2>> execute.log

# Usually, the execution will be much more complicated as it has to
# deal with timeouts and crashes.




# save a copy of the execution output
if [ ! -d "../OrbsExecutionOutputs" ]; then
	mkdir "../OrbsExecutionOutputs"
fi	
cat  test1 test2 | grep $2 > "../OrbsExecutionOutputs/execute.out.${3}"
cat  test1 test2 | grep $2  >> "../OrbsExecutionOutputs/execute.out.${3}"




# Extract projected trajectory from the captured output.
if [ "$4" = "GA" ] 
then
	cat test1 test2 | grep $2
else
	cat test1 test2 | grep $2 | md5sum
fi



# cleanup
rm -rf test1 test2

# all done.
