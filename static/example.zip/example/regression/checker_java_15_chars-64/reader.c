

#include <locale.h>

int main(int argc, char **argv) {
  setlocale(LC_ALL, "");
  struct lconv *cur_locale = localeconv();





  {
    printf("%s\n", cur_locale->currency_symbol);
  }

}
