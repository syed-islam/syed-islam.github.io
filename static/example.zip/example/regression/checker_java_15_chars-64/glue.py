import commands
import sys

use_locale = True

decimal = ","

if use_locale:
  currency = commands.getoutput('./reader 0')


cmd = ('java checker ' + currency
       + sys.argv[1] + decimal + sys.argv[2])
print commands.getoutput(cmd)
