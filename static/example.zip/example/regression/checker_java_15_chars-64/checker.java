class checker {
  public static void main(String[] args) {

    int chars = 0;
    for (int i = 0; i < args[0].length(); ++i) {
      if (args[0].charAt(i) == '.') {

      } else if ((args[0].charAt(i) >= '0') 
                 && (args[0].charAt(i) <= '9')) {
        ++chars;
      }
    }


    System.out.println("ORBS: " + chars);
  }

