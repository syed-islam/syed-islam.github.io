cd $1 #Move to system directory
rm -f *.class # Remove existing output
javac SortUniqUtility.java > /dev/null;
if [ -f SortUniqUtility.class ]; then #check build
    echo `md5sum SortUniqUtility.class`
else
    echo FAIL
fi
