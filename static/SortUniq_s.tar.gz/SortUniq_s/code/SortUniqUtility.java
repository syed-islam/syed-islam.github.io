import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class SortUniqUtility {
	static ArrayList<String> list = new ArrayList<String>();
	
	public static void main (String[] args) throws Exception{
		readFile(args[0]);
		if (args[1].equals("-s"))
			sort();
		if (args[1].equals("-u"))
			unique();
		writeList();
	}
	
	private static void readFile(String args) throws Exception{
		FileReader fr = new FileReader(args);
		BufferedReader br = new BufferedReader(fr);
		String line = "";
		while((line = br.readLine()) != null){
			list.add(line);
		}
		br.close();
		fr.close();
	}
	
	private static void sort(){
		Collections.sort(list);
	}
	
	private static void unique(){
		Set<String> hs = new HashSet<>();
		hs.addAll(list);
		list.clear();
		list.addAll(hs);
	}
	
	private static void writeList(){
		for (String s: list)
			System.out.println("ORBS:"+s);
	}
}

