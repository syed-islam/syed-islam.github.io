#!/bin/sh
rm -rf $1 #Remove existing setup
cp -r code $1 #Setup of the program
cd $1 #Move to the setup
cat - > input.txt <<EOF
1
2
3
4
5
6
7
8
9
10
EOF
for i in {1..15}; do cat input.txt input.txt > tmp.txt && mv tmp.txt input.txt; done  
