#!bin/bash
rm -rf run.log time.log work/ logs/ orig
