#!/bin/sh
ElapsedTimeLimit=1s
cd $1 # move to directory 
rm -rf orbs.output # remoe previous output
time timeout -s KILL $ElapsedTimeLimit java SortUniqUtility input.txt -u > output.orbs 2>&1 #execute
rc=$? #capture return code
if [ -f output.orbs ]; then
	if [ "$4" = "GA" ] 
	then
		grep "$2" output.orbs
	else
		grep "$2" output.orbs | md5sum #capture hash of return
	fi    	
else
    echo FAIL
fi

rm -rf output.orbs # clear output file

exit $rc # return
