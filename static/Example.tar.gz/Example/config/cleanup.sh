rm -rf compile.log execute.log logs work time.log orig 
