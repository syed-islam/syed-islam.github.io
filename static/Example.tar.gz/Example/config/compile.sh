cd $1 #Move to system directory
rm -f reader checker.class # Remove existing output
gcc $CFLAGS -o reader reader.c 2> compile.log #build
javac checker.java 2>> compile.log #Build
if [ -f reader -a -f checker.class ]; then #check build
    echo `md5sum reader` `md5sum checker.class` `md5sum glue.py`
else
    echo FAIL
fi
