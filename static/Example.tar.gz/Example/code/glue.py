import commands
import sys
# Glue reader and checker together.
use_locale = True
currency = "?"
decimal = ","
# Glue reader and checker together.
if use_locale:
  currency = commands.getoutput('./reader 0')
  decimal = commands.getoutput('./reader 1')
# Glue reader and checker together.
cmd = ('java checker ' + currency
       + sys.argv[1] + decimal + sys.argv[2])
print commands.getoutput(cmd)