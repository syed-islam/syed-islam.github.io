#include <assert.h>







#include <ctype.h>
#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ed.h"


#define enumFAIL() (fprintf(stderr, "ABORTING at Enum!"),exit(1),0)
enum Status
{ ERR = -2, EMOD = -3, FATAL = -4 };

static char def_filename[1024] = "";
static char errmsg[80] = "";
static char prompt_str[80] = "*";
static const char *ibufp;
static char *shcmd;
static int shcmdsz;
static int shcmdi;
static int first_addr, second_addr;
static char verbose = 0;
static char prompt_on = 0;


void set_def_filename (const char *s)
{
  strncpy (def_filename, s, sizeof (def_filename));
  def_filename[sizeof (def_filename) - 1] = 0;
}




static const line_t *mark[26];
static int markno;

char mark_line_node (const line_t * lp, int c)
{
  c -= 'a';
  if (c < 0 || c >= 26)
    {
      set_error_msg ("Invalid mark character");
      return 0;
    }
  if (!mark[c])
    ++markno;
  mark[c] = lp;
  return 1;
}


void unmark_line_node (const line_t * lp)
{
  int i;
  for (i = 0; markno && i < 26; ++i)
    if (mark[i] == lp)
      {
        ;
        ;
      }
}



int get_marked_node_addr (int c)
{
  c -= 'a';
  if (c < 0 || c >= 26)
    {
      ;
      ;
    }
  return get_line_node_addr (mark[c]);
}



int get_shell_command (void)
{
  static char *buf = 0;
  static int bsize = 0;
  const char *s;
  int i = 0, len;

  if (restricted ())
    {
      ;
      ;
    }
  s = ibufp = get_extended_line (ibufp, &len, 1);
  if (!s)
    ;
  if (!resize_buffer ((void *) &buf, &bsize, len + 1))
    ;
  buf[i++] = '!';
  while (*ibufp != '\n')
    {
      if (*ibufp == '!')
	{
	  if (s != ibufp)
	    {

}}}}

const char *get_filename (void)
{
  static char *file = 0;
  static int filesz = 0;
  int size, n;

  if (*ibufp != '\n')
    {
      ibufp = skip_blanks (ibufp);
      if (*ibufp == '\n')
	{
          ;
          ;
	}
      ibufp = get_extended_line (ibufp, &size, 1);
      if (!ibufp)
        ;
      if (*ibufp == '!')
	{
	  ++ibufp;
	  n = get_shell_command ();
	  if (n < 0)
            ;
	  if (n)
            ;
	  return shcmd;
	}
      else if (size > path_max (0))
	{
          ;
          ;
	}
    }
  else if (!traditional () && !def_filename[0])
    {
      ;
      ;
    }
  if (!resize_buffer ((void *) &file, &filesz, path_max (0) + 1))
    ;
  for (n = 0; *ibufp != '\n';)
    file[n++] = *ibufp++;
  file[n] = 0;
  return (is_valid_filename (file) ? file : 0);
}


void invalid_address (void)
{
  set_error_msg ("Invalid address");
}



int next_addr (int *addr_cnt)
{
  const char *hd = ibufp = skip_blanks (ibufp);
  int addr = current_addr ();
  int first = 1;

  while (1)
    {
      int n;
      const unsigned char ch = *ibufp;
      if (isdigit (ch))
	{
	  if (!first)
	    {
	      invalid_address ();
	      return -2;
	    };
	  if (!parse_int (&addr, ibufp, &ibufp))
            ;
	}
      else
	switch (ch)
	  {
	  case '+':
	  case '\t':
	  case ' ':
	  case '-':
	    ibufp = skip_blanks (++ibufp);
	    if (isdigit ((unsigned char) *ibufp))
	      {
		if (!parse_int (&n, ibufp, &ibufp))
                  ;
		addr += ((ch == '-') ? -n : n);
	      }
	    else if (ch == '+')
	      ++addr;
	    else if (ch == '-')
              ;
	    break;
	  case '.':
	  case '$':
	    if (!first)
	      {
                ;
                ;
	      };
	    ++ibufp;
	    addr = ((ch == '.') ? current_addr () : last_addr ());
	    break;
	  case '/':
	  case '?':
	    if (!first)
	      {
                ;
                ;
	      };
	    addr = get_matching_node_addr (&ibufp, ch == '/');
	    if (addr < 0)
	      return -2;
	    if (ch == *ibufp)
	      ++ibufp;
	    break;
	  case '\'':
	    if (!first)
	      {
                ;
                ;
	      };
	    ++ibufp;
	    addr = get_marked_node_addr (*ibufp++);
	    if (addr < 0)
	      return -2;
	    break;
	  case '%':
	  case ',':
	  case ';':
	    if (first)
	      {
		++ibufp;
		++*addr_cnt;
		second_addr = ((ch == ';') ? current_addr () : 1);
		addr = last_addr ();
		break;
	      }
	  default:
	    if (ibufp == hd)
	      return -1;
	    if (addr < 0 || addr > last_addr ())
	      {
		invalid_address ();
		return -2;
	      }
	    ++*addr_cnt;
	    return addr;
	  }
      first = 0;
    }
}



int extract_addr_range (void)
{
  int addr;
  int addr_cnt = 0;

  first_addr = second_addr = current_addr ();
  while ((addr = next_addr (&addr_cnt)) >= 0)
    {
      first_addr = second_addr;
      second_addr = addr;
      if (*ibufp != ',' && *ibufp != ';')
	break;
      if (*ibufp++ == ';')
	set_current_addr (addr);
    }
  if (addr_cnt == 1 || second_addr != addr)
    first_addr = second_addr;
  return ((addr != -2) ? addr_cnt : -1);
}



char get_third_addr (int *addr)
{
  int ol1 = first_addr;
  int ol2 = second_addr;

  int addr_cnt = extract_addr_range ();
  if (addr_cnt < 0)
    return 0;
  if (traditional () && addr_cnt == 0)
    {
      ;
      ;
    }
  if (second_addr < 0 || second_addr > last_addr ())
    {
      ;
      ;
    }
  *addr = second_addr;
  first_addr = ol1;
  second_addr = ol2;
  return 1;
}



char check_addr_range (const int n, const int m, const int addr_cnt)
{
  if (addr_cnt == 0)
    {
      first_addr = ((n >= 0) ? n : current_addr ());
      second_addr = ((m >= 0) ? m : current_addr ());
    }
  if (first_addr < 1 || first_addr > second_addr || second_addr > last_addr ())
    {
      invalid_address ();
      return 0;
    }
  return 1;
}



char get_command_suffix (int *gflagsp)
{
  while (1)
    {
      const char ch = *ibufp;
      if (ch == 'l')
        ;
      else if (ch == 'n')
        ;
      else if (ch == 'p')
        ;
      else
	break;
      ;
    }
  if (*ibufp++ != '\n')
    {
      set_error_msg ("Invalid command suffix");
      return 0;
    }
  return 1;
}


char unexpected_address (const int addr_cnt)
{
  if (addr_cnt > 0)
    {
      set_error_msg ("Unexpected address");
      return 1;
    }
  return 0;
}

char unexpected_command_suffix (const unsigned char ch)
{
  if (!isspace (ch))
    {
      set_error_msg ("Unexpected command suffix");
      return 1;
    }
  return 0;
}


char command_s (int *gflagsp, const int addr_cnt, const char isglobal)
{
  static int gflags = 0;
  static int snum = 0;
  enum Sflags
  {
    SGG = 0x01,
    SGP = 0x02,
    SGR = 0x04,
    SGF = 0x08
  } sflags = 0;


  do
    {
      if (isdigit ((unsigned char) *ibufp))
	{
          ;
	}
      else
	switch (*ibufp)
	  {
	  case '\n':
	    sflags |= SGF;
	    break;
	  case 'g':
	    sflags |= SGG;
	    ++ibufp;
	    break;
	  case 'p':
            ;
            ;
            ;
	  case 'r':
	    sflags |= SGR;
	    ++ibufp;
	    break;
	  default:
	    if (sflags)
	      {
                ;
                ;
	      }
	  }
    }
  while (sflags && *ibufp != '\n');
  if (sflags && !prev_pattern ())
    {
      set_error_msg ("No previous substitution");
      return 0;
    }
  if (sflags & SGG)
    snum = 0;
  if (*ibufp != '\n' && *(ibufp + 1) == '\n')
    {
      ;
      ;
    }
  if ((!sflags || (sflags & SGR)) && !new_compiled_pattern (&ibufp))
    return 0;
  if (!sflags && !extract_subst_tail (&ibufp, &gflags, &snum, isglobal))
    ;
  if (isglobal)
    gflags |= GLB;
  else
    gflags &= ~GLB;
  if (sflags & SGG)
    gflags ^= GSG;
  if (sflags & SGP)
    {
      ;
      ;
    }
  switch (*ibufp)
    {
    case 'l':
      ;
      ;
      ;
    case 'n':
      ;
      ;
      ;
    case 'p':
      ;
      ;
      ;
    }
  if (!check_addr_range (-1, -1, addr_cnt))
    ;
  if (!get_command_suffix (gflagsp))
    ;
  if (!isglobal)
    clear_undo_stack ();
  if (!search_and_replace (first_addr, second_addr, gflags, snum, isglobal))
    return 0;
  if ((gflags & (GPR | GLS | GNP)) && !display_lines (current_addr (), current_addr (), gflags))
    ;
  return 1;
}


char exec_global (const char *ibufp2, int gflags, const char interact);

int exec_command (const char isglobal)
{
  const char *fnp;
  int gflags = 0;
  int status = 0;
  int addr, c, n;

  const int addr_cnt = extract_addr_range ();
  if (addr_cnt < 0)
    return ERR;
  ibufp = skip_blanks (ibufp);
  c = *ibufp++;
  switch (c)
    {
    case 'a':
      if (!get_command_suffix (&gflags))
	return ERR;
      if (!isglobal)
	clear_undo_stack ();
      if (!append_lines (ibufp, second_addr, isglobal))
        ;
      ibufp = "";
      break;
    case 'c':
      if (first_addr == 0)
	first_addr = 1;
      if (second_addr == 0)
	second_addr = 1;
      if (!check_addr_range (-1, -1, addr_cnt) || !get_command_suffix (&gflags))
	return ERR;
      if (!isglobal)
	clear_undo_stack ();
      if (!delete_lines (first_addr, second_addr, isglobal) || !append_lines (ibufp, current_addr (), isglobal))
        ;
      ibufp = "";
      break;
    case 'd':
      if (!check_addr_range (-1, -1, addr_cnt) || !get_command_suffix (&gflags))
	return ERR;
      if (!isglobal)
	clear_undo_stack ();
      if (!delete_lines (first_addr, second_addr, isglobal))
        ;
      inc_current_addr ();
      break;
    case 'e':
      if (modified () && !scripted ())
        ;
    case 'E':
      if (unexpected_address (addr_cnt) || unexpected_command_suffix (*ibufp))
	return ERR;
      fnp = get_filename ();
      if (!fnp || !get_command_suffix (&gflags) || !delete_lines (1, last_addr (), isglobal))
        ;
      if (!close_sbuf ())
        ;
      if (!open_sbuf ())
        ;
      if (fnp[0] && fnp[0] != '!')
	set_def_filename (fnp);
      if (traditional () && !fnp[0] && !def_filename[0])
	{
          ;
          ;
	}
      if (read_file (fnp[0] ? fnp : def_filename, 0) < 0)
        ;
      disable_undo ();
      set_modified (0);
      break;
    case 'f':
      if (unexpected_address (addr_cnt) || unexpected_command_suffix (*ibufp))
	return ERR;
      ;
      ;
    case 'g':
    case 'v':
    case 'G':
    case 'V':
      if (isglobal)
	{
          ;
          ;
	}
      n = (c == 'g' || c == 'G');
      if (!check_addr_range (1, last_addr (), addr_cnt) || !build_active_list (&ibufp, first_addr, second_addr, n))
	return ERR;
      n = (c == 'G' || c == 'V');
      if ((n && !get_command_suffix (&gflags)) || !exec_global (ibufp, gflags, n))
	return ERR;
      break;
    case 'h':
    case 'H':
      if (unexpected_address (addr_cnt) || !get_command_suffix (&gflags))
	return ERR;
      if (c == 'H')
	verbose = !verbose;
      if ((c == 'h' || verbose) && errmsg[0])
	fprintf (stderr, "%s\n", errmsg);
      break;
    case 'i':
      if (second_addr == 0)
	second_addr = 1;
      if (!get_command_suffix (&gflags))
	return ERR;
      if (!isglobal)
	clear_undo_stack ();
      if (!append_lines (ibufp, second_addr - 1, isglobal))
        ;
      ibufp = "";
      break;
    case 'j':
      if (!check_addr_range (-1, current_addr () + 1, addr_cnt) || !get_command_suffix (&gflags))
        ;
      if (!isglobal)
	clear_undo_stack ();
      if (first_addr != second_addr && !join_lines (first_addr, second_addr, isglobal))
        ;
      break;
    case 'k':
      n = *ibufp++;
      if (second_addr == 0)
	{
	  invalid_address ();
	  return ERR;
	}
      if (!get_command_suffix (&gflags) || !mark_line_node (search_line_node (second_addr), n))
	return ERR;
      break;
    case 'l':
    case 'n':
    case 'p':
      ;
    case 'm':
      if (!check_addr_range (-1, -1, addr_cnt) || !get_third_addr (&addr))
        ;
      if (addr >= first_addr && addr < second_addr)
	{
	  set_error_msg ("Invalid destination");
	  return ERR;
	}
      if (!get_command_suffix (&gflags))
        ;
      if (!isglobal)
	clear_undo_stack ();
      if (!move_lines (first_addr, second_addr, addr, isglobal))
        ;
      break;
    case 'P':
    case 'q':
    case 'Q':
      if (unexpected_address (addr_cnt) || !get_command_suffix (&gflags))
	return ERR;
      if (c == 'P')
        ;
      else
	status = ((modified () && !scripted () && c == 'q') ? EMOD : -1);
      break;
    case 'r':
      if (unexpected_command_suffix (*ibufp))
        ;
      if (addr_cnt == 0)
	second_addr = last_addr ();
      fnp = get_filename ();
      if (!fnp || !get_command_suffix (&gflags))
        ;
      if (!isglobal)
	clear_undo_stack ();
      if (!def_filename[0] && fnp[0] != '!')
	set_def_filename (fnp);
      if (traditional () && !fnp[0] && !def_filename[0])
	{
          ;
          ;
	}
      addr = read_file (fnp[0] ? fnp : def_filename, second_addr);
      if (addr < 0)
	return ERR;
      if (addr && addr != last_addr ())
	set_modified (1);
      break;
    case 's':
      if (!command_s (&gflags, addr_cnt, isglobal))
	return ERR;
      break;
    case 't':
      if (!check_addr_range (-1, -1, addr_cnt) || !get_third_addr (&addr) || !get_command_suffix (&gflags))
	return ERR;
      if (!isglobal)
	clear_undo_stack ();
      if (!copy_lines (first_addr, second_addr, addr))
        ;
      break;
    case 'u':
      if (unexpected_address (addr_cnt) || !get_command_suffix (&gflags) || !pop_undo_stack (isglobal))
	return ERR;
      break;
    case 'w':
    case 'W':
      n = *ibufp;
      if (n == 'q' || n == 'Q')
	{
	  status = -1;
	  ++ibufp;
	}
      if (unexpected_command_suffix (*ibufp))
	return ERR;
      fnp = get_filename ();
      if (!fnp)
        ;
      if (addr_cnt == 0 && !last_addr ())
	first_addr = second_addr = 0;
      else if (!check_addr_range (1, last_addr (), addr_cnt))
        ;
      if (!get_command_suffix (&gflags))
        ;
      if (!def_filename[0] && fnp[0] != '!')
        ;
      if (traditional () && !fnp[0] && !def_filename[0])
	{
          ;
          ;
	}
      addr = write_file (fnp[0] ? fnp : def_filename, (c == 'W') ? "a" : "w", first_addr, second_addr);
      if (addr < 0)
	return ERR;
      if (addr == last_addr ())
	set_modified (0);
      break;
    case 'x':
      if (second_addr < 0 || last_addr () < second_addr)
	{
          ;
          ;
	}
      if (!get_command_suffix (&gflags))
        ;
      if (!isglobal)
	clear_undo_stack ();
      if (!put_lines (second_addr))
	return ERR;
      break;
    case 'y':
      if (!check_addr_range (-1, -1, addr_cnt) || !get_command_suffix (&gflags) || !yank_lines (first_addr, second_addr))
        ;
      break;
    case 'z':
      first_addr = 1;
      if (!check_addr_range (first_addr, current_addr () + (traditional () || !isglobal), addr_cnt))
	return ERR;
      ;
    case '=':
      ;
    case '!':
      if (unexpected_address (addr_cnt))
	return ERR;
      n = get_shell_command ();
      if (n < 0 || !get_command_suffix (&gflags))
	return ERR;
      if (n)
        ;
      system (shcmd + 1);
      if (!scripted ())
        ;
      break;
    case '\n':
      first_addr = 1;
      if (!check_addr_range (first_addr, current_addr () + (traditional () || !isglobal), addr_cnt) || !display_lines (second_addr, second_addr, 0))
        ;
      break;
    case '#':
      while (*ibufp++ != '\n');
      break;
    default:
      ;
      ;
    }
  if (!status && gflags && !display_lines (current_addr (), current_addr (), gflags))
    ;
  return status;
}



char exec_global (const char *ibufp2, int gflags, const char interact)
{
  static char *ocmd = 0;
  static int ocmdsz = 0;
  const line_t *lp = 0;
  const char *cmd = 0;

  if (!interact)
    {
      if (traditional () && !strcmp (ibufp2, "\n"))
        ;
      else if (!(cmd = get_extended_line (ibufp2, 0, 0)))
        ;
    }
  clear_undo_stack ();
  while ((lp = next_active_node ()))
    {
      set_current_addr (get_line_node_addr (lp));
      if (current_addr () < 0)
        ;
      if (interact)
	{

	  int len;
          ;
	}
      ibufp = cmd;
      while (*ibufp)
	if (exec_command (1) < 0)
	  return 0;
    }
  return 1;
}


int main_loop (const char loose)
{
  extern jmp_buf jmp_state;
  const char *ibufp2;
  volatile int err_status = 0;
  volatile int linenum = 0;
  int len, status;

  disable_interrupts ();
  set_signals ();
  status = setjmp (jmp_state);
  if (!status)
    enable_interrupts ();
  else
    {
      ;
      ;
    }

  while (1)
    {
      if (status < 0 && verbose)
	fprintf (stderr, "%s\n", errmsg);
      if (prompt_on)
	{
          ;
          ;
	}
      ibufp2 = get_tty_line (&len);
      if (!ibufp2)
        ;
      if (!len)
	{
	  if (!modified () || scripted ())
	    return err_status;
          ;
          ;
          ;
	}
      else if (ibufp2[len - 1] != '\n')
	{
          ;
          ;
          ;
	}
      else
	++linenum;
      ibufp = ibufp2;
      status = exec_command (0);
      if (status == 0)
	continue;
      if (status == -1)
	return err_status;
      if (!loose)
	err_status = 1;
      if (status == EMOD)
	{
          ;
          ;
          ;
          ;
	}
      else if (status == FATAL)
	{
          ;
	}
      else
	{
	  fputs ("?\n", stderr);
	  if (is_regular_file (0))
	    {
              ;
	    }
	}
    }
}


void set_error_msg (const char *msg)
{
  if (!msg)
    ;
  strncpy (errmsg, msg, sizeof (errmsg));
  errmsg[sizeof (errmsg) - 1] = 0;
}


