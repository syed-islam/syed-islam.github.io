#include <assert.h>








#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ed.h"


static const line_t **active_list = 0;
static int active_size = 0;
static int active_last = 0;
static int active_ptr = 0;
static int active_ndx = 0;



char set_active_node (const line_t * lp)
{
  disable_interrupts ();
  if (!resize_buffer ((void *) &active_list, &active_size, (active_last + 1) * sizeof (line_t **)))
    {
      ;
      ;
      ;
      ;
    }
  enable_interrupts ();
  active_list[active_last++] = lp;
  return 1;
}



void unset_active_nodes (const line_t * np, const line_t * mp)
{
  const line_t *lp = np;

  while (lp != mp)
    {
      int i;
      for (i = 0; i < active_last; ++i)
	{
	  if (++active_ndx >= active_last)
	    active_ndx = 0;
	  if (active_list[active_ndx] == lp)
	    {
	      active_list[active_ndx] = 0;
	      break;
	    }
	}
      lp = lp->q_forw;
    }
}



const line_t *next_active_node (void)
{
  while (active_ptr < active_last && !active_list[active_ptr])
    ++active_ptr;
  return (active_ptr < active_last) ? active_list[active_ptr++] : 0;
}



void clear_active_list (void)
{
  disable_interrupts ();
  if (active_list)
    free (active_list);
  active_list = 0;
  active_size = active_last = active_ptr = active_ndx = 0;
  enable_interrupts ();
}


