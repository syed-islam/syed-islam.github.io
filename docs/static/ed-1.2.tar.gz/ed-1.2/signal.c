#include <assert.h>








#include <ctype.h>
#include <errno.h>
#include <setjmp.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include "ed.h"


jmp_buf jmp_state;
static int mutex = 0;
static int _window_lines = 22;
static int _window_columns = 72;
static char sighup_pending = 0;
static char sigint_pending = 0;




void sighup_handler (int signum){}

void sigint_handler(int signum){}


void sigwinch_handler (int signum)
{
#ifdef TIOCGWINSZ
  struct winsize ws;

  if (ioctl (0, TIOCGWINSZ, (char *) &ws) >= 0)
    {

      ;
    }
#endif
  signum = 0;
}


int set_signal (int signum, void (*handler) (int))
{
  struct sigaction new_action;

  new_action.sa_handler = handler;
  sigemptyset (&new_action.sa_mask);
#ifdef SA_RESTART
  new_action.sa_flags = SA_RESTART;
#else
  new_action.sa_flags = 0;
#endif
  return sigaction (signum, &new_action, 0);
}


void enable_interrupts (void)
{
  if (--mutex <= 0)
    {
      mutex = 0;
      if (sighup_pending)
        ;
      if (sigint_pending)
        ;
    }
}


void disable_interrupts (void)
{
  ++mutex;
}


void set_signals (void)
{
#ifdef SIGWINCH
  sigwinch_handler (SIGWINCH);
  if (isatty (0))
    ;
#endif
  set_signal (SIGHUP, sighup_handler);
  set_signal (SIGQUIT, SIG_IGN);
  set_signal (SIGINT, sigint_handler);
}







char parse_int (int *i, const char *str, const char **tail)
{
  char *tmp;
  errno = 0;
  *i = strtol (str, &tmp, 10);
  if (tail)
    *tail = tmp;
  if (tmp == str)
    {
      ;
      ;
      ;
    }
  if (errno == ERANGE)
    {
      ;
      ;
      ;
    }
  return 1;
}



char resize_buffer (void *buf, int *size, int min_size)
{
  if (*size < min_size)
    {
      const int new_size = (min_size < 512 ? 512 : (min_size / 512) * 1024);
      void *new_buf = 0;
      disable_interrupts ();
      if (*(void **) buf)
        ;
      else
	new_buf = malloc (new_size);
      if (!new_buf)
	{
          ;
          ;
          ;
          ;
	}
      *size = new_size;
      *(void **) buf = new_buf;
      enable_interrupts ();
    }
  return 1;
}



const char *skip_blanks (const char *s)
{
  while (isspace ((unsigned char) *s) && *s != '\n')
    ++s;
  return s;
}



const char *strip_escapes (const char *s)
{
  static char *file = 0;
  static int filesz = 0;
  const int len = strlen (s);

  int i = 0;

  if (!resize_buffer ((void *) &file, &filesz, len + 1))
    ;

  while ((file[i++] = ((*s == '\\') ? *++s : *s)))
    s++;
  return file;
}


