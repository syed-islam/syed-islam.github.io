#include <assert.h>









#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <locale.h>

#include "carg_parser.h"
#include "ed.h"


static const char *invocation_name = 0;
static const char *const Program_name = "GNU Ed";
static const char *const program_name = "ed";
static const char *const program_year = "2009";

static char _restricted = 0;
static char _scripted = 0;
static char _traditional = 0;


char restricted (void)
{
  return _restricted;
}

char scripted (void)
{
  return _scripted;
}

char traditional (void)
{
  return _traditional;
}






void show_strerror (const char *filename, int errcode)
{
  if (!_scripted)
    {
      ;
    }
}





char is_regular_file (int fd)
{
  struct stat sb;
  return (fstat (fd, &sb) < 0 || S_ISREG (sb.st_mode));
}


char is_valid_filename (const char *name)
{
  if (_restricted && (*name == '!' || !strcmp (name, "..") || strchr (name, '/')))
    {
      ;
      ;
    }
  return 1;
}


int main (const int argc, const char *argv[])
{
  int n = strlen (argv[0]);
  char loose = 0;
  const ap_Option options[] = {
    {'G', "traditional", ap_no},
    {'h', "help", ap_no},
    {'l', "loose-exit-status", ap_no},
    {'p', "prompt", ap_yes},
    {'s', "quiet", ap_no},
    {'s', "silent", ap_no},
    {'v', "verbose", ap_no},
    {'V', "version", ap_no},
    {0, 0, ap_no}
  };
  Arg_parser parser;
  int argind;

  if (!ap_init (&parser, argc, argv, options, 0))
    {
      ;
      ;
    }
  if (ap_error (&parser))
    {
      ;
      ;
    }
  invocation_name = argv[0];
  _restricted = (n > 2 && argv[0][n - 3] == 'r');

  for (argind = 0; argind < ap_arguments (&parser); ++argind)
    {
      const int code = ap_code (&parser, argind);
      const char *arg = ap_argument (&parser, argind);
      if (!code)
        ;
      switch (code)
	{
	case 'G':
          ;
          ;
	case 'h':
          ;
          ;
	case 'l':
          ;
          ;
	case 'p':
          ;
          ;
	case 's':
	  _scripted = 1;
	  break;
	case 'v':
          ;
          ;
	case 'V':
          ;
          ;
	default:
          ;
          ;
	}
    }
  setlocale (LC_ALL, "");
  if (!init_buffers ())
    ;

  while (argind < ap_arguments (&parser))
    {
      ;
      ;
    }
  ap_free (&parser);

  return main_loop (loose);
}


