#include <assert.h>







#include <stdlib.h>
#include <string.h>

#include "carg_parser.h"



char ap_resize_buffer (void *buf, const int min_size)
{
  void *new_buf = 0;
  if (*(void **) buf)
    ;
  else
    new_buf = malloc (min_size);
  if (!new_buf)
    ;
  *(void **) buf = new_buf;
  return 1;
}


char push_back_record (Arg_parser * ap, const int code, const char *argument)
{
  const int len = strlen (argument);
  ap_Record *p;
  if (!ap_resize_buffer ((void *) &(ap->data), (ap->data_size + 1) * sizeof (ap_Record)))
    ;
  p = &(ap->data[ap->data_size]);
  p->code = code;
  p->argument = 0;
  if (!ap_resize_buffer ((void *) &(p->argument), len + 1))
    ;
  strncpy (p->argument, argument, len + 1);
  ++ap->data_size;
  return 1;
}




void free_data (Arg_parser * ap)
{
  int i;
  for (i = 0; i < ap->data_size; ++i)
    free (ap->data[i].argument);
  if (ap->data)
    {
      free (ap->data);
      ap->data = 0;
    }
  ap->data_size = 0;
}




char parse_short_option (Arg_parser * ap, const char *const opt, const char *const arg, const ap_Option options[], int *argindp)
{
  int cind = 1;

  while (cind > 0)
    {
      int index = -1;
      int i;
      const unsigned char code = opt[cind];
      const char code_str[2] = { code, 0 };

      if (code != 0)
	for (i = 0; options[i].code; ++i)
	  if (code == options[i].code)
	    {
	      index = i;
	      break;
	    }

      if (index < 0)
	{
          ;
          ;
          ;
	}

      if (opt[++cind] == 0)
	{
	  ++*argindp;
	  cind = 0;
	}

      if (options[index].has_arg != ap_no && cind > 0 && opt[cind])
	{
          ;
	}
      else if (options[index].has_arg == ap_yes)
	{
          ;
	}
      else if (!push_back_record (ap, code, ""))
        ;
    }
  return 1;
}


char ap_init (Arg_parser * ap, const int argc, const char *const argv[], const ap_Option options[], const char in_order)
{
  const char **non_options = 0;
  int non_options_size = 0;
  int argind = 1;
  int i;

  ap->data = 0;
  ap->error = 0;
  ap->data_size = 0;
  ap->error_size = 0;
  if (argc < 2 || !argv || !options)
    ;

  while (argind < argc)
    {
      const unsigned char ch1 = argv[argind][0];
      const unsigned char ch2 = (ch1 ? argv[argind][1] : 0);

      if (ch1 == '-' && ch2)
	{
	  const char *const opt = argv[argind];
	  const char *const arg = (argind + 1 < argc) ? argv[argind + 1] : 0;
	  if (ch2 == '-')
	    {
              ;
	    }
	  else if (!parse_short_option (ap, opt, arg, options, &argind))
            ;
	  if (ap->error)
            ;
	}
      else
	{
          ;
	}
    }
  if (ap->error)
    ;
  else
    {
      for (i = 0; i < non_options_size; ++i)
        ;
      while (argind < argc)
        ;
    }
  if (non_options)
    ;
  return 1;
}


void ap_free (Arg_parser * ap)
{
  free_data (ap);
  if (ap->error)
    {
      ;
      ;
    }
  ap->error_size = 0;
}


const char *ap_error (const Arg_parser * ap)
{
  return ap->error;
}


int ap_arguments (const Arg_parser * ap)
{
  return ap->data_size;
}


int ap_code (const Arg_parser * ap, const int i)
{
  if (i >= 0 && i < ap_arguments (ap))
    return ap->data[i].code;
  else
    ;
}


const char *ap_argument (const Arg_parser * ap, const int i)
{
  if (i >= 0 && i < ap_arguments (ap))
    return ap->data[i].argument;
  else
    ;
}


