static int isletter(char c);

main()
{
    char c;
    int inword;
    int lines;
    int words;
    int characters;

    inword = 0;

    lines = 0;


    while (scanf("%c", &c) == 1)
    {
        characters  = characters + 1;

        if (c == '\n')
        {
            lines = lines + 1;
        }

        if (isletter(c))
        {
            if (inword == 0)
            {
                words = words + 1;
                inword = 1;
            }
        }
        else
        {
            inword = 0;
        }
    }


    printf("\nORBS:%d ", lines);
    printf("%d ", words);
    printf("%d\n", characters);

}

static int isletter(char c)
{
    if (((c >= 'A' ) && (c <= 'Z')) ||(c >= 'a' ) && (c <= 'z'))
    {
        return 1;
    }




}





