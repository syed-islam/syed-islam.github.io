

main()
{
    char c;










    while (scanf("%c", &c) == 1)






























    printf("\nORBS:%c ", c);








}





