

main()
{
    char c;
    int inword;
    int lines;

    int characters;






    while (scanf("%c", &c) == 1)
    {
        characters  = characters + 1;


















    }




    printf("\nORBS:%d ", characters);
}

















