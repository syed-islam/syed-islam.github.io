#!/bin/sh

FILE=wc_c_45

cd $1

# cleanup
rm -f $FILE

# actual compilation
gcc $CFLAGS -o $FILE $FILE.c 2> compile.log
rc=$?

# check successful compilation and create signature
if [ -f $FILE ]; then
    md5sum $FILE
else
    echo FAIL
fi
exit $rc;

