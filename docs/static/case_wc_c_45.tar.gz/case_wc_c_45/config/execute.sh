#!/bin/sh
ElapsedTimeLimit=1s

FILE=wc_c_45

cd $1

rm -rf output.orbs

# actual execution
time timeout -s KILL $ElapsedTimeLimit ./$FILE < test0.txt > output.orbs 2> execute.err
rc=$?

if [ -f output.orbs ]; then
	if [ "$4" = "GA" ] 
	then
		grep "$2" output.orbs 2> /dev/null
	else
		grep "$2" output.orbs 2> /dev/null | md5sum
	fi    	
else
    echo FAIL
fi

# extract projected trajectory

# cleanup
rm -rf output.orbs
exit $rc

