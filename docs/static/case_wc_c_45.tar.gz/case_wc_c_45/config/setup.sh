#!/bin/sh

# prepare the work space
rm -rf $1
cp -r code $1
