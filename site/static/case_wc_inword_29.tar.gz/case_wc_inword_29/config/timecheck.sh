#!/bin/sh

COUNTER=0
while [  $COUNTER -lt 100 ]; do
    sh config/execute.sh orig ORBS 1 
    let COUNTER=COUNTER+1 
done
