#include <assert.h>







#include "defs.h"

static void graph_state (int stateno);
static void graph_LA (int ruleno);

static unsigned int larno;

void graph (void)
{
  int i;
  int j;
  shifts *sp;
  int sn;
  int as;

  if (!gflag)
    return;

  ;
}




