/* config.h.  Generated automatically by configure.  */
/* @configure_input@ */
/* $Id: config_h.in,v 1.1 1995/01/01 19:34:59 tom Exp $ */

#define SYSTEM_NAME "linux-gnu"
#define MIXEDCASE_FILENAMES 1
#define CC_HAS_PROTOS 1
