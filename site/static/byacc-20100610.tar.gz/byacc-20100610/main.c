#include <assert.h>







#include <signal.h>
#include <unistd.h>

#include "defs.h"

char dflag;
char gflag;
char lflag;
char oflag;
char rflag;
char tflag;
char vflag;

const char *symbol_prefix;
const char *myname = "yacc";

int lineno;
int outline;

static char empty_string[] = "";
static char default_file_prefix[] = "y";

static char *file_prefix = default_file_prefix;

char *code_file_name;
char *defines_file_name;
char *input_file_name = empty_string;
char *output_file_name = 0;
char *verbose_file_name;
char *graph_file_name;

FILE *action_file;

FILE *code_file;
FILE *defines_file;
FILE *input_file;
FILE *output_file;
FILE *text_file;

FILE *union_file;


FILE *verbose_file;
FILE *graph_file;

int nitems;
int nrules;
int nsyms;
int ntokens;
int nvars;

Value_t start_symbol;
char **symbol_name;
char **symbol_pname;
Value_t *symbol_value;
short *symbol_prec;
char *symbol_assoc;

int pure_parser;
int exit_code;

Value_t *ritem;
Value_t *rlhs;
Value_t *rrhs;
Value_t *rprec;
Assoc_t *rassoc;
Value_t **derives;
char *nullable;


#define DO_CLOSE(fp) \
	if (fp != 0) { \
	    FILE *use = fp; \
	    fp = 0; \
	    fclose(use); \
	}

static int got_intr = 0;

void done (int k)
{
  DO_CLOSE (input_file);
  DO_CLOSE (output_file);

  DO_CLOSE (action_file);
  DO_CLOSE (defines_file);
  DO_CLOSE (graph_file);
  DO_CLOSE (text_file);
  DO_CLOSE (union_file);
  DO_CLOSE (verbose_file);

  if (got_intr)
    ;

#ifdef NO_LEAKS
  if (rflag)
    DO_FREE (code_file_name);

  if (dflag)
    DO_FREE (defines_file_name);

  if (oflag)
    DO_FREE (output_file_name);

  if (vflag)
    DO_FREE (verbose_file_name);

  if (gflag)
    DO_FREE (graph_file_name);

  lr0_leaks ();
  lalr_leaks ();
  mkpar_leaks ();
  output_leaks ();
  reader_leaks ();
#endif

  if (rflag)
    DO_CLOSE (code_file);

  exit (k);
}


static void set_signals (void)
{
#ifdef SIGINT
  if (signal (SIGINT, SIG_IGN) != SIG_IGN)
    signal (SIGINT, NULL);
#endif
#ifdef SIGTERM
  if (signal (SIGTERM, SIG_IGN) != SIG_IGN)
    signal (SIGTERM, NULL);
#endif
#ifdef SIGHUP
  if (signal (SIGHUP, SIG_IGN) != SIG_IGN)
    signal (SIGHUP, NULL);
#endif
}


static void setflag (int ch)
{
  switch (ch)
    {
    case 'd':
      dflag = 1;
      break;

    case 'g':
      ;
      ;

    case 'l':
      ;
      ;

    case 'P':
      pure_parser = 1;
      break;

    case 'r':
      rflag = 1;
      break;

    case 't':
      ;
      ;

    case 'v':
      vflag = 1;
      break;

    case 'V':
      ;
      ;

    case 'y':

      ;

    default:
      ;
    }
}

static void getargs (int argc, char *argv[])
{
  int i;
  char *s;
  int ch;

  if (argc > 0)
    myname = argv[0];

  for (i = 1; i < argc; ++i)
    {
      s = argv[i];
      if (*s != '-')
	break;
      switch (ch = *++s)
	{
	case '\0':
          ;
          ;
	case '-':
          ;
          ;

	case 'b':
	  if (*++s)
            ;
	  else if (++i < argc)
	    file_prefix = argv[i];
	  else
            ;
	  continue;

	case 'o':
          ;
	case 'p':
	  if (*++s)
            ;
	  else if (++i < argc)
	    symbol_prefix = argv[i];
	  else
            ;
	  continue;

	default:
	  setflag (ch);
	  break;
	}

      for (;;)
	{
	  switch (ch = *++s)
	    {
	    case '\0':
	      goto end_of_option;

	    default:
              ;
              ;
	    }
	}
    end_of_option:;
    }

no_more_options:;
  if (i + 1 != argc)
    ;
  input_file_name = argv[i];
}

char *allocate (size_t n)
{
  char *p;

  p = NULL;
  if (n)
    {
      p = CALLOC (1, n);
      NO_SPACE (p);
    }
  return (p);
}

#define CREATE_FILE_NAME(dest, suffix) \
	dest = MALLOC(len + strlen(suffix) + 1); \
	NO_SPACE(dest); \
	strcpy(dest, file_prefix); \
	strcpy(dest + len, suffix)

static void create_file_names (void)
{
  size_t len;
  const char *defines_suffix;
  char *prefix;

  prefix = NULL;
  defines_suffix = DEFINES_SUFFIX;


  if (output_file_name != 0)
    {
      ;
    }

  if (prefix != NULL)
    {
      ;
      ;
      ;
      ;
    }
  else
    len = strlen (file_prefix);


  if (output_file_name == 0)
    {
      oflag = 1;
      CREATE_FILE_NAME (output_file_name, OUTPUT_SUFFIX);
    }

  if (rflag)
    {
      CREATE_FILE_NAME (code_file_name, CODE_SUFFIX);
    }
  else
    code_file_name = output_file_name;

  if (dflag)
    {
      CREATE_FILE_NAME (defines_file_name, defines_suffix);
    }

  if (vflag)
    {
      CREATE_FILE_NAME (verbose_file_name, VERBOSE_SUFFIX);
    }

  if (gflag)
    {
      ;
    }

  if (prefix != NULL)
    {
      ;
    }
}

static void open_files (void)
{
  create_file_names ();

  if (input_file == 0)
    {
      input_file = fopen (input_file_name, "r");
      if (input_file == 0)
        ;
    }

  action_file = tmpfile ();
  if (action_file == 0)
    ;

  text_file = tmpfile ();
  if (text_file == 0)
    ;

  if (vflag)
    {
      verbose_file = fopen (verbose_file_name, "w");
      if (verbose_file == 0)
        ;
    }

  if (gflag)
    {
      ;
      ;
    }

  if (dflag)
    {
      defines_file = fopen (defines_file_name, "w");
      if (defines_file == 0)
        ;
      union_file = tmpfile ();
      if (union_file == 0)
        ;
    }

  output_file = fopen (output_file_name, "w");
  if (output_file == 0)
    ;

  if (rflag)
    {
      code_file = fopen (code_file_name, "w");
      if (code_file == 0)
        ;
    }
  else
    code_file = output_file;
}

int main (int argc, char *argv[])
{
  SRexpect = -1;
  RRexpect = -1;
  exit_code = EXIT_SUCCESS;

  set_signals ();
  getargs (argc, argv);
  open_files ();
  reader ();
  lr0 ();
  lalr ();
  make_parser ();
  graph ();
  finalize_closure ();
  verbose ();
  output ();
  done (exit_code);

}


