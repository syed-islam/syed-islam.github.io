



#define FLEX_SCANNER
#define YY_FLEX_MAJOR_VERSION 2
#define YY_FLEX_MINOR_VERSION 5

#include <stdio.h>
#include <unistd.h>



#ifdef c_plusplus
#ifndef __cplusplus
#define __cplusplus
#endif
#endif


#ifdef __cplusplus

#include <stdlib.h>


#define YY_USE_PROTOS


#define YY_USE_CONST

#else

#if __STDC__

#define YY_USE_PROTOS
#define YY_USE_CONST

#endif
#endif

#ifdef __TURBOC__
#pragma warn -rch
#pragma warn -use
#include <io.h>
#include <stdlib.h>
#define YY_USE_CONST
#define YY_USE_PROTOS
#endif

#ifdef YY_USE_CONST
#define yyconst const
#else
#define yyconst
#endif


#ifdef YY_USE_PROTOS
#define YY_PROTO(proto) proto
#else
#define YY_PROTO(proto) ()
#endif


#define YY_NULL 0


#define YY_SC_TO_UI(c) ((unsigned int) (unsigned char) c)


#define BEGIN yy_start = 1 + 2 *


#define YY_START ((yy_start - 1) / 2)
#define YYSTATE YY_START


#define YY_STATE_EOF(state) (YY_END_OF_BUFFER + state + 1)


#define YY_NEW_FILE yyrestart( yyin )

#define YY_END_OF_BUFFER_CHAR 0


#define YY_BUF_SIZE 16384

typedef struct yy_buffer_state *YY_BUFFER_STATE;

extern int yyleng;
extern FILE *yyin, *yyout;

#define EOB_ACT_CONTINUE_SCAN 0
#define EOB_ACT_END_OF_FILE 1
#define EOB_ACT_LAST_MATCH 2





#define yyless(n) \
	do \
		{ \
		 \
		*yy_cp = yy_hold_char; \
		YY_RESTORE_YY_MORE_OFFSET \
		yy_c_buf_p = yy_cp = yy_bp + n - YY_MORE_ADJ; \
		YY_DO_BEFORE_ACTION;  \
		} \
	while ( 0 )

#define unput(c) yyunput( c, yytext_ptr )


typedef unsigned int yy_size_t;


struct yy_buffer_state
{
  FILE *yy_input_file;

  char *yy_ch_buf;
  char *yy_buf_pos;


  yy_size_t yy_buf_size;


  int yy_n_chars;


  int yy_is_our_buffer;


  int yy_is_interactive;


  int yy_at_bol;


  int yy_fill_buffer;

  int yy_buffer_status;
#define YY_BUFFER_NEW 0
#define YY_BUFFER_NORMAL 1

#define YY_BUFFER_EOF_PENDING 2
};

static YY_BUFFER_STATE yy_current_buffer = 0;


#define YY_CURRENT_BUFFER yy_current_buffer



static char yy_hold_char;

static int yy_n_chars;


int yyleng;


static char *yy_c_buf_p = (char *) 0;
static int yy_init = 1;
static int yy_start = 0;


static int yy_did_buffer_switch_on_eof;

void yyrestart YY_PROTO ((FILE * input_file));

void yy_switch_to_buffer YY_PROTO ((YY_BUFFER_STATE new_buffer));
void yy_load_buffer_state YY_PROTO ((void));
YY_BUFFER_STATE yy_create_buffer YY_PROTO ((FILE * file, int size));
void yy_delete_buffer YY_PROTO ((YY_BUFFER_STATE b));
void yy_init_buffer YY_PROTO ((YY_BUFFER_STATE b, FILE * file));
void yy_flush_buffer YY_PROTO ((YY_BUFFER_STATE b));
#define YY_FLUSH_BUFFER yy_flush_buffer( yy_current_buffer )

YY_BUFFER_STATE yy_scan_buffer YY_PROTO ((char *base, yy_size_t size));
YY_BUFFER_STATE yy_scan_string YY_PROTO ((yyconst char *yy_str));
YY_BUFFER_STATE yy_scan_bytes YY_PROTO ((yyconst char *bytes, int len));

static void *yy_flex_alloc YY_PROTO ((yy_size_t));
static void *yy_flex_realloc YY_PROTO ((void *, yy_size_t));
static void yy_flex_free YY_PROTO ((void *));

#define yy_new_buffer yy_create_buffer

#define yy_set_interactive(is_interactive) \
	{ \
	if ( ! yy_current_buffer ) \
		yy_current_buffer = yy_create_buffer( yyin, YY_BUF_SIZE ); \
	yy_current_buffer->yy_is_interactive = is_interactive; \
	}

#define yy_set_bol(at_bol) \
	{ \
	if ( ! yy_current_buffer ) \
		yy_current_buffer = yy_create_buffer( yyin, YY_BUF_SIZE ); \
	yy_current_buffer->yy_at_bol = at_bol; \
	}

#define YY_AT_BOL() (yy_current_buffer->yy_at_bol)


#define FLEX_DEBUG
typedef unsigned char YY_CHAR;
FILE *yyin = (FILE *) 0, *yyout = (FILE *) 0;
typedef int yy_state_type;

#define FLEX_DEBUG
extern char *yytext;
#define yytext_ptr yytext

static yy_state_type yy_get_previous_state YY_PROTO ((void));
static yy_state_type yy_try_NUL_trans YY_PROTO ((yy_state_type current_state));
static int yy_get_next_buffer YY_PROTO ((void));
static void yy_fatal_error YY_PROTO ((yyconst char msg[]));


#define YY_DO_BEFORE_ACTION \
	yytext_ptr = yy_bp; \
	yyleng = (int) (yy_cp - yy_bp); \
	yy_hold_char = *yy_cp; \
	*yy_cp = '\0'; \
	yy_c_buf_p = yy_cp;

#define YY_NUM_RULES 72
#define YY_END_OF_BUFFER 73
static yyconst short int yy_accept[191] = { 0,
  68, 68, 3, 3, 58, 58, 63, 63, 0, 0,
  73, 71, 68, 67, 71, 57, 71, 71, 71, 71,
  21, 71, 71, 23, 71, 52, 71, 41, 71, 39,
  51, 71, 51, 51, 51, 51, 51, 71, 68, 71,
  69, 70, 3, 4, 5, 58, 59, 62, 72, 66,
  63, 64, 65, 72, 13, 72, 68, 0, 37, 0,
  11, 26, 35, 31, 0, 0, 24, 44, 0, 0,
  0, 27, 45, 28, 22, 0, 55, 2, 0, 25,
  56, 52, 0, 54, 53, 53, 42, 40, 36, 38,
  43, 51, 33, 51, 51, 51, 51, 51, 51, 32,

  34, 68, 0, 0, 0, 0, 0, 0, 3, 4,
  5, 6, 5, 7, 58, 60, 61, 63, 0, 13,
  0, 12, 46, 0, 46, 0, 0, 50, 55, 0,
  0, 1, 0, 54, 29, 30, 51, 51, 51, 51,
  51, 51, 51, 0, 9, 0, 0, 10, 0, 47,
  0, 0, 0, 55, 0, 56, 14, 20, 51, 51,
  51, 51, 51, 9, 0, 48, 0, 49, 0, 55,
  56, 51, 51, 51, 51, 19, 0, 15, 16, 18,
  51, 0, 0, 17, 0, 8, 0, 0, 8, 0
};

static yyconst int yy_ec[256] = { 0,
  1, 1, 1, 1, 1, 1, 1, 1, 2, 3,
  1, 2, 2, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 2, 4, 5, 6, 1, 7, 8, 9, 1,
  1, 10, 11, 1, 12, 13, 14, 15, 16, 16,
  16, 16, 16, 16, 16, 17, 17, 1, 1, 18,
  19, 20, 1, 1, 21, 21, 21, 21, 22, 21,
  23, 23, 23, 23, 23, 23, 23, 23, 23, 23,
  23, 23, 23, 23, 23, 23, 23, 24, 23, 23,
  1, 25, 1, 26, 23, 1, 27, 21, 28, 29,

  30, 31, 23, 23, 32, 23, 23, 33, 34, 35,
  36, 37, 23, 38, 39, 40, 41, 23, 23, 42,
  43, 23, 44, 45, 46, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,

  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1
};

static yyconst int yy_meta[47] = { 0,
  1, 1, 2, 1, 3, 1, 1, 1, 4, 5,
  1, 1, 1, 1, 6, 6, 6, 1, 1, 1,
  6, 7, 8, 8, 3, 1, 6, 6, 6, 7,
  6, 8, 8, 8, 8, 8, 8, 8, 8, 8,
  8, 8, 8, 1, 1, 1
};

static yyconst short int yy_base[212] = { 0,
  0, 45, 45, 46, 47, 54, 58, 62, 50, 51,
  469, 484, 56, 484, 424, 484, 417, 400, 58, 381,
  370, 67, 80, 88, 71, 93, 98, 50, 357, 51,
  0, 314, 291, 52, 291, 287, 294, 79, 110, 134,
  484, 484, 325, 484, 115, 0, 484, 484, 324, 484,
  321, 484, 484, 116, 484, 117, 120, 319, 484, 318,
  484, 484, 484, 484, 311, 123, 484, 484, 128, 139,
  145, 484, 484, 484, 484, 305, 153, 484, 314, 484,
  156, 164, 172, 0, 484, 177, 296, 484, 484, 484,
  295, 0, 484, 262, 260, 258, 96, 258, 254, 484,

  484, 125, 193, 173, 225, 188, 181, 197, 272, 484,
  143, 484, 209, 484, 0, 484, 484, 270, 196, 484,
  199, 484, 484, 259, 226, 216, 225, 484, 221, 237,
  227, 484, 244, 0, 484, 484, 184, 173, 171, 157,
  141, 144, 130, 208, 484, 254, 214, 484, 241, 484,
  258, 155, 199, 230, 247, 265, 0, 0, 125, 116,
  112, 104, 95, 484, 262, 484, 119, 484, 112, 268,
  273, 72, 74, 48, 44, 0, 291, 0, 0, 0,
  42, 294, 288, 0, 274, 484, 309, 275, 484, 484,
  334, 342, 350, 358, 366, 374, 382, 385, 393, 401,

  409, 417, 425, 433, 441, 449, 452, 459, 464, 468,
  475
};

static yyconst short int yy_def[212] = { 0,
  190, 1, 191, 191, 192, 192, 193, 193, 194, 194,
  190, 190, 190, 190, 190, 190, 195, 190, 190, 196,
  190, 190, 190, 190, 190, 190, 197, 190, 190, 190,
  198, 190, 198, 198, 198, 198, 198, 190, 190, 199,
  190, 190, 200, 190, 201, 202, 190, 190, 203, 190,
  190, 190, 190, 204, 190, 204, 190, 195, 190, 195,
  190, 190, 190, 190, 190, 205, 190, 190, 190, 190,
  197, 190, 190, 190, 190, 190, 190, 190, 206, 190,
  190, 190, 190, 207, 190, 197, 190, 190, 190, 190,
  190, 198, 190, 198, 198, 198, 198, 198, 198, 190,

  190, 190, 199, 199, 199, 208, 199, 199, 200, 190,
  201, 190, 201, 190, 202, 190, 190, 190, 204, 190,
  204, 190, 190, 190, 190, 190, 209, 190, 190, 190,
  206, 190, 190, 207, 190, 190, 198, 198, 198, 198,
  198, 198, 198, 208, 190, 208, 208, 190, 199, 190,
  190, 210, 190, 190, 190, 190, 198, 198, 198, 198,
  198, 198, 198, 190, 199, 190, 190, 190, 190, 190,
  190, 198, 198, 198, 198, 198, 199, 198, 198, 198,
  198, 199, 211, 198, 211, 190, 211, 211, 190, 0,
  190, 190, 190, 190, 190, 190, 190, 190, 190, 190,

  190, 190, 190, 190, 190, 190, 190, 190, 190, 190,
  190
};

static yyconst short int yy_nxt[531] = { 0,
  12, 13, 14, 15, 16, 17, 18, 19, 20, 21,
  22, 23, 24, 25, 26, 27, 27, 28, 29, 30,
  31, 31, 31, 31, 12, 32, 33, 31, 31, 34,
  31, 31, 31, 31, 31, 31, 31, 31, 35, 36,
  37, 31, 31, 12, 38, 12, 39, 44, 44, 47,
  40, 48, 55, 55, 45, 45, 47, 57, 48, 51,
  52, 58, 53, 51, 52, 63, 53, 87, 88, 90,
  91, 49, 184, 181, 56, 56, 64, 68, 49, 69,
  78, 70, 71, 71, 79, 72, 95, 180, 41, 80,
  42, 73, 69, 96, 70, 71, 71, 100, 74, 75,

  76, 179, 77, 77, 77, 81, 178, 82, 82, 83,
  81, 102, 86, 86, 86, 103, 84, 112, 120, 122,
  168, 57, 140, 101, 113, 58, 102, 166, 114, 176,
  103, 125, 175, 141, 84, 105, 61, 126, 126, 174,
  121, 121, 77, 77, 77, 112, 127, 173, 106, 106,
  106, 81, 190, 83, 83, 83, 190, 81, 107, 86,
  86, 86, 172, 168, 127, 163, 108, 129, 129, 129,
  77, 77, 77, 162, 130, 61, 81, 133, 82, 82,
  83, 161, 130, 148, 81, 133, 83, 83, 83, 81,
  145, 86, 86, 86, 105, 61, 160, 107, 120, 61,

  159, 122, 146, 146, 146, 107, 158, 106, 106, 106,
  145, 112, 147, 154, 154, 154, 164, 107, 113, 157,
  121, 107, 114, 121, 150, 108, 105, 61, 149, 132,
  151, 151, 147, 150, 150, 129, 129, 129, 147, 106,
  106, 106, 130, 61, 170, 170, 170, 153, 153, 107,
  130, 154, 154, 154, 155, 155, 145, 108, 156, 156,
  156, 156, 156, 156, 61, 107, 166, 150, 146, 146,
  146, 118, 167, 167, 110, 165, 186, 189, 147, 171,
  171, 171, 170, 170, 170, 143, 107, 171, 171, 171,
  186, 177, 182, 61, 142, 182, 61, 139, 188, 188,

  138, 137, 187, 187, 187, 183, 183, 183, 183, 183,
  183, 186, 188, 136, 135, 107, 132, 128, 107, 123,
  61, 61, 118, 187, 187, 187, 117, 110, 99, 98,
  97, 94, 93, 188, 43, 43, 43, 43, 43, 43,
  43, 43, 46, 46, 46, 46, 46, 46, 46, 46,
  50, 50, 50, 50, 50, 50, 50, 50, 54, 54,
  54, 54, 54, 54, 54, 54, 60, 60, 60, 60,
  60, 60, 60, 60, 65, 89, 65, 65, 65, 65,
  65, 65, 85, 85, 85, 85, 85, 85, 67, 85,
  92, 92, 92, 104, 104, 104, 104, 104, 104, 104,

  104, 109, 109, 109, 109, 66, 109, 109, 109, 111,
  111, 111, 111, 111, 111, 111, 111, 115, 62, 61,
  115, 115, 115, 115, 115, 116, 116, 116, 116, 116,
  116, 116, 116, 119, 119, 119, 119, 119, 119, 119,
  119, 124, 59, 124, 124, 124, 124, 124, 124, 131,
  131, 131, 131, 131, 131, 131, 131, 134, 134, 144,
  144, 144, 144, 144, 144, 144, 144, 152, 190, 152,
  152, 169, 190, 169, 169, 185, 185, 185, 185, 185,
  185, 185, 185, 11, 190, 190, 190, 190, 190, 190,
  190, 190, 190, 190, 190, 190, 190, 190, 190, 190,

  190, 190, 190, 190, 190, 190, 190, 190, 190, 190,
  190, 190, 190, 190, 190, 190, 190, 190, 190, 190,
  190, 190, 190, 190, 190, 190, 190, 190, 190, 190
};

static yyconst short int yy_chk[531] = { 0,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 2, 3, 4, 5,
  2, 5, 9, 10, 3, 4, 6, 13, 6, 7,
  7, 13, 7, 8, 8, 19, 8, 28, 28, 30,
  30, 5, 181, 175, 9, 10, 19, 22, 6, 22,
  25, 22, 22, 22, 25, 22, 34, 174, 2, 25,
  2, 23, 23, 34, 23, 23, 23, 38, 23, 23,

  24, 173, 24, 24, 24, 26, 172, 26, 26, 26,
  27, 39, 27, 27, 27, 39, 26, 45, 54, 56,
  169, 57, 97, 38, 45, 57, 102, 167, 45, 163,
  102, 66, 162, 97, 26, 40, 40, 66, 66, 161,
  54, 56, 69, 69, 69, 111, 66, 160, 40, 40,
  40, 70, 111, 70, 70, 70, 111, 71, 40, 71,
  71, 71, 159, 152, 66, 143, 40, 77, 77, 77,
  81, 81, 81, 142, 77, 104, 82, 81, 82, 82,
  82, 141, 77, 107, 83, 81, 83, 83, 83, 86,
  106, 86, 86, 86, 103, 103, 140, 104, 119, 108,

  139, 121, 106, 106, 106, 107, 138, 103, 103, 103,
  144, 113, 106, 153, 153, 153, 147, 103, 113, 137,
  119, 108, 113, 121, 126, 103, 105, 105, 108, 131,
  126, 126, 144, 127, 125, 129, 129, 129, 147, 105,
  105, 105, 129, 149, 154, 154, 154, 130, 130, 105,
  129, 130, 130, 130, 133, 133, 146, 105, 133, 133,
  133, 155, 155, 155, 165, 149, 151, 124, 146, 146,
  146, 118, 151, 151, 109, 149, 185, 188, 146, 156,
  156, 156, 170, 170, 170, 99, 165, 171, 171, 171,
  183, 165, 177, 177, 98, 182, 182, 96, 185, 188,

  95, 94, 183, 183, 183, 177, 177, 177, 182, 182,
  182, 187, 183, 91, 87, 177, 79, 76, 182, 65,
  60, 58, 51, 187, 187, 187, 49, 43, 37, 36,
  35, 33, 32, 187, 191, 191, 191, 191, 191, 191,
  191, 191, 192, 192, 192, 192, 192, 192, 192, 192,
  193, 193, 193, 193, 193, 193, 193, 193, 194, 194,
  194, 194, 194, 194, 194, 194, 195, 195, 195, 195,
  195, 195, 195, 195, 196, 29, 196, 196, 196, 196,
  196, 196, 197, 197, 197, 197, 197, 197, 21, 197,
  198, 198, 198, 199, 199, 199, 199, 199, 199, 199,

  199, 200, 200, 200, 200, 20, 200, 200, 200, 201,
  201, 201, 201, 201, 201, 201, 201, 202, 18, 17,
  202, 202, 202, 202, 202, 203, 203, 203, 203, 203,
  203, 203, 203, 204, 204, 204, 204, 204, 204, 204,
  204, 205, 15, 205, 205, 205, 205, 205, 205, 206,
  206, 206, 206, 206, 206, 206, 206, 207, 207, 208,
  208, 208, 208, 208, 208, 208, 208, 209, 11, 209,
  209, 210, 0, 210, 210, 211, 211, 211, 211, 211,
  211, 211, 211, 190, 190, 190, 190, 190, 190, 190,
  190, 190, 190, 190, 190, 190, 190, 190, 190, 190,

  190, 190, 190, 190, 190, 190, 190, 190, 190, 190,
  190, 190, 190, 190, 190, 190, 190, 190, 190, 190,
  190, 190, 190, 190, 190, 190, 190, 190, 190, 190
};

static yy_state_type yy_last_accepting_state;
static char *yy_last_accepting_cpos;

extern int yy_flex_debug;
int yy_flex_debug = 1;

static yyconst short int yy_rule_linenum[72] = { 0,
  50, 51, 52, 53, 54, 55, 56, 58, 59, 61,
  62, 63, 64, 66, 67, 68, 69, 70, 71, 72,
  73, 79, 80, 81, 82, 83, 84, 85, 86, 87,
  88, 89, 90, 91, 92, 93, 94, 95, 96, 97,
  98, 99, 100, 101, 102, 103, 104, 105, 106, 110,
  111, 112, 116, 120, 121, 122, 135, 136, 137, 138,
  139, 140, 141, 142, 143, 144, 149, 150, 152, 153,
  154
};


#define REJECT reject_used_but_not_detected
#define yymore() yymore_used_but_not_detected
#define YY_MORE_ADJ 0
#define YY_RESTORE_YY_MORE_OFFSET
char *yytext;
#line 1 "c.l"
#define INITIAL 0

#define comment 1

#define string 2

#define stringwait 3

#define longline 4

#line 24 "c.l"
#include <cflow.h>
#include <ctype.h>
#include <parser.h>

struct obstack string_stk;

int line_num;
char *filename;
char *canonical_filename;
YYSTYPE yylval;
unsigned input_file_count;

int ident ();
void update_loc ();
#define lex_error(msg) error_at_line(0, 0, filename, line_num, "%s", msg)

#line 607 "c.c"



#ifndef YY_SKIP_YYWRAP
#ifdef __cplusplus
extern "C" int yywrap YY_PROTO ((void));
#else
extern int yywrap YY_PROTO ((void));
#endif
#endif

#ifndef YY_NO_UNPUT
static void yyunput YY_PROTO ((int c, char *buf_ptr));
#endif

#ifndef yytext_ptr
static void yy_flex_strncpy YY_PROTO ((char *, yyconst char *, int));
#endif

#ifdef YY_NEED_STRLEN
static int yy_flex_strlen YY_PROTO ((yyconst char *));
#endif

#ifndef YY_NO_INPUT
#ifdef __cplusplus
static int yyinput YY_PROTO ((void));
#else
static int input YY_PROTO ((void));
#endif
#endif

#if YY_STACK_USED
static int yy_start_stack_ptr = 0;
static int yy_start_stack_depth = 0;
static int *yy_start_stack = 0;
#ifndef YY_NO_PUSH_STATE
static void yy_push_state YY_PROTO ((int new_state));
#endif
#ifndef YY_NO_POP_STATE
static void yy_pop_state YY_PROTO ((void));
#endif
#ifndef YY_NO_TOP_STATE
static int yy_top_state YY_PROTO ((void));
#endif

#else
#define YY_NO_PUSH_STATE 1
#define YY_NO_POP_STATE 1
#define YY_NO_TOP_STATE 1
#endif

#ifdef YY_MALLOC_DECL
YY_MALLOC_DECL
#else
#if __STDC__
#ifndef __cplusplus
#include <stdlib.h>
#endif
#else

#endif
#endif


#ifndef YY_READ_BUF_SIZE
#define YY_READ_BUF_SIZE 8192
#endif



#ifndef ECHO

#define ECHO (void) fwrite( yytext, yyleng, 1, yyout )
#endif


#ifndef YY_INPUT
#define YY_INPUT(buf,result,max_size) \
	if ( yy_current_buffer->yy_is_interactive ) \
		{ \
		int c = '*', n; \
		for ( n = 0; n < max_size && \
			     (c = getc( yyin )) != EOF && c != '\n'; ++n ) \
			buf[n] = (char) c; \
		if ( c == '\n' ) \
			buf[n++] = (char) c; \
		if ( c == EOF && ferror( yyin ) ) \
			YY_FATAL_ERROR( "input in flex scanner failed" ); \
		result = n; \
		} \
	else if ( ((result = fread( buf, 1, max_size, yyin )) == 0) \
		  && ferror( yyin ) ) \
		YY_FATAL_ERROR( "input in flex scanner failed" );
#endif


#ifndef yyterminate
#define yyterminate() return YY_NULL
#endif


#ifndef YY_START_STACK_INCR
#define YY_START_STACK_INCR 25
#endif


#ifndef YY_FATAL_ERROR
#define YY_FATAL_ERROR(msg) yy_fatal_error( msg )
#endif


#ifndef YY_DECL
#define YY_DECL int yylex YY_PROTO(( void ))
#endif


#ifndef YY_USER_ACTION
#define YY_USER_ACTION
#endif


#ifndef YY_BREAK
#define YY_BREAK break;
#endif

#define YY_RULE_SETUP \
	if ( yyleng > 0 ) \
		yy_current_buffer->yy_at_bol = \
				(yytext[yyleng - 1] == '\n'); \
	YY_USER_ACTION

YY_DECL
{
  register yy_state_type yy_current_state;
  register char *yy_cp = NULL, *yy_bp = NULL;
  register int yy_act;

#line 48 "c.l"


#line 764 "c.c"

  if (yy_init)
    {
      yy_init = 0;

#ifdef YY_USER_INIT
      YY_USER_INIT;
#endif

      if (!yy_start)
	yy_start = 1;

      if (!yyin)
	yyin = stdin;

      if (!yyout)
	yyout = stdout;

      if (!yy_current_buffer)
	yy_current_buffer = yy_create_buffer (yyin, YY_BUF_SIZE);

      yy_load_buffer_state ();
    }

  while (1)
    {
      yy_cp = yy_c_buf_p;


      *yy_cp = yy_hold_char;


      yy_bp = yy_cp;

      yy_current_state = yy_start;
      yy_current_state += YY_AT_BOL ();
    yy_match:
      do
	{
	  register YY_CHAR yy_c = yy_ec[YY_SC_TO_UI (*yy_cp)];
	  if (yy_accept[yy_current_state])
	    {
	      yy_last_accepting_state = yy_current_state;
	      yy_last_accepting_cpos = yy_cp;
	    }
	  while (yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state)
	    {
	      yy_current_state = (int) yy_def[yy_current_state];
	      if (yy_current_state >= 191)
		yy_c = yy_meta[(unsigned int) yy_c];
	    }
	  yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned int) yy_c];
	  ++yy_cp;
	}
      while (yy_base[yy_current_state] != 484);

    yy_find_action:
      yy_act = yy_accept[yy_current_state];
      if (yy_act == 0)
	{
	  yy_cp = yy_last_accepting_cpos;
	  yy_current_state = yy_last_accepting_state;
	  yy_act = yy_accept[yy_current_state];
	}

      YY_DO_BEFORE_ACTION;


    do_action:

      if (yy_flex_debug)
	{
	  if (yy_act == 0)
	    fprintf (stderr, "--scanner backing up\n");
	  else if (yy_act < 72)
	    fprintf (stderr, "--accepting rule at line %d (\"%s\")\n", yy_rule_linenum[yy_act], yytext);
	  else if (yy_act == 72)
	    fprintf (stderr, "--accepting default rule (\"%s\")\n", yytext);
	  else if (yy_act == 73)
	    fprintf (stderr, "--(end of buffer or a NUL)\n");
	  else
	    fprintf (stderr, "--EOF (start condition %d)\n", YY_START);
	}

      switch (yy_act)
	{
	case 0:

	  *yy_cp = yy_hold_char;
	  yy_cp = yy_last_accepting_cpos;
	  yy_current_state = yy_last_accepting_state;
	  goto yy_find_action;

	case 1:
	  YY_RULE_SETUP
#line 50 "c.l"
	    ++ line_num;
	  YY_BREAK case 2:YY_RULE_SETUP
#line 51 "c.l"
	    BEGIN (comment);
	  YY_BREAK case 3:YY_RULE_SETUP
#line 52 "c.l"
	   ;
	  YY_BREAK case 4:YY_RULE_SETUP
#line 53 "c.l"
	  ++ line_num;
	  YY_BREAK case 5:YY_RULE_SETUP
#line 54 "c.l"
	   ;
	  YY_BREAK case 6:YY_RULE_SETUP
#line 55 "c.l"
	  ++ line_num;
	  YY_BREAK case 7:YY_RULE_SETUP
#line 56 "c.l"
//	    BEGIN (INITIAL);
	  YY_BREAK case 8:
#line 59 "c.l"
	  case 9:YY_RULE_SETUP
#line 59 "c.l"
	  {
//	    update_loc ();
	  }
	  YY_BREAK case 10:YY_RULE_SETUP
#line 61 "c.l"
	  {
	    BEGIN (longline);
	    ++line_num;
	  }
	  YY_BREAK case 11:YY_RULE_SETUP
#line 62 "c.l"
	  ++ line_num;
	  YY_BREAK case 12:YY_RULE_SETUP
#line 63 "c.l"
	  ++ line_num;
	  YY_BREAK case 13:YY_RULE_SETUP
#line 64 "c.l"
	  {
	    BEGIN (INITIAL);
	    ++line_num;
	  }
	  YY_BREAK case 14:YY_RULE_SETUP
#line 66 "c.l"
	   ;
	  YY_BREAK case 15:YY_RULE_SETUP
#line 67 "c.l"
	    return EXTERN;
	  YY_BREAK case 16:YY_RULE_SETUP
#line 68 "c.l"
	    return STATIC;
	  YY_BREAK case 17:YY_RULE_SETUP
#line 69 "c.l"
	    return TYPEDEF;
	  YY_BREAK case 18:YY_RULE_SETUP
#line 70 "c.l"
	  {
	    yylval.str = "struct";
	    return STRUCT;
	  }
	  YY_BREAK case 19:YY_RULE_SETUP
#line 71 "c.l"
	  {
	    yylval.str = "union";
	    return STRUCT;
	  }
	  YY_BREAK case 20:YY_RULE_SETUP
#line 72 "c.l"
	  {
	    yylval.str = "enum";
	    return STRUCT;
	  }
	  YY_BREAK case 21:YY_RULE_SETUP
#line 73 "c.l"
	  YY_BREAK case 24:
	  case 25:
#line 83 "c.l"
	  case 26:
#line 84 "c.l"
	  case 27:
#line 85 "c.l"
	  case 30:
#line 88 "c.l"
	  case 32:
#line 90 "c.l"
	  case 33:
#line 91 "c.l"
	  case 34:
#line 92 "c.l"
	  case 35:
#line 93 "c.l"
	  case 36:
#line 94 "c.l"
	  case 37:
#line 95 "c.l"
	  case 38:
#line 96 "c.l"
	  case 39:
#line 97 "c.l"
	  case 40:
#line 98 "c.l"
	  case 41:
#line 99 "c.l"
	  case 42:
#line 100 "c.l"
	  case 43:
#line 101 "c.l"
	  case 44:
#line 102 "c.l"
	  case 45:YY_RULE_SETUP
#line 102 "c.l"
	    return OP;
	  YY_BREAK case 46:
#line 104 "c.l"
	  case 47:
#line 105 "c.l"
	  case 48:
#line 106 "c.l"
	  case 49:YY_RULE_SETUP
#line 106 "c.l"
	    return STRING;
	  YY_BREAK case 50:
#line 111 "c.l"
	  case 51:YY_RULE_SETUP
#line 111 "c.l"
	    return ident ();
	  YY_BREAK case 52:YY_RULE_SETUP
#line 112 "c.l"
	  {
	    obstack_grow (&string_stk, yytext, yyleng + 1);
	    yylval.str = obstack_finish (&string_stk);
	    return WORD;
	  }
	  YY_BREAK case 53:YY_RULE_SETUP
#line 116 "c.l"
	  {
	    yyless (yyleng - 1);
	    obstack_grow (&string_stk, yytext, yyleng + 1);
	    yylval.str = obstack_finish (&string_stk);
	    return WORD;
	  }
	  YY_BREAK case 54:
#line 121 "c.l"
	  case 55:
#line 122 "c.l"
	  case 56:YY_RULE_SETUP
#line 122 "c.l"
	  {
	    obstack_grow (&string_stk, yytext, yyleng + 1);
	    yylval.str = obstack_finish (&string_stk);
	    return WORD;
	  }
	  YY_BREAK case 57:YY_RULE_SETUP
#line 135 "c.l"
	    BEGIN (string);
	  YY_BREAK case 58:YY_RULE_SETUP
#line 136 "c.l"
	   ;
	  YY_BREAK case 59:YY_RULE_SETUP
#line 137 "c.l"
	  {
	    ++line_num;
	    lex_error (_("unterminated string?"));
	  }
	  YY_BREAK case 60:YY_RULE_SETUP
#line 138 "c.l"
	   ;
	  YY_BREAK case 61:YY_RULE_SETUP
#line 139 "c.l"
	  ++ line_num;
	  YY_BREAK case 62:YY_RULE_SETUP
#line 140 "c.l"
	    BEGIN (stringwait);
	  YY_BREAK case 63:YY_RULE_SETUP
#line 141 "c.l"
	   ;
	  YY_BREAK case 64:YY_RULE_SETUP
#line 142 "c.l"
	  ++ line_num;
	  YY_BREAK case 65:YY_RULE_SETUP
#line 143 "c.l"
	    BEGIN (string);
	  YY_BREAK case 66:YY_RULE_SETUP
#line 144 "c.l"
	  {
	    BEGIN (INITIAL);
	    yyless (0);
	    return STRING;
	  }
	  YY_BREAK case 67:YY_RULE_SETUP
#line 149 "c.l"
	  ++ line_num;
	  YY_BREAK case 68:YY_RULE_SETUP
#line 150 "c.l"
	   ;
	  YY_BREAK case 69:YY_RULE_SETUP
#line 152 "c.l"
	    return LBRACE0;
	  YY_BREAK case 70:YY_RULE_SETUP
#line 153 "c.l"
	    return RBRACE0;
	  YY_BREAK case 71:YY_RULE_SETUP
#line 154 "c.l"
	    return yytext[0];
	  YY_BREAK case 72:YY_RULE_SETUP
#line 155 "c.l"
	    ECHO;
	  YY_BREAK
#line 1169 "c.c"
	case YY_STATE_EOF (INITIAL):
	case YY_STATE_EOF (comment):
	case YY_STATE_EOF (string):
	case YY_STATE_EOF (stringwait):
	case YY_STATE_EOF (longline):
	  yyterminate ();

	case YY_END_OF_BUFFER:
	  {

	    int yy_amount_of_matched_text = (int) (yy_cp - yytext_ptr) - 1;


	    *yy_cp = yy_hold_char;
	    YY_RESTORE_YY_MORE_OFFSET if (yy_current_buffer->yy_buffer_status == YY_BUFFER_NEW)
	      {

		yy_n_chars = yy_current_buffer->yy_n_chars;
		yy_current_buffer->yy_input_file = yyin;
		yy_current_buffer->yy_buffer_status = YY_BUFFER_NORMAL;
	      }


	    if (yy_c_buf_p <= &yy_current_buffer->yy_ch_buf[yy_n_chars])
	      {
		yy_state_type yy_next_state;

		yy_c_buf_p = yytext_ptr + yy_amount_of_matched_text;

		yy_current_state = yy_get_previous_state ();



		yy_next_state = yy_try_NUL_trans (yy_current_state);

		yy_bp = yytext_ptr + YY_MORE_ADJ;

		if (yy_next_state)
		  {

		    yy_cp = ++yy_c_buf_p;
		    yy_current_state = yy_next_state;
		    goto yy_match;
		  }

		else
		  {
		    yy_cp = yy_c_buf_p;
		    goto yy_find_action;
		  }
	      }

	    else
	      switch (yy_get_next_buffer ())
		{
		case EOB_ACT_END_OF_FILE:
		  {
		    yy_did_buffer_switch_on_eof = 0;

		    if (yywrap ())
		      {

			yy_c_buf_p = yytext_ptr + YY_MORE_ADJ;

			yy_act = YY_STATE_EOF (YY_START);
			goto do_action;
		      }

		    else
		      {
			if (!yy_did_buffer_switch_on_eof)
			  YY_NEW_FILE;
		      }
		    break;
		  }

		case EOB_ACT_CONTINUE_SCAN:
		  yy_c_buf_p = yytext_ptr + yy_amount_of_matched_text;

		  yy_current_state = yy_get_previous_state ();

		  yy_cp = yy_c_buf_p;
		  yy_bp = yytext_ptr + YY_MORE_ADJ;
		  goto yy_match;

		case EOB_ACT_LAST_MATCH:
		  yy_c_buf_p = &yy_current_buffer->yy_ch_buf[yy_n_chars];

		  yy_current_state = yy_get_previous_state ();

		  yy_cp = yy_c_buf_p;
		  yy_bp = yytext_ptr + YY_MORE_ADJ;
		  goto yy_find_action;
		}
	    break;
	  }

	default:
	  YY_FATAL_ERROR ("fatal flex scanner internal error--no action found");
	}
    }
}




static int yy_get_next_buffer ()
{
  register char *dest = yy_current_buffer->yy_ch_buf;
  register char *source = yytext_ptr;
  register int number_to_move, i;
  int ret_val;

  if (yy_c_buf_p > &yy_current_buffer->yy_ch_buf[yy_n_chars + 1])
    YY_FATAL_ERROR ("fatal flex scanner internal error--end of buffer missed");

  if (yy_current_buffer->yy_fill_buffer == 0)
    {
      if (yy_c_buf_p - yytext_ptr - YY_MORE_ADJ == 1)
	{

	  return EOB_ACT_END_OF_FILE;
	}

      else
	{

	  return EOB_ACT_LAST_MATCH;
	}
    }




  number_to_move = (int) (yy_c_buf_p - yytext_ptr) - 1;

  for (i = 0; i < number_to_move; ++i)
    *(dest++) = *(source++);

  if (yy_current_buffer->yy_buffer_status == YY_BUFFER_EOF_PENDING)

    yy_current_buffer->yy_n_chars = yy_n_chars = 0;

  else
    {
      int num_to_read = yy_current_buffer->yy_buf_size - number_to_move - 1;

      while (num_to_read <= 0)
	{
#ifdef YY_USES_REJECT
	  YY_FATAL_ERROR ("input buffer overflow, can't enlarge buffer because scanner uses REJECT");
#else


	  YY_BUFFER_STATE b = yy_current_buffer;

	  int yy_c_buf_p_offset = (int) (yy_c_buf_p - b->yy_ch_buf);

	  if (b->yy_is_our_buffer)
	    {
	      int new_size = b->yy_buf_size * 2;

	      if (new_size <= 0)
		b->yy_buf_size += b->yy_buf_size / 8;
	      else
		b->yy_buf_size *= 2;

	      b->yy_ch_buf = (char *) yy_flex_realloc ((void *) b->yy_ch_buf, b->yy_buf_size + 2);
	    }
	  else

	    b->yy_ch_buf = 0;

	  if (!b->yy_ch_buf)
	    YY_FATAL_ERROR ("fatal error - scanner input buffer overflow");

	  yy_c_buf_p = &b->yy_ch_buf[yy_c_buf_p_offset];

	  num_to_read = yy_current_buffer->yy_buf_size - number_to_move - 1;
#endif
	}

      if (num_to_read > YY_READ_BUF_SIZE)
	num_to_read = YY_READ_BUF_SIZE;


      YY_INPUT ((&yy_current_buffer->yy_ch_buf[number_to_move]), yy_n_chars, num_to_read);

      yy_current_buffer->yy_n_chars = yy_n_chars;
    }

  if (yy_n_chars == 0)
    {
      if (number_to_move == YY_MORE_ADJ)
	{
	  ret_val = EOB_ACT_END_OF_FILE;
	  yyrestart (yyin);
	}

      else
	{
	  ret_val = EOB_ACT_LAST_MATCH;
	  yy_current_buffer->yy_buffer_status = YY_BUFFER_EOF_PENDING;
	}
    }

}




static yy_state_type yy_get_previous_state ()
{
  register yy_state_type yy_current_state;
  register char *yy_cp;

  yy_current_state = yy_start;
  yy_current_state += YY_AT_BOL ();

  for (yy_cp = yytext_ptr + YY_MORE_ADJ; yy_cp < yy_c_buf_p; ++yy_cp)
    {
      register YY_CHAR yy_c = (*yy_cp ? yy_ec[YY_SC_TO_UI (*yy_cp)] : 1);
      if (yy_accept[yy_current_state])
	{
	  yy_last_accepting_state = yy_current_state;
	  yy_last_accepting_cpos = yy_cp;
	}
      while (yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state)
	{
	  yy_current_state = (int) yy_def[yy_current_state];
	  if (yy_current_state >= 191)
	    yy_c = yy_meta[(unsigned int) yy_c];
	}
      yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned int) yy_c];
    }

  return yy_current_state;
}




#ifdef YY_USE_PROTOS
static yy_state_type yy_try_NUL_trans (yy_state_type yy_current_state)
#else
static yy_state_type yy_try_NUL_trans (yy_current_state)
     yy_state_type yy_current_state;
#endif
{
  register int yy_is_jam;
  register char *yy_cp = yy_c_buf_p;

  register YY_CHAR yy_c = 1;
  if (yy_accept[yy_current_state])
    {
      yy_last_accepting_state = yy_current_state;
      yy_last_accepting_cpos = yy_cp;
    }


  return yy_is_jam ? 0 : yy_current_state;
}


#ifndef YY_NO_UNPUT
#ifdef YY_USE_PROTOS
static void yyunput (int c, register char *yy_bp)
#else
static void yyunput (c, yy_bp)
     int c;
     register char *yy_bp;
#endif
{
  register char *yy_cp = yy_c_buf_p;


  *yy_cp = yy_hold_char;

  if (yy_cp < yy_current_buffer->yy_ch_buf + 2)
    {

      register int number_to_move = yy_n_chars + 2;
      register char *dest = &yy_current_buffer->yy_ch_buf[yy_current_buffer->yy_buf_size + 2];
      register char *source = &yy_current_buffer->yy_ch_buf[number_to_move];

      while (source > yy_current_buffer->yy_ch_buf)
	*--dest = *--source;

      yy_cp += (int) (dest - source);
      yy_bp += (int) (dest - source);
      yy_current_buffer->yy_n_chars = yy_n_chars = yy_current_buffer->yy_buf_size;

      if (yy_cp < yy_current_buffer->yy_ch_buf + 2)
	YY_FATAL_ERROR ("flex scanner push-back overflow");
    }

  *--yy_cp = (char) c;


  yytext_ptr = yy_bp;
  yy_hold_char = *yy_cp;
  yy_c_buf_p = yy_cp;
}
#endif


#ifndef YY_NO_INPUT
#ifdef __cplusplus
static int yyinput ()
#else
static int input ()
#endif
{
  int c;

  *yy_c_buf_p = yy_hold_char;

  if (*yy_c_buf_p == YY_END_OF_BUFFER_CHAR)
    {

      if (yy_c_buf_p < &yy_current_buffer->yy_ch_buf[yy_n_chars])

	*yy_c_buf_p = '\0';

      else
	{
	  int offset = yy_c_buf_p - yytext_ptr;
	  ++yy_c_buf_p;

	  switch (yy_get_next_buffer ())
	    {
	    case EOB_ACT_LAST_MATCH:



	      yyrestart (yyin);



	    case EOB_ACT_END_OF_FILE:
	      {
		if (yywrap ())
		  return EOF;

		if (!yy_did_buffer_switch_on_eof)
		  YY_NEW_FILE;
#ifdef __cplusplus
		return yyinput ();
#else
		return input ();
#endif
	      }

	    case EOB_ACT_CONTINUE_SCAN:
	      yy_c_buf_p = yytext_ptr + offset;
	      break;
	    }
	}
    }

  c = *(unsigned char *) yy_c_buf_p;
  *yy_c_buf_p = '\0';
  yy_hold_char = *++yy_c_buf_p;

  yy_current_buffer->yy_at_bol = (c == '\n');

  return c;
}
#endif

#ifdef YY_USE_PROTOS
void yyrestart (FILE * input_file)
#else
void yyrestart (input_file)
     FILE *input_file;
#endif
{
  if (!yy_current_buffer)
    yy_current_buffer = yy_create_buffer (yyin, YY_BUF_SIZE);

  yy_init_buffer (yy_current_buffer, input_file);
  yy_load_buffer_state ();
}


#ifdef YY_USE_PROTOS
void yy_switch_to_buffer (YY_BUFFER_STATE new_buffer)
#else
void yy_switch_to_buffer (new_buffer)
     YY_BUFFER_STATE new_buffer;
#endif
{
  if (yy_current_buffer == new_buffer)
    return;

  if (yy_current_buffer)
    {

      *yy_c_buf_p = yy_hold_char;
      yy_current_buffer->yy_buf_pos = yy_c_buf_p;
      yy_current_buffer->yy_n_chars = yy_n_chars;
    }

  yy_current_buffer = new_buffer;
  yy_load_buffer_state ();


  yy_did_buffer_switch_on_eof = 1;
}


#ifdef YY_USE_PROTOS
void yy_load_buffer_state (void)
#else
void yy_load_buffer_state ()
#endif
{
  yy_n_chars = yy_current_buffer->yy_n_chars;
  yytext_ptr = yy_c_buf_p = yy_current_buffer->yy_buf_pos;
  yyin = yy_current_buffer->yy_input_file;
  yy_hold_char = *yy_c_buf_p;
}


#ifdef YY_USE_PROTOS
YY_BUFFER_STATE yy_create_buffer (FILE * file, int size)
#else
YY_BUFFER_STATE yy_create_buffer (file, size)
     FILE *file;
     int size;
#endif
{
  YY_BUFFER_STATE b;

  b = (YY_BUFFER_STATE) yy_flex_alloc (sizeof (struct yy_buffer_state));
  if (!b)
    YY_FATAL_ERROR ("out of dynamic memory in yy_create_buffer()");

  b->yy_buf_size = size;


  b->yy_ch_buf = (char *) yy_flex_alloc (b->yy_buf_size + 2);
  if (!b->yy_ch_buf)
    YY_FATAL_ERROR ("out of dynamic memory in yy_create_buffer()");

  b->yy_is_our_buffer = 1;

  yy_init_buffer (b, file);

  return b;
}


#ifdef YY_USE_PROTOS
void yy_delete_buffer (YY_BUFFER_STATE b)
#else
void yy_delete_buffer (b)
     YY_BUFFER_STATE b;
#endif
{
  if (!b)
    return;

  if (b == yy_current_buffer)
    yy_current_buffer = (YY_BUFFER_STATE) 0;

  if (b->yy_is_our_buffer)
    yy_flex_free ((void *) b->yy_ch_buf);

  yy_flex_free ((void *) b);
}



#ifdef YY_USE_PROTOS
void yy_init_buffer (YY_BUFFER_STATE b, FILE * file)
#else
void yy_init_buffer (b, file)
     YY_BUFFER_STATE b;
     FILE *file;
#endif


{
  yy_flush_buffer (b);

  b->yy_input_file = file;
  b->yy_fill_buffer = 1;

#if YY_ALWAYS_INTERACTIVE
  b->yy_is_interactive = 1;
#else
#if YY_NEVER_INTERACTIVE
  b->yy_is_interactive = 0;
#else
  b->yy_is_interactive = file ? (isatty (fileno (file)) > 0) : 0;
#endif
#endif
}


#ifdef YY_USE_PROTOS
void yy_flush_buffer (YY_BUFFER_STATE b)
#else
void yy_flush_buffer (b)
     YY_BUFFER_STATE b;
#endif

{
  if (!b)
    return;

  b->yy_n_chars = 0;


  b->yy_ch_buf[0] = YY_END_OF_BUFFER_CHAR;
  b->yy_ch_buf[1] = YY_END_OF_BUFFER_CHAR;

  b->yy_buf_pos = &b->yy_ch_buf[0];

  b->yy_at_bol = 1;
  b->yy_buffer_status = YY_BUFFER_NEW;

  if (b == yy_current_buffer)
    yy_load_buffer_state ();
}


#ifndef YY_NO_SCAN_BUFFER
#ifdef YY_USE_PROTOS
YY_BUFFER_STATE yy_scan_buffer (char *base, yy_size_t size)
#else
YY_BUFFER_STATE yy_scan_buffer (base, size)
     char *base;
     yy_size_t size;
#endif
{
  YY_BUFFER_STATE b;

  if (size < 2 || base[size - 2] != YY_END_OF_BUFFER_CHAR || base[size - 1] != YY_END_OF_BUFFER_CHAR)

    return 0;

  b = (YY_BUFFER_STATE) yy_flex_alloc (sizeof (struct yy_buffer_state));
  if (!b)
    YY_FATAL_ERROR ("out of dynamic memory in yy_scan_buffer()");

  b->yy_buf_size = size - 2;
  b->yy_buf_pos = b->yy_ch_buf = base;
  b->yy_is_our_buffer = 0;
  b->yy_input_file = 0;
  b->yy_n_chars = b->yy_buf_size;
  b->yy_is_interactive = 0;
  b->yy_at_bol = 1;
  b->yy_fill_buffer = 0;
  b->yy_buffer_status = YY_BUFFER_NEW;

  yy_switch_to_buffer (b);

  return b;
}
#endif


#ifndef YY_NO_SCAN_STRING
#ifdef YY_USE_PROTOS
YY_BUFFER_STATE yy_scan_string (yyconst char *yy_str)
#else
YY_BUFFER_STATE yy_scan_string (yy_str)
     yyconst char *yy_str;
#endif
{
  int len;
  for (len = 0; yy_str[len]; ++len)
    ;

  return yy_scan_bytes (yy_str, len);
}
#endif


#ifndef YY_NO_SCAN_BYTES
#ifdef YY_USE_PROTOS
YY_BUFFER_STATE yy_scan_bytes (yyconst char *bytes, int len)
#else
YY_BUFFER_STATE yy_scan_bytes (bytes, len)
     yyconst char *bytes;
     int len;
#endif
{
  YY_BUFFER_STATE b;
  char *buf;
  yy_size_t n;
  int i;


  n = len + 2;
  buf = (char *) yy_flex_alloc (n);
  if (!buf)
    YY_FATAL_ERROR ("out of dynamic memory in yy_scan_bytes()");

  for (i = 0; i < len; ++i)
    buf[i] = bytes[i];

  buf[len] = buf[len + 1] = YY_END_OF_BUFFER_CHAR;

  b = yy_scan_buffer (buf, n);
  if (!b)
    YY_FATAL_ERROR ("bad buffer in yy_scan_bytes()");


  b->yy_is_our_buffer = 1;

  return b;
}
#endif


#ifndef YY_NO_PUSH_STATE
#ifdef YY_USE_PROTOS
static void yy_push_state (int new_state)
#else
static void yy_push_state (new_state)
     int new_state;
#endif
{
  if (yy_start_stack_ptr >= yy_start_stack_depth)
    {
      yy_size_t new_size;

      yy_start_stack_depth += YY_START_STACK_INCR;
      new_size = yy_start_stack_depth * sizeof (int);

      if (!yy_start_stack)
	yy_start_stack = (int *) yy_flex_alloc (new_size);

      else
	yy_start_stack = (int *) yy_flex_realloc ((void *) yy_start_stack, new_size);

      if (!yy_start_stack)
	YY_FATAL_ERROR ("out of memory expanding start-condition stack");
    }

  yy_start_stack[yy_start_stack_ptr++] = YY_START;

  BEGIN (new_state);
}
#endif


#ifndef YY_NO_POP_STATE
static void yy_pop_state ()
{
  if (--yy_start_stack_ptr < 0)
    YY_FATAL_ERROR ("start-condition stack underflow");

  BEGIN (yy_start_stack[yy_start_stack_ptr]);
}
#endif


#ifndef YY_NO_TOP_STATE
static int yy_top_state ()
{
  return yy_start_stack[yy_start_stack_ptr - 1];
}
#endif

#ifndef YY_EXIT_FAILURE
#define YY_EXIT_FAILURE 2
#endif

#ifdef YY_USE_PROTOS
static void yy_fatal_error (yyconst char msg[])
#else
static void yy_fatal_error (msg)
     char msg[];
#endif
{
  (void) fprintf (stderr, "%s\n", msg);
  exit (YY_EXIT_FAILURE);
}





#undef yyless
#define yyless(n) \
	do \
		{ \
		 \
		yytext[yyleng] = yy_hold_char; \
		yy_c_buf_p = yytext + n; \
		yy_hold_char = *yy_c_buf_p; \
		*yy_c_buf_p = '\0'; \
		yyleng = n; \
		} \
	while ( 0 )




#ifndef yytext_ptr
#ifdef YY_USE_PROTOS
static void yy_flex_strncpy (char *s1, yyconst char *s2, int n)
#else
static void yy_flex_strncpy (s1, s2, n)
     char *s1;
     yyconst char *s2;
     int n;
#endif
{
  register int i;
  for (i = 0; i < n; ++i)
    s1[i] = s2[i];
}
#endif

#ifdef YY_NEED_STRLEN
#ifdef YY_USE_PROTOS
static int yy_flex_strlen (yyconst char *s)
#else
static int yy_flex_strlen (s)
     yyconst char *s;
#endif
{
  register int n;
  for (n = 0; s[n]; ++n)
    ;

  return n;
}
#endif


#ifdef YY_USE_PROTOS
static void *yy_flex_alloc (yy_size_t size)
#else
static void *yy_flex_alloc (size)
     yy_size_t size;
#endif
{
  return (void *) malloc (size);
}

#ifdef YY_USE_PROTOS
static void *yy_flex_realloc (void *ptr, yy_size_t size)
#else
static void *yy_flex_realloc (ptr, size)
     void *ptr;
     yy_size_t size;
#endif
{

  return (void *) realloc ((char *) ptr, size);
}

#ifdef YY_USE_PROTOS
static void yy_flex_free (void *ptr)
#else
static void yy_flex_free (ptr)
     void *ptr;
#endif
{
  free (ptr);
}

#if YY_MAIN
int main ()
{
  yylex ();
  return 0;
}
#endif
#line 155 "c.l"


static char *keywords[] = {
  "break",
  "case",
  "continue",
  "default",
  "do",
  "else",
  "for",
  "goto",
  "if",
  "return",
  "sizeof",
  "switch",
  "while"
};

static char *types[] = {
  "char",
  "const",
  "double",
  "float",
  "int",
  "long",
  "register",
  "restrict",
  "short",
  "signed",
  "unsigned",
  "void",
  "volatile",
};

void init_lex (int debug_level)
{
  int i;
  Symbol *sp;

  yy_flex_debug = debug_level;

  obstack_init (&string_stk);

  for (i = 0; i < NUMITEMS (keywords); i++)
    {
      sp = install (keywords[i]);
      sp->type = SymToken;
      sp->token_type = WORD;
    }

  for (i = 0; i < NUMITEMS (types); i++)
    {
      sp = install (types[i]);
      sp->type = SymToken;
      sp->token_type = TYPE;
      sp->source = NULL;
      sp->def_line = -1;
      sp->ref_line = NULL;
    }
  sp = install ("...");
  sp->type = SymToken;
  sp->token_type = IDENTIFIER;
  sp->source = NULL;
  sp->def_line = -1;
  sp->ref_line = NULL;
}

int ident ()
{
  Symbol *sp;

  sp = lookup (yytext);
  if (sp && sp->type == SymToken)
    {
      yylval.str = sp->name;
      return sp->token_type;
    }
  obstack_grow (&string_stk, yytext, yyleng);
  obstack_1grow (&string_stk, 0);
  yylval.str = obstack_finish (&string_stk);
  return IDENTIFIER;
}



char *pp_bin;
char *pp_opts;
static struct obstack *opt_stack;

void set_preprocessor (const char *arg)
{
  pp_bin = arg ? xstrdup (arg) : NULL;
}

void pp_option (const char *arg)
{
  if (!opt_stack)
    {
      if (!pp_bin)
	pp_bin = CFLOW_PREPROC;
      opt_stack = xmalloc (sizeof *opt_stack);
      obstack_init (opt_stack);
    }
  obstack_1grow (opt_stack, ' ');
  obstack_grow (opt_stack, arg, strlen (arg));
}

void pp_finalize ()
{
  char *s = obstack_finish (opt_stack);
  if (!pp_opts)
    pp_opts = xstrdup (s);
  else
    {
      pp_opts = xrealloc (pp_opts, strlen (pp_opts) + strlen (s) + 1);
      strcat (pp_opts, s);
    }
  obstack_free (opt_stack, s);
  free (opt_stack);
  opt_stack = NULL;
}

FILE *pp_open (const char *name)
{
  FILE *fp;
  char *s;
  size_t size;

  if (opt_stack)
    pp_finalize ();
  size = strlen (pp_bin) + 1 + strlen (name) + 1;
  if (pp_opts)
    size += strlen (pp_opts);
  s = xmalloc (size);
  strcpy (s, pp_bin);
  if (pp_opts)
    strcat (s, pp_opts);
  strcat (s, " ");
  strcat (s, name);
  if (debug)
    printf (_("Command line: %s\n"), s);
  fp = popen (s, "r");
  if (!fp)
    error (0, errno, _("cannot execute `%s'"), s);
  free (s);
  return fp;
}

void pp_close (FILE * fp)
{
  pclose (fp);
}



int yywrap ()
{
  if (!yyin)
    return 1;
  if (preprocess_option)
    pp_close (yyin);
  else
    fclose (yyin);
  yyin = NULL;
#ifdef FLEX_SCANNER
  yy_delete_buffer (yy_current_buffer);
#endif
  delete_statics ();
  return 1;
}

int get_token ()
{
  return yyin ? yylex () : 0;
}

int source (char *name)
{
  FILE *fp;

  fp = fopen (name, "r");
  if (!fp)
    {
      error (0, errno, _("cannot open `%s'"), name);
      return 1;
    }
  if (preprocess_option)
    {
      fclose (fp);
      fp = pp_open (name);
      if (!fp)
	return 1;
    }
  obstack_grow (&string_stk, name, strlen (name) + 1);
  filename = obstack_finish (&string_stk);
  canonical_filename = filename;
  line_num = 1;
  input_file_count++;

  yyrestart (fp);
  return 0;
}

static int getnum (unsigned base, int count)
{
  int c, n;
  unsigned i;

  for (n = 0; count; count--)
    {
      if (isdigit (c = input ()))
	i = c - '0';
      else
	i = toupper (c) - 'A' + 10;
      if (i > base)
	{
	  unput (c);
	  break;
	}
      n = n * base + i;
    }
  return n;
}

int backslash ()
{
  int c;

  switch (c = input ())
    {
    case 'a':
      return '\a';
    case 'b':
      return '\b';
    case 'f':
      return '\f';
    case 'n':
      return '\n';
    case 'r':
      return '\r';
    case 't':
      return '\t';
    case 'x':
      return getnum (16, 2);
    case '0':
      return getnum (8, 3);
    }
  return c;
}

void update_loc ()
{
  char *p;

  for (p = strchr (yytext, '#') + 1; *p && isspace (*p); p++)
    ;
  if (p[0] == 'l')
    p += 4;

  line_num = strtoul (p, &p, 10);
  for (; *p && isspace (*p); p++)
    ;
  if (p[0] == '"')
    {
      int n;

      for (p++, n = 0; p[n] && p[n] != '"'; n++)
	;
      obstack_grow (&string_stk, p, n);
      obstack_1grow (&string_stk, 0);
      filename = obstack_finish (&string_stk);
    }
  if (debug > 1)
    printf (_("New location: %s:%d\n"), filename, line_num);
}
