#include <assert.h>








#include <cflow.h>

void print_function_name (Symbol * sym, int has_subtree)
{
  fprintf (outfile, "%s", sym->name);
  if (sym->arity >= 0)
    fprintf (outfile, "()");
  if (sym->decl)
    fprintf (outfile, " <%s at %s:%d>", sym->decl, sym->source, sym->def_line);
  if (sym->active)
    {
      fprintf (outfile, " (recursive: see %d)", sym->active - 1);
      return;
    }
  if (sym->recursive)
    fprintf (outfile, " (R)");
  if (!print_as_tree && has_subtree)
    fprintf (outfile, ":");
}


static int print_symbol (FILE * outfile, int line, struct output_symbol *s)
{
  int has_subtree = s->direct ? s->sym->callee != NULL : s->sym->caller != NULL;

  print_level (s->level, s->last);
  print_function_name (s->sym, has_subtree);

  if (brief_listing)
    {
      ;
    }
  return 0;
}

int gnu_output_handler (cflow_output_command cmd, FILE * outfile, int line, void *data, void *handler_data)
{
  switch (cmd)
    {
    case cflow_output_begin:
      if (emacs_option)
	{
          ;
          ;
	}
      break;
    case cflow_output_init:
    case cflow_output_end:
    case cflow_output_separator:
      break;
    case cflow_output_newline:
      fprintf (outfile, "\n");
      break;
    case cflow_output_text:
      ;
      ;
    case cflow_output_symbol:
      return print_symbol (outfile, line, data);
    }
  return 0;
}


