#include <assert.h>








#include <cflow.h>
#include <parser.h>

typedef struct
{
  char *name;
  int type_end;
  int parmcnt;
  int line;
  enum storage storage;
} Ident;

void parse_declaration (Ident *, int);
void parse_variable_declaration (Ident *, int);
void parse_function_declaration (Ident *, int);
void parse_dcl (Ident *, int maybe_knr);
void parse_knr_dcl (Ident *);
void parse_typedef ();
void expression ();
void initializer_list ();
void func_body ();
void declare (Ident *, int maybe_knr);
void declare_type (Ident *);
int dcl (Ident *);
int parmdcl (Ident *);
int dirdcl (Ident *);
void skip_struct ();
Symbol *get_symbol (char *name);
void maybe_parm_list (int *parm_cnt_return);

void call (char *, int);
void reference (char *, int);

int level;
Symbol *caller;
struct obstack text_stk;

int parm_level;

typedef struct
{
  int type;
  char *token;
  int line;
} TOKSTK;

typedef int Stackpos[1];

TOKSTK tok;
TOKSTK *token_stack;
int tos;
int curs;
int token_stack_length = 64;
int token_stack_increase = 32;
static int need_space;

void mark (Stackpos);
void restore (Stackpos);
void tokpush (int, int, char *);
void save_token (TOKSTK *);

static void print_token (TOKSTK * tokptr)
{
  switch (tokptr->type)
    {
    case IDENTIFIER:
    case TYPE:
    case WORD:
    case MODIFIER:
    case STRUCT:
      fprintf (stderr, "`%s'", tokptr->token);
      break;
    case LBRACE0:
    case LBRACE:
      ;
      ;
    case RBRACE0:
    case RBRACE:
      ;
      ;
    case EXTERN:
      ;
      ;
    case STATIC:
      ;
      ;
    case TYPEDEF:
      ;
      ;
    case OP:
      ;
      ;
    default:
      ;
    }
}

static void file_error (char *msg, int near)
{
  fprintf (stderr, "%s:%d: %s", filename, tok.line, msg);
  if (near)
    {
      fprintf (stderr, _(" near "));
      print_token (&tok);
    }
  fprintf (stderr, "\n");
}

void mark (Stackpos pos)
{
  pos[0] = curs;
}

void restore (Stackpos pos)
{
  curs = pos[0];
  if (curs)
    tok = token_stack[curs - 1];
}

void tokpush (int type, int line, char *token)
{
  token_stack[tos].type = type;
  token_stack[tos].token = token;
  token_stack[tos].line = line;
  if (++tos == token_stack_length)
    {
      ;
      ;
    }
}

void cleanup_stack ()
{
  int delta = tos - curs;

  if (delta)
    ;

  tos = delta;
  curs = 0;
}

void clearstack ()
{
  tos = curs = 0;
}

int nexttoken ()
{
  int type;

  if (curs == tos)
    {
      type = get_token ();
      tokpush (type, line_num, yylval.str);
    }
  tok = token_stack[curs];
  curs++;
  return tok.type;
}

int putback ()
{
  if (curs == 0)
    ;
  curs--;
  if (curs > 0)
    {
      tok.type = token_stack[curs - 1].type;
      tok.token = token_stack[curs - 1].token;
    }
  else
    tok.type = 0;
  return tok.type;
}

void init_parse ()
{
  obstack_init (&text_stk);
  token_stack = xmalloc (token_stack_length * sizeof (*token_stack));
  clearstack ();
}

void save_token (TOKSTK * tokptr)
{
  int len;

  switch (tokptr->type)
    {
    case IDENTIFIER:
    case TYPE:
    case STRUCT:
    case PARM_WRAPPER:
    case WORD:
      if (need_space)
	obstack_1grow (&text_stk, ' ');
      len = strlen (tokptr->token);
      obstack_grow (&text_stk, tokptr->token, len);
      need_space = 1;
      break;
    case MODIFIER:
      if (need_space)
	obstack_1grow (&text_stk, ' ');
      if (tokptr->token[0] == '*')
	need_space = 0;
      else
        ;
      len = strlen (tokptr->token);
      obstack_grow (&text_stk, tokptr->token, len);
      break;
    case EXTERN:
    case STATIC:
      break;
    case '(':
      if (need_space)
	obstack_1grow (&text_stk, ' ');

    default:
      obstack_1grow (&text_stk, tokptr->type);
      need_space = 0;
    }
}

static Stackpos start_pos;
static int save_end;

void save_stack ()
{
  mark (start_pos);
  save_end = curs - 1;
}

void undo_save_stack ()
{
  save_end = -1;
}

char *finish_save_stack (char *name)
{
  int i;
  int level = 0;
  int found_ident = !omit_symbol_names_option;

  need_space = 0;
  for (i = 0; i < save_end; i++)
    {
      switch (token_stack[i].type)
	{
	case '(':
	  if (omit_arguments_option)
	    {
              ;
	    }
	  break;
	case ')':
	  if (omit_arguments_option)
            ;
	  break;
	case IDENTIFIER:
	  if (!found_ident && strcmp (name, token_stack[i].token) == 0)
	    {
              ;
              ;
              ;
	    }
	}
      if (level == 0)
	save_token (token_stack + i);
    }
  obstack_1grow (&text_stk, 0);
  return obstack_finish (&text_stk);
}

void skip_to (int c)
{
  while (nexttoken ())
    {
      if (tok.type == c)
	break;
    }
}

int yyparse ()
{
  Ident identifier;

  level = 0;
  caller = NULL;
  clearstack ();
  while (nexttoken ())
    {
      identifier.storage = ExternStorage;
      switch (tok.type)
	{
	case 0:
          ;
	case TYPEDEF:
          ;
          ;
	case EXTERN:
	  identifier.storage = ExplicitExternStorage;
	  parse_declaration (&identifier, 0);
	  break;
	case STATIC:
	  identifier.storage = StaticStorage;
	  nexttoken ();

	default:
	  parse_declaration (&identifier, 0);
	  break;
	}
      cleanup_stack ();
    }

}

static int is_function ()
{
  Stackpos sp;
  int res = 0;

  mark (sp);

  while (tok.type == TYPE || tok.type == IDENTIFIER || tok.type == MODIFIER || tok.type == STATIC || tok.type == EXTERN)
    nexttoken ();

  if (tok.type == '(')
    res = nexttoken () != MODIFIER;

  restore (sp);
  return res;
}

void parse_declaration (Ident * ident, int parm)
{
  if (is_function ())
    parse_function_declaration (ident, parm);
  else
    parse_variable_declaration (ident, parm);
  delete_parms (parm_level);
}


void expression ()
{
  char *name;
  int line;
  int parens_lev;

  parens_lev = 0;
  while (1)
    {
      switch (tok.type)
	{
	case ';':
	  return;
	case LBRACE:
	case LBRACE0:
	case RBRACE:
	case RBRACE0:
	  putback ();
	  return;
	case ',':
          ;
	case 0:
          ;
	case IDENTIFIER:
	  name = tok.token;
	  line = tok.line;
	  nexttoken ();
	  if (tok.type == '(')
	    {
	      call (name, line);
	      parens_lev++;
	    }
	  else
	    {
	      reference (name, line);
	      if (tok.type == MEMBER_OF)
		{
                  ;
		}
	      else
		{
		  putback ();
		}
	    }
	  break;
	case '(':

	  if (nexttoken () == TYPE)
            ;
	  else
	    {
	      putback ();
	      parens_lev++;
	    }
	  break;
	case ')':
	  parens_lev--;
	  break;
	}
      nexttoken ();
    }
}

void parse_function_declaration (Ident * ident, int parm)
{
  int error_recovery = 0;
  ident->type_end = -1;
  parse_knr_dcl (ident);

restart:
  switch (tok.type)
    {
    case ')':
      if (parm)
	break;

    default:
      if (error_recovery)
	nexttoken ();
      else
	{
	  if (verbose)
	    file_error (_("expected `;'"), 1);
	  error_recovery = 1;
	}
      goto restart;

    case ';':
    case ',':
      break;
    case LBRACE0:
    case LBRACE:
      if (ident->name)
	{
	  caller = lookup (ident->name);
	  func_body ();
	}
      break;
    case 0:
      ;
    }
}


void parse_variable_declaration (Ident * ident, int parm)
{
  Stackpos sp;

  mark (sp);
  ident->type_end = -1;
  if (tok.type == STRUCT)
    {
      if (nexttoken () == IDENTIFIER)
	{
          ;
	}
      putback ();
      skip_struct ();
      while (tok.type == MODIFIER)
        ;
      if (tok.type == IDENTIFIER)
	{
	  TOKSTK hold = tok;
	  restore (sp);
	  if (ident->type_end == -1)
	    {

	      tos = curs;
	      token_stack[curs].type = IDENTIFIER;
	      token_stack[curs].token = "{ ... }";
	      tos++;
	    }
	  else
	    {
              ;
	    }
	  tokpush (hold.type, hold.line, hold.token);
	}
      else
	{
          ;
	}
    }
again:
  parse_dcl (ident, 0);

select:
  switch (tok.type)
    {
    case ')':
      if (parm)
	break;

    default:
      ;
    case ';':
      break;
    case ',':
      if (parm)
	break;
      ;
      ;
      ;
    case '=':
      nexttoken ();
      if (tok.type == LBRACE || tok.type == LBRACE0)
	initializer_list ();
      else
	expression ();
      goto select;
      break;
    case LBRACE0:
    case LBRACE:
      ;
      ;
    case 0:
      ;
    }
}

void initializer_list ()
{
  int lev = 0;
  while (1)
    {
      switch (tok.type)
	{
	case LBRACE:
	case LBRACE0:
	  lev++;
	  break;
	case RBRACE:
	case RBRACE0:
	  if (--lev <= 0)
	    {
	      nexttoken ();
	      return;
	    }
          ;
	case 0:
          ;
          ;
	case ',':
          ;
	default:
	  expression ();
	  break;
	}
      nexttoken ();
    }
}

void parse_knr_dcl (Ident * ident)
{
  ident->type_end = -1;
  parse_dcl (ident, !strict_ansi);
}

void skip_struct ()
{
  int lev = 0;

  if (nexttoken () == IDENTIFIER)
    {
      ;
    }
  else if (tok.type == ';')
    ;

  if (tok.type == LBRACE || tok.type == LBRACE0)
    {
      do
	{
	  switch (tok.type)
	    {
	    case 0:
              ;
              ;
	    case LBRACE:
	    case LBRACE0:
	      lev++;
	      break;
	    case RBRACE:
	    case RBRACE0:
	      lev--;
	    }
	  nexttoken ();
	}
      while (lev);
    }
}


void parse_dcl (Ident * ident, int maybe_knr)
{
  ident->parmcnt = -1;
  ident->name = NULL;
  putback ();
  dcl (ident);
  save_stack ();
  if (ident->name)
    declare (ident, maybe_knr);
  else
    undo_save_stack ();
}

int dcl (Ident * idptr)
{
  int type;

  while (nexttoken () != 0 && tok.type != '(')
    {
      if (tok.type == MODIFIER)
	{
	  if (idptr && idptr->type_end == -1)
	    idptr->type_end = curs - 1;
	}
      else if (tok.type == IDENTIFIER)
	{
	  while (tok.type == IDENTIFIER)
	    nexttoken ();
	  type = tok.type;
	  putback ();
	  if (type == TYPE)
            ;
	  else if (type != MODIFIER)
	    break;
	}
      else if (tok.type == ')')
	{
	  return 1;
	}
    }
  if (idptr && idptr->type_end == -1)
    idptr->type_end = curs - 1;
  return dirdcl (idptr);
}

int dirdcl (Ident * idptr)
{
  int wrapper = 0;
  int *parm_ptr = NULL;

  if (tok.type == '(')
    {
      dcl (idptr);
      if (tok.type != ')' && verbose)
	{
          ;
          ;
	}
    }
  else if (tok.type == IDENTIFIER)
    {
      if (idptr)
	{
	  idptr->name = tok.token;
	  idptr->line = tok.line;
	  parm_ptr = &idptr->parmcnt;
	}
    }

  if (nexttoken () == PARM_WRAPPER)
    {
      wrapper = 1;
      nexttoken ();
    }
  else
    putback ();

  while (nexttoken () == '[' || tok.type == '(')
    {
      if (tok.type == '[')
	skip_to (']');
      else
	{
	  maybe_parm_list (parm_ptr);
	  if (tok.type != ')' && verbose)
	    {
              ;
              ;
	    }
	}
    }
  if (wrapper)
    nexttoken ();

  if (tok.type == PARM_WRAPPER)
    {
      if (nexttoken () == '(')
	{
	  int level = 0;
	  while (nexttoken ())
	    {
	      if (tok.type == 0)
		{
                  ;
                  ;
		}
	      else if (tok.type == '(')
		level++;
	      else if (tok.type == ')')
		{
		  if (level-- == 0)
		    {
		      nexttoken ();
		      break;
		    }
		}
	    }
	}
      else
        ;
    }
  return 0;
}



void maybe_parm_list (int *parm_cnt_return)
{
  int parmcnt = 0;
  Ident ident;
  int level;

  parm_level++;
  while (nexttoken ())
    {
      switch (tok.type)
	{
	case ')':
	  if (parm_cnt_return)
	    *parm_cnt_return = parmcnt;
	  parm_level--;
	  return;
	case ',':
	  break;
	case IDENTIFIER:
	case STRUCT:
	case UNION:
	case ENUM:
	case TYPE:
	  parmcnt++;
	  ident.storage = AutoStorage;
	  parse_declaration (&ident, 1);
	  putback ();
	  break;
	default:
          ;
	}
    }
  ;
}

void func_body ()
{
  Ident ident;

  level++;
  move_parms (level);
  while (level)
    {
      cleanup_stack ();
      nexttoken ();
      switch (tok.type)
	{
	default:
	  expression ();
	  break;
	case STATIC:
	  ident.storage = StaticStorage;
	  nexttoken ();
	  parse_variable_declaration (&ident, 0);
	  break;
	case TYPE:
	case STRUCT:
	  ident.storage = AutoStorage;
	  parse_variable_declaration (&ident, 0);
	  break;
	case EXTERN:
          ;
          ;
          ;
	case LBRACE0:
	case '{':
          ;
          ;
	case RBRACE0:
	  if (use_indentation)
	    {
              ;
	    }


	case '}':
	  delete_autos (level);
	  level--;
	  break;
	case 0:
          ;
	}
    }
}

int get_knr_args (Ident * ident)
{
  int parmcnt, stop;
  Stackpos sp, new_sp;
  Ident id;

  switch (tok.type)
    {
    case IDENTIFIER:
    case TYPE:
    case STRUCT:


      mark (sp);
      parmcnt = 0;

      for (stop = 0; !stop && parmcnt < ident->parmcnt; nexttoken ())
	{
	  id.type_end = -1;
	  switch (tok.type)
	    {
	    case LBRACE:
	    case LBRACE0:
              ;
              ;
              ;
	    case TYPE:
	    case IDENTIFIER:
	    case STRUCT:
	      putback ();
	      mark (new_sp);
	      if (dcl (&id) == 0)
		{
		  parmcnt++;
		  if (tok.type == ',')
		    {
		      do
			{
                          ;
                          ;
                          ;
			}
                      #define doWhileFAIL() (fprintf(stderr, "ABORTING at Do While!"),exit(1),0)
		      while (doWhileFAIL());
		    }
		  else if (tok.type != ';')
		    putback ();
		  break;
		}


	    default:
              ;
              ;
	    }
	}
    }
  return 0;
}

void declare (Ident * ident, int maybe_knr)
{
  Symbol *sp;

  if (ident->storage == AutoStorage)
    {
      undo_save_stack ();
      sp = install_ident (ident->name, ident->storage);
      if (parm_level)
	{
	  sp->level = parm_level;
	  sp->flag = symbol_parm;
	}
      else
	sp->level = level;
      sp->arity = -1;
      return;
    }

  if ((ident->parmcnt >= 0 && (!maybe_knr || get_knr_args (ident) == 0) && !(tok.type == LBRACE || tok.type == LBRACE0 || tok.type == TYPE)) || (ident->parmcnt < 0 && ident->storage == ExplicitExternStorage))
    {
      undo_save_stack ();

      return;
    }

  sp = get_symbol (ident->name);
  if (sp->source)
    {
      if (ident->storage == StaticStorage && (sp->storage != StaticStorage || level > 0))
	{
	  sp = install_ident (ident->name, ident->storage);
	}
      else
	{
          ;
          ;
	}
    }

  sp->type = SymIdentifier;
  sp->arity = ident->parmcnt;
  ident_change_storage (sp, (ident->storage == ExplicitExternStorage) ? ExternStorage : ident->storage);
  sp->decl = finish_save_stack (ident->name);
  sp->source = filename;
  sp->def_line = ident->line;
  sp->level = level;
  if (debug)
    ;
}


Symbol *get_symbol (char *name)
{
  Symbol *sp = lookup (name);

  if (sp)
    {
      for (; sp; sp = sp->next)
	{
	  if (sp->type == SymIdentifier && strcmp (sp->name, name) == 0)
	    break;
	}
      if (sp)
	return sp;
    }
  return install_ident (name, ExternStorage);
}

Symbol *add_reference (char *name, int line)
{
  Symbol *sp = get_symbol (name);
  Ref *refptr;

  if (sp->storage == AutoStorage || (sp->storage == StaticStorage && globals_only ()))
    return NULL;
  refptr = xmalloc (sizeof (*refptr));
  refptr->source = filename;
  refptr->line = line;
  if (!sp->ref_line)
    sp->ref_line = linked_list_create (free);
  linked_list_append (&sp->ref_line, refptr);
  return sp;
}


void call (char *name, int line)
{
  Symbol *sp;

  sp = add_reference (name, line);
  if (!sp)
    return;
  if (sp->arity < 0)
    sp->arity = 0;
  if (caller)
    {
      if (!data_in_list (caller, sp->caller))
	linked_list_append (&sp->caller, caller);
      if (!data_in_list (sp, caller->callee))
	linked_list_append (&caller->callee, sp);
    }
}

void reference (char *name, int line)
{
  Symbol *sp = add_reference (name, line);
  if (!sp)
    return;
  if (caller)
    {
      if (!data_in_list (caller, sp->caller))
	linked_list_append (&sp->caller, caller);
      if (!data_in_list (sp, caller->callee))
	linked_list_append (&caller->callee, sp);
    }
}


