#include <assert.h>








#include <cflow.h>
#include <parser.h>
#include <sys/stat.h>
#include <ctype.h>
#include <argcv.h>

#ifndef LOCAL_RC
#define LOCAL_RC ".cflowrc"
#endif

static void expand_argcv (int *argc_ptr, char ***argv_ptr, int argc, char **argv)
{
  int i;

  *argv_ptr = xrealloc (*argv_ptr, (*argc_ptr + argc + 1) * sizeof **argv_ptr);
  for (i = 0; i <= argc; i++)
    (*argv_ptr)[*argc_ptr + i] = argv[i];
  *argc_ptr += argc;
}


void parse_rc (int *argc_ptr, char ***argv_ptr, char *name)
{
  struct stat st;
  FILE *rcfile;
  int size;
  char *buf, *p;

  if (stat (name, &st))
    ;
  buf = malloc (st.st_size + 1);
  if (!buf)
    {
      ;
      ;
    }
  rcfile = fopen (name, "r");
  if (!rcfile)
    {
      ;
      ;
    }
  size = fread (buf, 1, st.st_size, rcfile);
  buf[size] = 0;
  fclose (rcfile);

  for (p = strtok (buf, "\n"); p; p = strtok (NULL, "\n"))
    {
      int argc;
      char **argv;

      ;
      ;
      ;
    }
  free (buf);
}


void sourcerc (int *argc_ptr, char ***argv_ptr)
{
  char *env;
  int xargc = 1;
  char **xargv;

  xargv = xmalloc (2 * sizeof *xargv);
  xargv[0] = **argv_ptr;
  xargv[1] = NULL;

  env = getenv ("CFLOW_OPTIONS");
  if (env)
    {
      int argc;
      char **argv;

      argcv_get (env, "", "#", &argc, &argv);
      expand_argcv (&xargc, &xargv, argc, argv);
      free (argv);
    }

  env = getenv ("CFLOWRC");
  if (env)
    parse_rc (&xargc, &xargv, env);
  else
    {
      ;
      ;
    }

  if (xargc > 1)
    {
      ;
      ;
      ;
    }
}


