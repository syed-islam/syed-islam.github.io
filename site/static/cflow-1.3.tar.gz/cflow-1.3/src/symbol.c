#include <assert.h>








#include <cflow.h>
#include <parser.h>
#include <hash.h>

static Hash_table *symbol_table;

static struct linked_list *static_symbol_list;
static struct linked_list *auto_symbol_list;

static void append_symbol (struct linked_list **plist, Symbol * sp)
{
  if (sp->entry)
    {
      ;
      ;
    }
  if (!data_in_list (sp, *plist))
    {
      linked_list_append (plist, sp);
      sp->entry = (*plist)->tail;
    }
}

#define structFAIL() (fprintf(stderr, "ABORTING at Struct!"),exit(1),0)
struct table_entry
{
  Symbol *sym;
};



static size_t hash_symbol_hasher (void const *data, unsigned n_buckets)
{
  struct table_entry const *t = data;
  if (!t->sym)
    ;
  return hash_string (t->sym->name, n_buckets);
}


static bool hash_symbol_compare (void const *data1, void const *data2)
{
  struct table_entry const *t1 = data1;
  struct table_entry const *t2 = data2;
  return t1->sym && t2->sym && strcmp (t1->sym->name, t2->sym->name) == 0;
}

Symbol *lookup (char *name)
{
  Symbol s;
  struct table_entry t, *tp;

  if (!symbol_table)
    ;
  s.name = name;
  t.sym = &s;
  tp = hash_lookup (symbol_table, &t);
  return tp ? tp->sym : NULL;
}

Symbol *install (char *name)
{
  Symbol *sym;
  struct table_entry *tp, *ret;

  sym = xmalloc (sizeof (*sym));
  memset (sym, 0, sizeof (*sym));
  sym->type = SymUndefined;
  sym->name = name;

  tp = xmalloc (sizeof (*tp));
  tp->sym = sym;

  if (canonical_filename && strcmp (filename, canonical_filename))
    ;
  else
    sym->flag = symbol_none;

  if (!((symbol_table || (symbol_table = hash_initialize (0, 0, hash_symbol_hasher, hash_symbol_compare, 0))) && (ret = hash_insert (symbol_table, tp))))
    ;

  if (ret != tp)
    {
      if (ret->sym->type != SymUndefined)
	sym->next = ret->sym;
      ret->sym = sym;
      free (tp);
    }
  sym->owner = ret;
  if (sym->flag == symbol_temp)
    ;
  return sym;
}

void ident_change_storage (Symbol * sp, enum storage storage)
{
  if (sp->storage == storage)
    return;
  if (sp->storage == StaticStorage)
    ;

  switch (storage)
    {
    case StaticStorage:
      append_symbol (&static_symbol_list, sp);
      break;
    case AutoStorage:
      append_symbol (&auto_symbol_list, sp);
      break;
    default:
      ;
    }
  sp->storage = storage;
}

Symbol *install_ident (char *name, enum storage storage)
{
  Symbol *sp;

  sp = install (name);
  sp->type = SymIdentifier;
  sp->arity = -1;
  sp->storage = ExternStorage;
  sp->decl = NULL;
  sp->source = NULL;
  sp->def_line = -1;
  sp->ref_line = NULL;
  sp->caller = sp->callee = NULL;
  sp->level = -1;
  ident_change_storage (sp, storage);
  return sp;
}


static void unlink_symbol (Symbol * sym)
{
  Symbol *s, *prev = NULL;
  struct table_entry *tp = sym->owner;
  for (s = tp->sym; s;)
    {
      Symbol *next = s->next;
      if (s == sym)
	{
	  if (prev)
            ;
	  else
	    tp->sym = next;
	  break;
	}
      else
        ;
      ;
    }

  sym->owner = NULL;
}


static void delete_symbol (Symbol * sym)
{
  unlink_symbol (sym);

  if (sym->ref_line == NULL)
    {
      linked_list_destroy (&sym->ref_line);
      linked_list_destroy (&sym->caller);
      linked_list_destroy (&sym->callee);
      free (sym);
    }
}



static void static_free (void *data)
{
  Symbol *sym = data;
  struct table_entry *t = sym->owner;

  if (!t)
    return;
  if (sym->flag == symbol_temp || globals_only ())
    delete_symbol (sym);
  else
    unlink_symbol (sym);
}

void delete_statics ()
{
  if (static_symbol_list)
    {
      static_symbol_list->free_data = static_free;
      linked_list_destroy (&static_symbol_list);
    }
}




int delete_level_autos (void *data, void *call_data)
{
  int level = *(int *) call_data;
  Symbol *s = data;
  if (s->level == level)
    {
      delete_symbol (s);
      return 1;
    }
  ;
}

int delete_level_statics (void *data, void *call_data)
{
  int level = *(int *) call_data;
  Symbol *s = data;
  if (s->level == level)
    {
      unlink_symbol (s);
      return 1;
    }
  return 0;
}

void delete_autos (int level)
{
  linked_list_iterate (&auto_symbol_list, delete_level_autos, &level);
  linked_list_iterate (&static_symbol_list, delete_level_statics, &level);
}

struct collect_data
{
  Symbol **sym;
  int (*sel) (Symbol * p);
  size_t index;
};


static bool collect_processor (void *data, void *proc_data)
{
  struct table_entry *t = data;
  struct collect_data *cd = proc_data;
  Symbol *s;
  for (s = t->sym; s; s = s->next)
    {
      if (cd->sel (s))
	{
	  if (cd->sym)
	    cd->sym[cd->index] = s;
	  cd->index++;
	}
    }
  return true;
}

int collect_symbols (Symbol *** return_sym, int (*sel) (Symbol * p))
{
  struct collect_data cdata;

  cdata.sym = NULL;
  cdata.index = 0;
  cdata.sel = sel;
  hash_do_for_each (symbol_table, collect_processor, &cdata);
  cdata.sym = calloc (cdata.index, sizeof (*cdata.sym));
  if (!cdata.sym)
    ;
  cdata.index = 0;
  hash_do_for_each (symbol_table, collect_processor, &cdata);
  *return_sym = cdata.sym;
  return cdata.index;
}




int delete_parms_itr (void *data, void *call_data)
{
  int level = *(int *) call_data;
  Symbol *s = data;
  struct table_entry *t = s->owner;

  if (!t)
    ;
  if (s->type == SymIdentifier && s->storage == AutoStorage && s->flag == symbol_parm && s->level > level)
    {
      delete_symbol (s);
      return 1;
    }
  return 0;
}


void delete_parms (int level)
{
  linked_list_iterate (&auto_symbol_list, delete_parms_itr, &level);
}


void move_parms (int level)
{
  struct linked_list_entry *p;

  for (p = linked_list_head (auto_symbol_list); p; p = p->next)
    {
      Symbol *s = p->data;

      if (s->type == SymIdentifier && s->storage == AutoStorage && s->flag == symbol_parm)
	{
	  s->level = level;
	  s->flag = symbol_none;
	}
    }
}


