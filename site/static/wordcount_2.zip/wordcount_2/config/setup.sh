#!/bin/sh
cp -r orig $1