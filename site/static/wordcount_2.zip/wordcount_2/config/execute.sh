#!/bin/sh

FILE=wc_inword_29

cd $1

# FIME: Need to fail on timeout!

# actual execution
gtimeout 1 ./$FILE < test0.txt > test1 2> execute.err

rc=$?
if [[ $rc != 0 ]] ; then
	exit $rc
fi

# extract projected trajectory
cat test1 | grep $2 | md5sum

# cleanup
rm test1

