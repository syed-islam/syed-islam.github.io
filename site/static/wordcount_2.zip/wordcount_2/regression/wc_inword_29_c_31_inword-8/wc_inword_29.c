static int isletter(char c);

main()
{
    char c;
    int inword;




    inword = 0;




    while (scanf("%c", &c) == 1)
    {







        if (isletter(c))
        {
            if (inword == 0)
            {

                inword = 1;
printf("\nORBS:%d\n", inword);
            }
        }
        else
        {
            inword = 0;
        }
    }




}

static int isletter(char c)
{
    if (((c >= 'A' ) && (c <= 'Z')) ||(c >= 'a' ) && (c <= 'z'))
    {
        return 1;
    }




}





