#include <assert.h>










#include "bcdefs.h"
#ifndef VARARGS
#include <stdarg.h>
#else
#include <varargs.h>
#endif
#include "global.h"
#include "proto.h"




char *strcopyof (str)
     char *str;
{
  char *temp;

  temp = (char *) bc_malloc (strlen (str) + 1);
  return (strcpy (temp, str));
}




arg_list *nextarg (args, val, is_var)
     arg_list *args;
     int val;
     int is_var;
{
  arg_list *temp;

  temp = (arg_list *) bc_malloc (sizeof (arg_list));
  temp->av_name = val;
  temp->arg_is_var = is_var;
  temp->next = args;

  return (temp);
}




static char *arglist1 = NULL, *arglist2 = NULL;




_PROTOTYPE (static char *make_arg_str, (arg_list * args, int len));

static char *make_arg_str (args, len)
     arg_list *args;
     int len;
{
  char *temp;
  char sval[20];


  if (args != NULL)
    temp = make_arg_str (args->next, len + 12);
  else
    {
      temp = (char *) bc_malloc (len);
      *temp = 0;
      return temp;
    }


  if (args->arg_is_var)
    if (len != 1)
      sprintf (sval, "*%d,", args->av_name);
    else
      ;
  else if (len != 1)
    sprintf (sval, "%d,", args->av_name);
  else
    sprintf (sval, "%d", args->av_name);
  temp = strcat (temp, sval);
  return (temp);
}

char *arg_str (args)
     arg_list *args;
{
  if (arglist2 != NULL)
    free (arglist2);
  arglist2 = arglist1;
  arglist1 = make_arg_str (args, 1);
  return (arglist1);
}

char *call_str (args)
     arg_list *args;
{
  arg_list *temp;
  int arg_count;
  int ix;

  if (arglist2 != NULL)
    free (arglist2);
  arglist2 = arglist1;


  for (temp = args, arg_count = 0; temp != NULL; temp = temp->next)
    arg_count++;
  arglist1 = (char *) bc_malloc (arg_count + 1);
  for (temp = args, ix = 0; temp != NULL; temp = temp->next)
    arglist1[ix++] = (temp->av_name ? '1' : '0');
  arglist1[ix] = 0;

  return (arglist1);
}



void free_args (args)
     arg_list *args;
{
  arg_list *temp;

  temp = args;
  while (temp != NULL)
    {
      args = args->next;
      free (temp);
      temp = args;
    }
}




void check_params (params, autos)
     arg_list *params, *autos;
{
  arg_list *tmp1, *tmp2;


  if (params != NULL)
    {
      tmp1 = params;
      while (tmp1 != NULL)
	{
	  tmp2 = tmp1->next;
	  while (tmp2 != NULL)
	    {
	      if (tmp2->av_name == tmp1->av_name)
                ;
	      tmp2 = tmp2->next;
	    }
	  if (tmp1->arg_is_var)
	    warn ("Variable array parameter");
	  tmp1 = tmp1->next;
	}
    }


  if (autos != NULL)
    {
      tmp1 = autos;
      while (tmp1 != NULL)
	{
	  tmp2 = tmp1->next;
	  while (tmp2 != NULL)
	    {
	      if (tmp2->av_name == tmp1->av_name)
                ;
	      tmp2 = tmp2->next;
	    }
	  if (tmp1->arg_is_var)
            ;
	  tmp1 = tmp1->next;
	}
    }


  if ((params != NULL) && (autos != NULL))
    {
      tmp1 = params;
      while (tmp1 != NULL)
	{
	  tmp2 = autos;
	  while (tmp2 != NULL)
	    {
	      if (tmp2->av_name == tmp1->av_name)
                ;
	      tmp2 = tmp2->next;
	    }
	  tmp1 = tmp1->next;
	}
    }
}




void init_gen ()
{

  break_label = 0;
  continue_label = 0;
  next_label = 1;
  out_count = 2;
  if (compile_only)
    ;
  else
    init_load ();
  had_error = FALSE;
  did_gen = FALSE;
}




void generate (str)
     char *str;
{
  did_gen = TRUE;
  if (compile_only)
    {
      ;
      ;
      ;
    }
  else
    load_code (str);
}




void run_code ()
{

  if (!had_error && did_gen)
    {
      if (compile_only)
	{
          ;
          ;
	}
      else
	execute ();
    }


  if (did_gen)
    init_gen ();
  else
    had_error = FALSE;
}




void out_char (ch)
     int ch;
{
  if (ch == '\n')
    {
      out_col = 0;
      putchar ('\n');
    }
  else
    {
      out_col++;
      if (out_col == line_size - 1)
	{
	  putchar ('\\');
	  putchar ('\n');
	  out_col = 1;
	}
      putchar (ch);
    }
}



void out_schar (ch)
     int ch;
{
  if (ch == '\n')
    {
      out_col = 0;
      putchar ('\n');
    }
  else
    {
      if (!std_only)
	{
	  out_col++;
	  if (out_col == line_size - 1)
	    {
              ;
              ;
              ;
	    }
	}
      putchar (ch);
    }
}






id_rec *find_id (tree, id)
     id_rec *tree;
     char *id;
{
  int cmp_result;


  if (tree == NULL)
    return NULL;


  cmp_result = strcmp (id, tree->id);
  if (cmp_result == 0)
    return tree;
  else if (cmp_result < 0)
    return find_id (tree->left, id);
  else
    return find_id (tree->right, id);
}




int insert_id_rec (root, new_id)
     id_rec **root;
     id_rec *new_id;
{
  id_rec *A, *B;


  if (*root == NULL)
    {
      *root = new_id;
      new_id->left = NULL;
      new_id->right = NULL;
      new_id->balance = 0;
      return (TRUE);
    }


  if (strcmp (new_id->id, (*root)->id) < 0)
    {

      if (insert_id_rec (&((*root)->left), new_id))
	{

	  (*root)->balance--;

	  switch ((*root)->balance)
	    {
	    case 0:
	      return (FALSE);
	    case -1:
	      return (FALSE);
	    case -2:
              ;
              ;
              ;
	    }
	}
    }
  else
    {

      if (insert_id_rec (&((*root)->right), new_id))
	{

	  (*root)->balance++;
	  switch ((*root)->balance)
	    {
	    case 0:
	      return (FALSE);
	    case 1:
	      return (FALSE);
	    case 2:
              ;
              ;
              ;
	    }
	}
    }


  return (FALSE);
}




void init_tree ()
{
  name_tree = NULL;
  next_array = 1;
  next_func = 1;

  next_var = 5;
}




int lookup (name, namekind)
     char *name;
     int namekind;
{
  id_rec *id;


  if (strlen (name) != 1)
    warn ("multiple letter name - %s", name);


  id = find_id (name_tree, name);
  if (id == NULL)
    {

      id = (id_rec *) bc_malloc (sizeof (id_rec));
      id->id = strcopyof (name);
      id->a_name = 0;
      id->f_name = 0;
      id->v_name = 0;
      insert_id_rec (&name_tree, id);
    }


  switch (namekind)
    {

    case ARRAY:

      if (id->a_name != 0)
	{
	  free (name);
	  return (-id->a_name);
	}
      id->a_name = next_array++;
      a_names[id->a_name] = name;
      if (id->a_name < MAX_STORE)
	{
	  if (id->a_name >= a_count)
            ;
	  return (-id->a_name);
	}
      ;
      ;

    case FUNCT:
    case FUNCTDEF:
      if (id->f_name != 0)
	{
	  free (name);

	  if (use_math && namekind == FUNCTDEF && id->f_name <= 6)
            ;
	  return (id->f_name);
	}
      id->f_name = next_func++;
      f_names[id->f_name] = name;
      if (id->f_name < MAX_STORE)
	{
	  if (id->f_name >= f_count)
            ;
	  return (id->f_name);
	}
      ;
      ;

    case SIMPLE:
      if (id->v_name != 0)
	{
	  free (name);
	  return (id->v_name);
	}
      id->v_name = next_var++;
      v_names[id->v_name - 1] = name;
      if (id->v_name <= MAX_STORE)
	{
	  if (id->v_name >= v_count)
            ;
	  return (id->v_name);
	}
      ;
      ;
    }

  ;
  ;

}




void welcome ()
{
  printf ("This is free software with ABSOLUTELY NO WARRANTY.\n");
  printf ("For details type `warranty'. \n");
}


void show_bc_version ()
{
  printf ("%s %s\n%s\n", PACKAGE, VERSION, BC_COPYRIGHT);
}










char *bc_malloc (size)
     int size;
{
  char *ptr;

  ptr = (char *) malloc (size);
  if (ptr == NULL)
    ;

  return ptr;
}














#ifndef VARARGS
#ifdef __STDC__
void warn (char *mesg, ...)
#else
void warn (mesg)
     char *mesg;
#endif
#else
void warn (mesg, va_alist)
     char *mesg;
#endif
{
  char *name;
  va_list args;

#ifndef VARARGS
  va_start (args, mesg);
#else
  va_start (args);
#endif
  if (std_only)
    {
      ;
    }
  else if (warn_not_std)
    {
      ;
    }
  va_end (args);
}



#ifndef VARARGS
#ifdef __STDC__
void rt_error (char *mesg, ...)
#else
void rt_error (mesg)
     char *mesg;
#endif
#else
void rt_error (mesg, va_alist)
     char *mesg;
#endif
{
  va_list args;

  fprintf (stderr, "Runtime error (func=%s, adr=%d): ", f_names[pc.pc_func], pc.pc_addr);
#ifndef VARARGS
  va_start (args, mesg);
#else
  va_start (args);
#endif
  vfprintf (stderr, mesg, args);
  va_end (args);

  fprintf (stderr, "\n");
  runtime_error = TRUE;
}



#ifndef VARARGS
#ifdef __STDC__
void yyerror (char *str, ...)
#else
void yyerror (str)
     char *str;
#endif
#else
void yyerror (str, va_alist)
     char *str;
#endif
{}


void out_of_memory ()
{}


#ifndef VARARGS
#ifdef __STDC__
void rt_warn (char *mesg, ...)
#else
void rt_warn (mesg)
     char *mesg;
#endif
#else
void rt_warn (mesg, va_alist)
     char *mesg;
#endif
{
 }
