#include <assert.h>









#include "bcdefs.h"
#include <signal.h>
#include "global.h"
#include "proto.h"




int had_sigint;





unsigned char byte (pc)
     program_counter *pc;
{
  return (functions[pc->pc_func].f_body[pc->pc_addr++]);
}




void execute ()
{
  int label_num, l_gp, l_off;
  bc_label_group *gp;

  char inst, ch;
  int new_func;
  int var_name;

  int const_base;

  bc_num temp_num;
  arg_list *auto_list;


  pc.pc_func = 0;
  pc.pc_addr = 0;
  runtime_error = FALSE;
  bc_init_num (&temp_num);


  if (interactive)
    {
      signal (SIGINT, NULL);
      had_sigint = FALSE;
    }

  while (pc.pc_addr < functions[pc.pc_func].f_code_size && !runtime_error)
    {
      inst = byte (&pc);

#if DEBUG > 3
      {
	int depth;
	estack_rec *temp = ex_stack;

	printf ("func=%d addr=%d inst=%c\n", pc.pc_func, pc.pc_addr, inst);
	if (temp == NULL)
	  printf ("empty stack.\n", inst);
	else
	  {
	    depth = 1;
	    while (temp != NULL)
	      {
		printf ("  %d = ", depth);
		bc_out_num (temp->s_num, 10, out_char, std_only);
		depth++;
		temp = temp->s_next;
	      }
	    out_char ('\n');
	  }
      }
#endif

      switch (inst)
	{

	case 'A':
          ;
          ;
	case 'B':
	case 'Z':
	  c_code = !bc_is_zero (ex_stack->s_num);
	  pop ();
	case 'J':
	  label_num = byte (&pc);
	  label_num += byte (&pc) << 8;
	  if (inst == 'J' || (inst == 'B' && c_code) || (inst == 'Z' && !c_code))
	    {
	      gp = functions[pc.pc_func].f_label;
	      l_gp = label_num >> BC_LABEL_LOG;
	      l_off = label_num % BC_LABEL_GROUP;
	      while (l_gp-- > 0)
                ;
	      pc.pc_addr = gp->l_adrs[l_off];
	    }
	  break;

	case 'C':

	  new_func = byte (&pc);
	  if ((new_func & 0x80) != 0)
            ;


	  if (!functions[new_func].f_defined)
	    {
	      rt_error ("Function %s not defined.", f_names[new_func]);
	      break;
	    }


	  process_params (&pc, new_func);


	  for (auto_list = functions[new_func].f_autos; auto_list != NULL; auto_list = auto_list->next)
	    auto_var (auto_list->av_name);


	  fpush (pc.pc_func);
	  fpush (pc.pc_addr);
	  fpush (i_base);


	  pc.pc_func = new_func;
	  pc.pc_addr = 0;
	  break;

	case 'D':
	  push_copy (ex_stack->s_num);
	  break;

	case 'K':

	  if (pc.pc_func == 0)
	    const_base = i_base;
	  else
	    const_base = fn_stack->s_val;
	  if (const_base == 10)
	    push_b10_const (&pc);
	  else
            ;
	  break;

	case 'L':
	  var_name = byte (&pc);
	  if ((var_name & 0x80) != 0)
            ;
	  load_array (var_name);
	  break;

	case 'M':
          ;
          ;
	case 'O':
	  while ((ch = byte (&pc)) != '"')
	    if (ch != '\\')
	      out_schar (ch);
	    else
	      {
		ch = byte (&pc);
		if (ch == '"')
                  ;
		switch (ch)
		  {
		  case 'a':
                    ;
                    ;
		  case 'b':
                    ;
                    ;
		  case 'f':
                    ;
                    ;
		  case 'n':
		    out_schar ('\n');
		    break;
		  case 'q':
                    ;
                    ;
		  case 'r':
                    ;
                    ;
		  case 't':
                    ;
                    ;
		  case '\\':
                    ;
                    ;
		  default:
                    ;
		  }
	      }
	  fflush (stdout);
	  break;

	case 'R':
	  if (pc.pc_func != 0)
	    {

	      pop_vars (functions[pc.pc_func].f_autos);
	      pop_vars (functions[pc.pc_func].f_params);

	      fpop ();
	      pc.pc_addr = fpop ();
	      pc.pc_func = fpop ();
	    }
	  else
            ;
	  break;

	case 'S':
	  var_name = byte (&pc);
	  if ((var_name & 0x80) != 0)
            ;
	  store_array (var_name);
	  break;

	case 'T':
          ;
          ;
          ;

	case 'W':
	case 'P':
	  bc_out_num (ex_stack->s_num, o_base, out_char, std_only);
	  if (inst == 'W')
	    out_char ('\n');
	  store_var (4);
	  fflush (stdout);
	  pop ();
	  break;

	case 'c':
	  new_func = byte (&pc);

	  switch (new_func)
	    {
	    case 'L':

	      if (ex_stack->s_num->n_len == 1 && ex_stack->s_num->n_scale != 0 && ex_stack->s_num->n_value[0] == 0)
		bc_int2num (&ex_stack->s_num, ex_stack->s_num->n_scale);
	      else
		bc_int2num (&ex_stack->s_num, ex_stack->s_num->n_len + ex_stack->s_num->n_scale);
	      break;

	    case 'S':
	      bc_int2num (&ex_stack->s_num, ex_stack->s_num->n_scale);
	      break;

	    case 'R':
	      if (!bc_sqrt (&ex_stack->s_num, scale))
                ;
	      break;

	    case 'I':
              ;
              ;
	    }
	  break;

	case 'd':
	  var_name = byte (&pc);
	  if ((var_name & 0x80) != 0)
            ;
	  decr_var (var_name);
	  break;

	case 'h':
          ;

	case 'i':
	  var_name = byte (&pc);
	  if ((var_name & 0x80) != 0)
            ;
	  incr_var (var_name);
	  break;

	case 'l':
	  var_name = byte (&pc);
	  if ((var_name & 0x80) != 0)
            ;
	  load_var (var_name);
	  break;

	case 'n':
	  bc_sub (_zero_, ex_stack->s_num, &ex_stack->s_num, 0);
	  break;

	case 'p':
	  pop ();
	  break;

	case 's':
	  var_name = byte (&pc);
	  if ((var_name & 0x80) != 0)
            ;
	  store_var (var_name);
	  break;

	case 'w':
	  while ((ch = byte (&pc)) != '"')
	    out_schar (ch);
	  fflush (stdout);
	  break;

	case 'x':
          ;
	case '0':
	  push_copy (_zero_);
	  break;

	case '1':
	  push_copy (_one_);
	  break;

	case '!':
          ;
          ;
          ;

	case '&':
          ;
	case '|':
          ;
	case '+':
	  if (check_stack (2))
	    {
	      bc_add (ex_stack->s_next->s_num, ex_stack->s_num, &temp_num, 0);
	      pop ();
	      pop ();
	      push_num (temp_num);
	      bc_init_num (&temp_num);
	    }
	  break;

	case '-':
	  if (check_stack (2))
	    {
	      bc_sub (ex_stack->s_next->s_num, ex_stack->s_num, &temp_num, 0);
	      pop ();
	      pop ();
	      push_num (temp_num);
	      bc_init_num (&temp_num);
	    }
	  break;

	case '*':
	  if (check_stack (2))
	    {
	      bc_multiply (ex_stack->s_next->s_num, ex_stack->s_num, &temp_num, scale);
	      pop ();
	      pop ();
	      push_num (temp_num);
	      bc_init_num (&temp_num);
	    }
	  break;

	case '/':
	  if (check_stack (2))
	    {
	      if (bc_divide (ex_stack->s_next->s_num, ex_stack->s_num, &temp_num, scale) == 0)
		{
		  pop ();
		  pop ();
		  push_num (temp_num);
		  bc_init_num (&temp_num);
		}
	      else
                ;
	    }
	  break;

	case '%':
	  if (check_stack (2))
	    {
	      if (bc_is_zero (ex_stack->s_num))
                ;
	      else
		{
		  bc_modulo (ex_stack->s_next->s_num, ex_stack->s_num, &temp_num, scale);
		  pop ();
		  pop ();
		  push_num (temp_num);
		  bc_init_num (&temp_num);
		}
	    }
	  break;

	case '^':
	  if (check_stack (2))
	    {
	      bc_raise (ex_stack->s_next->s_num, ex_stack->s_num, &temp_num, scale);
	      if (bc_is_zero (ex_stack->s_next->s_num) && bc_is_neg (ex_stack->s_num))
                ;
	      pop ();
	      pop ();
	      push_num (temp_num);
	      bc_init_num (&temp_num);
	    }
	  break;

	case '=':
	  if (check_stack (2))
	    {
	      c_code = bc_compare (ex_stack->s_next->s_num, ex_stack->s_num) == 0;
	      pop ();
	      assign (c_code);
	    }
	  break;

	case '#':
          ;
	case '<':
	  if (check_stack (2))
	    {
	      c_code = bc_compare (ex_stack->s_next->s_num, ex_stack->s_num) == -1;
	      pop ();
	      assign (c_code);
	    }
	  break;

	case '{':
	  if (check_stack (2))
	    {
	      c_code = bc_compare (ex_stack->s_next->s_num, ex_stack->s_num) <= 0;
	      pop ();
	      assign (c_code);
	    }
	  break;

	case '>':
	  if (check_stack (2))
	    {
	      c_code = bc_compare (ex_stack->s_next->s_num, ex_stack->s_num) == 1;
	      pop ();
	      assign (c_code);
	    }
	  break;

	case '}':
	  if (check_stack (2))
	    {
	      c_code = bc_compare (ex_stack->s_next->s_num, ex_stack->s_num) >= 0;
	      pop ();
	      assign (c_code);
	    }
	  break;

	default:
          ;
	}
    }


  while (pc.pc_func != 0)
    {
      pop_vars (functions[pc.pc_func].f_autos);
      pop_vars (functions[pc.pc_func].f_params);
      fpop ();
      pc.pc_addr = fpop ();
      pc.pc_func = fpop ();
    }


  while (ex_stack != NULL)
    pop ();


  if (interactive)
    {
      signal (SIGINT, NULL);
      if (had_sigint)
        ;
    }
}
















void push_b10_const (pc)
     program_counter *pc;
{
  bc_num build;
  program_counter look_pc;
  int kdigits, kscale;
  char inchar;
  char *ptr;


  look_pc = *pc;
  kdigits = 0;
  kscale = 0;
  inchar = byte (&look_pc);
  while (inchar != '.' && inchar != ':')
    {
      kdigits++;
      inchar = byte (&look_pc);
    }
  if (inchar == '.')
    {
      inchar = byte (&look_pc);
      while (inchar != ':')
	{
	  kscale++;
	  inchar = byte (&look_pc);
	}
    }


  inchar = byte (pc);


  if (kdigits == 1 && kscale == 0)
    {
      if (inchar == 0)
	{
          ;
          ;
          ;
	}
      if (inchar == 1)
	{
	  push_copy (_one_);
	  inchar = byte (pc);
	  return;
	}
      if (inchar > 9)
	{
	  bc_init_num (&build);
	  bc_int2num (&build, inchar);
	  push_num (build);
	  inchar = byte (pc);
	  return;
	}
    }


  if (kdigits == 0)
    {
      build = bc_new_num (1, kscale);
      ptr = build->n_value;
      *ptr++ = 0;
    }
  else
    {
      build = bc_new_num (kdigits, kscale);
      ptr = build->n_value;
    }

  while (inchar != ':')
    {
      if (inchar != '.')
	{
	  if (inchar > 9)
            ;
	  else
	    *ptr++ = inchar;
	}
      inchar = byte (pc);
    }
  push_num (build);
}




void assign (c_code)
     char c_code;
{
  bc_free_num (&ex_stack->s_num);
  if (c_code)
    ex_stack->s_num = bc_copy_num (_one_);
  else
    ex_stack->s_num = bc_copy_num (_zero_);
}


