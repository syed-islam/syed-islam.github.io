



#include "bcdefs.h"


#undef EXTERN
#define EXTERN


#include "global.h"

CONST char *libmath[] =
#include "libmath.h"
  ;
