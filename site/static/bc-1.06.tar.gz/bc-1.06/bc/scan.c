



#define FLEX_SCANNER
#define YY_FLEX_MAJOR_VERSION 2
#define YY_FLEX_MINOR_VERSION 5

#include <stdio.h>



#ifdef c_plusplus
#ifndef __cplusplus
#define __cplusplus
#endif
#endif


#ifdef __cplusplus

#include <stdlib.h>
#include <unistd.h>


#define YY_USE_PROTOS


#define YY_USE_CONST

#else

#if __STDC__

#define YY_USE_PROTOS
#define YY_USE_CONST

#endif
#endif

#ifdef __TURBOC__
#pragma warn -rch
#pragma warn -use
#include <io.h>
#include <stdlib.h>
#define YY_USE_CONST
#define YY_USE_PROTOS
#endif

#ifdef YY_USE_CONST
#define yyconst const
#else
#define yyconst
#endif


#ifdef YY_USE_PROTOS
#define YY_PROTO(proto) proto
#else
#define YY_PROTO(proto) ()
#endif


#define YY_NULL 0


#define YY_SC_TO_UI(c) ((unsigned int) (unsigned char) c)


#define BEGIN yy_start = 1 + 2 *


#define YY_START ((yy_start - 1) / 2)
#define YYSTATE YY_START


#define YY_STATE_EOF(state) (YY_END_OF_BUFFER + state + 1)


#define YY_NEW_FILE yyrestart( yyin )

#define YY_END_OF_BUFFER_CHAR 0


#define YY_BUF_SIZE 16384

typedef struct yy_buffer_state *YY_BUFFER_STATE;

extern int yyleng;
extern FILE *yyin, *yyout;

#define EOB_ACT_CONTINUE_SCAN 0
#define EOB_ACT_END_OF_FILE 1
#define EOB_ACT_LAST_MATCH 2





#define yyless(n) \
	do \
		{ \
		 \
		*yy_cp = yy_hold_char; \
		YY_RESTORE_YY_MORE_OFFSET \
		yy_c_buf_p = yy_cp = yy_bp + n - YY_MORE_ADJ; \
		YY_DO_BEFORE_ACTION;  \
		} \
	while ( 0 )

#define unput(c) yyunput( c, yytext_ptr )


typedef unsigned int yy_size_t;


struct yy_buffer_state
{
  FILE *yy_input_file;

  char *yy_ch_buf;
  char *yy_buf_pos;


  yy_size_t yy_buf_size;


  int yy_n_chars;


  int yy_is_our_buffer;


  int yy_is_interactive;


  int yy_at_bol;


  int yy_fill_buffer;

  int yy_buffer_status;
#define YY_BUFFER_NEW 0
#define YY_BUFFER_NORMAL 1

#define YY_BUFFER_EOF_PENDING 2
};

static YY_BUFFER_STATE yy_current_buffer = 0;


#define YY_CURRENT_BUFFER yy_current_buffer



static char yy_hold_char;

static int yy_n_chars;


int yyleng;


static char *yy_c_buf_p = (char *) 0;
static int yy_init = 1;
static int yy_start = 0;


static int yy_did_buffer_switch_on_eof;

void yyrestart YY_PROTO ((FILE * input_file));

void yy_switch_to_buffer YY_PROTO ((YY_BUFFER_STATE new_buffer));
void yy_load_buffer_state YY_PROTO ((void));
YY_BUFFER_STATE yy_create_buffer YY_PROTO ((FILE * file, int size));
void yy_delete_buffer YY_PROTO ((YY_BUFFER_STATE b));
void yy_init_buffer YY_PROTO ((YY_BUFFER_STATE b, FILE * file));
void yy_flush_buffer YY_PROTO ((YY_BUFFER_STATE b));
#define YY_FLUSH_BUFFER yy_flush_buffer( yy_current_buffer )

YY_BUFFER_STATE yy_scan_buffer YY_PROTO ((char *base, yy_size_t size));
YY_BUFFER_STATE yy_scan_string YY_PROTO ((yyconst char *yy_str));
YY_BUFFER_STATE yy_scan_bytes YY_PROTO ((yyconst char *bytes, int len));

static void *yy_flex_alloc YY_PROTO ((yy_size_t));
static void *yy_flex_realloc YY_PROTO ((void *, yy_size_t));
static void yy_flex_free YY_PROTO ((void *));

#define yy_new_buffer yy_create_buffer

#define yy_set_interactive(is_interactive) \
	{ \
	if ( ! yy_current_buffer ) \
		yy_current_buffer = yy_create_buffer( yyin, YY_BUF_SIZE ); \
	yy_current_buffer->yy_is_interactive = is_interactive; \
	}

#define yy_set_bol(at_bol) \
	{ \
	if ( ! yy_current_buffer ) \
		yy_current_buffer = yy_create_buffer( yyin, YY_BUF_SIZE ); \
	yy_current_buffer->yy_at_bol = at_bol; \
	}

#define YY_AT_BOL() (yy_current_buffer->yy_at_bol)

typedef unsigned char YY_CHAR;
FILE *yyin = (FILE *) 0, *yyout = (FILE *) 0;
typedef int yy_state_type;
extern char *yytext;
#define yytext_ptr yytext

static yy_state_type yy_get_previous_state YY_PROTO ((void));
static yy_state_type yy_try_NUL_trans YY_PROTO ((yy_state_type current_state));
static int yy_get_next_buffer YY_PROTO ((void));
static void yy_fatal_error YY_PROTO ((yyconst char msg[]));


#define YY_DO_BEFORE_ACTION \
	yytext_ptr = yy_bp; \
	yyleng = (int) (yy_cp - yy_bp); \
	yy_hold_char = *yy_cp; \
	*yy_cp = '\0'; \
	yy_c_buf_p = yy_cp;

#define YY_NUM_RULES 44
#define YY_END_OF_BUFFER 45
static yyconst short int yy_accept[298] = { 0,
  0, 0, 2, 2, 45, 43, 38, 36, 30, 43,
  1, 31, 43, 27, 31, 27, 27, 26, 31, 42,
  34, 32, 34, 43, 27, 40, 40, 40, 40, 40,
  40, 40, 40, 40, 40, 40, 40, 40, 40, 40,
  40, 43, 2, 2, 3, 2, 2, 1, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 38,
  34, 0, 41, 32, 28, 35, 42, 0, 39, 42,
  42, 0, 33, 37, 40, 40, 40, 40, 40, 40,

  40, 40, 40, 40, 10, 40, 40, 40, 40, 40,
  40, 40, 40, 40, 40, 40, 29, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 42, 0, 0, 42, 0,
  40, 40, 40, 40, 40, 9, 40, 40, 40, 40,
  40, 40, 40, 40, 40, 40, 40, 40, 40, 40,
  40, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2,

  2, 2, 2, 2, 2, 2, 16, 40, 40, 40,
  17, 19, 40, 40, 20, 40, 40, 40, 40, 6,
  18, 40, 40, 12, 40, 40, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 2, 2, 2, 2, 5, 40, 40, 40,
  14, 40, 40, 15, 24, 40, 13, 40, 11, 2,
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  2, 2, 40, 4, 40, 7, 25, 8, 40, 2,
  2, 2, 2, 2, 2, 2, 40, 21, 40, 2,
  2, 2, 23, 22, 2, 2, 0
};

static yyconst int yy_ec[256] = { 0,
  1, 1, 1, 1, 1, 1, 1, 1, 2, 3,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 2, 4, 5, 6, 1, 7, 8, 1, 9,
  10, 11, 12, 13, 14, 15, 16, 17, 17, 17,
  17, 17, 17, 17, 17, 17, 17, 1, 18, 19,
  20, 21, 1, 1, 22, 22, 22, 22, 22, 22,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  23, 24, 25, 26, 27, 1, 28, 29, 30, 31,

  32, 33, 34, 35, 36, 37, 38, 39, 40, 41,
  42, 43, 44, 45, 46, 47, 48, 37, 49, 37,
  50, 37, 51, 52, 53, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,

  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1
};

static yyconst int yy_meta[54] = { 0,
  1, 1, 2, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 3, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 3, 3, 3, 3,
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
  1, 1, 1
};

static yyconst short int yy_base[302] = { 0,
  0, 0, 53, 0, 525, 526, 522, 526, 503, 517,
  526, 501, 512, 526, 499, 95, 94, 94, 99, 105,
  498, 114, 497, 513, 495, 466, 468, 470, 479, 471,
  467, 0, 81, 102, 105, 479, 462, 458, 473, 94,
  104, 452, 0, 501, 526, 482, 139, 0, 481, 492,
  0, 479, 131, 132, 131, 125, 132, 478, 150, 477,
  493, 475, 160, 115, 117, 126, 130, 125, 446, 183,
  184, 186, 187, 123, 445, 180, 185, 192, 440, 489,
  526, 485, 526, 526, 526, 526, 158, 486, 526, 162,
  221, 485, 526, 526, 0, 440, 454, 444, 451, 437,

  437, 442, 434, 451, 0, 432, 436, 436, 447, 438,
  437, 195, 444, 426, 425, 433, 526, 0, 466, 0,
  178, 0, 0, 0, 0, 222, 464, 0, 230, 233,
  463, 0, 417, 65, 189, 208, 193, 205, 213, 220,
  214, 235, 416, 218, 224, 227, 241, 234, 237, 243,
  246, 231, 232, 245, 0, 275, 460, 278, 279, 459,
  419, 432, 412, 422, 425, 0, 409, 408, 408, 406,
  418, 415, 404, 408, 401, 416, 398, 406, 397, 398,
  403, 287, 438, 288, 437, 182, 250, 239, 270, 275,
  391, 266, 268, 271, 273, 274, 288, 279, 285, 281,

  299, 390, 292, 287, 293, 298, 0, 399, 400, 394,
  0, 0, 392, 401, 0, 385, 384, 398, 382, 0,
  0, 383, 395, 0, 398, 393, 376, 294, 303, 302,
  375, 374, 306, 312, 373, 305, 308, 313, 310, 372,
  371, 314, 317, 370, 335, 332, 0, 376, 384, 370,
  0, 379, 367, 0, 0, 371, 0, 370, 0, 362,
  325, 336, 322, 361, 137, 323, 360, 359, 331, 358,
  333, 357, 356, 0, 353, 0, 0, 0, 355, 349,
  343, 327, 342, 340, 334, 338, 346, 0, 238, 344,
  236, 339, 0, 0, 177, 102, 526, 392, 120, 395,

  398
};

static yyconst short int yy_def[302] = { 0,
  297, 1, 297, 3, 297, 297, 297, 297, 297, 298,
  297, 297, 297, 297, 297, 297, 297, 297, 297, 297,
  297, 297, 297, 297, 297, 299, 299, 299, 299, 299,
  299, 299, 299, 299, 299, 299, 299, 299, 299, 299,
  299, 297, 300, 300, 297, 300, 301, 300, 300, 300,
  300, 300, 300, 300, 300, 300, 300, 300, 300, 300,
  300, 300, 300, 63, 63, 63, 63, 63, 63, 63,
  63, 63, 63, 63, 63, 63, 63, 63, 300, 297,
  297, 298, 297, 297, 297, 297, 297, 297, 297, 297,
  297, 297, 297, 297, 299, 299, 299, 299, 299, 299,

  299, 299, 299, 299, 299, 299, 299, 299, 299, 299,
  299, 299, 299, 299, 299, 299, 297, 300, 300, 300,
  301, 300, 300, 300, 300, 300, 300, 300, 300, 300,
  300, 300, 63, 63, 63, 63, 63, 63, 63, 63,
  63, 63, 63, 63, 63, 63, 63, 63, 63, 63,
  63, 63, 63, 63, 300, 297, 297, 297, 297, 297,
  299, 299, 299, 299, 299, 299, 299, 299, 299, 299,
  299, 299, 299, 299, 299, 299, 299, 299, 299, 299,
  299, 300, 300, 300, 300, 63, 63, 63, 63, 63,
  63, 63, 63, 63, 63, 63, 63, 63, 63, 63,

  63, 63, 63, 63, 63, 63, 299, 299, 299, 299,
  299, 299, 299, 299, 299, 299, 299, 299, 299, 299,
  299, 299, 299, 299, 299, 299, 63, 63, 63, 63,
  63, 63, 63, 63, 63, 63, 63, 63, 63, 63,
  63, 63, 63, 63, 63, 63, 299, 299, 299, 299,
  299, 299, 299, 299, 299, 299, 299, 299, 299, 63,
  63, 63, 63, 63, 63, 63, 63, 63, 63, 63,
  63, 63, 299, 299, 299, 299, 299, 299, 299, 63,
  63, 63, 63, 63, 63, 63, 299, 299, 299, 63,
  63, 63, 299, 299, 63, 63, 0, 297, 297, 297,

  297
};

static yyconst short int yy_nxt[580] = { 0,
  6, 7, 8, 9, 10, 11, 12, 13, 14, 14,
  15, 16, 14, 17, 18, 19, 20, 14, 21, 22,
  23, 20, 14, 24, 14, 25, 6, 26, 27, 28,
  29, 30, 31, 32, 33, 34, 32, 32, 35, 32,
  32, 36, 37, 38, 39, 40, 32, 32, 41, 32,
  14, 42, 14, 43, 44, 45, 46, 47, 48, 49,
  50, 51, 51, 52, 53, 51, 54, 55, 56, 57,
  51, 58, 59, 60, 57, 51, 61, 51, 62, 43,
  63, 64, 65, 66, 67, 68, 69, 70, 71, 69,
  69, 72, 69, 69, 73, 74, 75, 76, 77, 69,

  69, 78, 69, 51, 79, 51, 86, 86, 102, 89,
  87, 186, 133, 84, 84, 87, 103, 88, 84, 90,
  93, 91, 95, 113, 93, 93, 91, 93, 92, 93,
  104, 115, 106, 81, 105, 128, 107, 114, 116, 93,
  108, 82, 125, 122, 123, 125, 129, 126, 130, 133,
  123, 123, 126, 130, 127, 131, 132, 137, 136, 135,
  132, 132, 133, 132, 133, 132, 139, 148, 138, 120,
  133, 283, 133, 133, 156, 132, 133, 133, 159, 156,
  82, 157, 122, 159, 133, 160, 133, 133, 133, 133,
  133, 133, 133, 133, 133, 133, 133, 133, 133, 133,

  133, 133, 133, 133, 133, 133, 133, 134, 133, 133,
  140, 150, 142, 144, 151, 147, 143, 145, 141, 153,
  187, 146, 176, 227, 133, 189, 154, 133, 152, 133,
  133, 133, 133, 133, 133, 90, 133, 91, 182, 133,
  133, 177, 91, 182, 92, 183, 184, 129, 188, 130,
  190, 184, 133, 185, 130, 133, 131, 191, 192, 193,
  133, 133, 194, 195, 196, 133, 197, 133, 198, 199,
  201, 133, 200, 203, 133, 204, 205, 228, 133, 133,
  206, 133, 133, 133, 133, 229, 133, 294, 133, 202,
  133, 156, 133, 133, 87, 159, 156, 133, 157, 87,

  159, 88, 160, 182, 184, 230, 231, 236, 182, 184,
  183, 185, 232, 133, 233, 133, 234, 133, 133, 235,
  133, 133, 133, 237, 238, 239, 133, 240, 133, 241,
  243, 260, 133, 244, 133, 133, 246, 245, 261, 133,
  133, 133, 262, 264, 267, 133, 133, 263, 270, 133,
  133, 265, 133, 133, 266, 133, 268, 133, 269, 133,
  133, 133, 271, 272, 133, 280, 282, 281, 284, 133,
  133, 285, 133, 286, 133, 295, 291, 293, 133, 133,
  133, 133, 133, 133, 292, 133, 133, 133, 296, 133,
  133, 133, 82, 82, 82, 118, 290, 118, 121, 121,

  121, 289, 288, 287, 133, 133, 133, 133, 133, 133,
  279, 278, 277, 276, 275, 274, 273, 133, 133, 133,
  133, 133, 133, 133, 259, 258, 257, 256, 255, 254,
  253, 252, 251, 250, 249, 248, 247, 242, 133, 159,
  156, 226, 225, 224, 223, 222, 221, 220, 219, 218,
  217, 216, 215, 214, 213, 212, 211, 210, 209, 208,
  207, 159, 156, 133, 133, 91, 158, 119, 181, 180,
  179, 178, 175, 174, 173, 172, 171, 170, 169, 168,
  167, 166, 165, 164, 163, 162, 161, 91, 158, 83,
  80, 155, 149, 133, 123, 94, 120, 120, 123, 124,

  123, 120, 119, 117, 112, 111, 110, 109, 101, 100,
  99, 98, 97, 96, 84, 94, 81, 81, 84, 85,
  84, 83, 81, 80, 297, 5, 297, 297, 297, 297,
  297, 297, 297, 297, 297, 297, 297, 297, 297, 297,
  297, 297, 297, 297, 297, 297, 297, 297, 297, 297,
  297, 297, 297, 297, 297, 297, 297, 297, 297, 297,
  297, 297, 297, 297, 297, 297, 297, 297, 297, 297,
  297, 297, 297, 297, 297, 297, 297, 297, 297
};

static yyconst short int yy_chk[580] = { 0,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 3, 3, 3, 3, 3, 3, 3,
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3,

  3, 3, 3, 3, 3, 3, 16, 17, 33, 19,
  18, 134, 134, 17, 16, 18, 33, 18, 19, 20,
  22, 20, 299, 40, 22, 22, 20, 22, 20, 22,
  34, 41, 35, 22, 34, 56, 35, 40, 41, 22,
  35, 47, 53, 47, 56, 54, 57, 55, 57, 296,
  53, 54, 55, 57, 55, 57, 59, 66, 65, 64,
  59, 59, 64, 59, 65, 59, 68, 74, 67, 59,
  74, 265, 68, 66, 87, 59, 63, 67, 90, 87,
  121, 87, 121, 90, 265, 90, 63, 63, 63, 63,
  63, 63, 63, 63, 63, 63, 63, 63, 63, 63,

  63, 63, 63, 63, 63, 63, 63, 63, 63, 63,
  70, 76, 71, 72, 77, 73, 71, 72, 70, 78,
  135, 72, 112, 186, 295, 137, 78, 76, 77, 186,
  70, 71, 77, 72, 73, 91, 135, 91, 126, 78,
  137, 112, 91, 126, 91, 126, 129, 130, 136, 130,
  138, 129, 138, 129, 130, 136, 130, 139, 140, 141,
  139, 141, 142, 144, 145, 144, 146, 140, 147, 148,
  150, 145, 149, 151, 146, 152, 153, 187, 152, 153,
  154, 148, 142, 291, 149, 188, 188, 289, 147, 150,
  150, 156, 154, 151, 158, 159, 156, 187, 156, 158,

  159, 158, 159, 182, 184, 189, 190, 196, 182, 184,
  182, 184, 192, 192, 193, 193, 194, 189, 194, 195,
  195, 196, 190, 197, 198, 199, 198, 200, 200, 201,
  203, 228, 199, 204, 204, 197, 206, 205, 229, 203,
  205, 228, 230, 234, 238, 206, 201, 233, 243, 230,
  229, 236, 236, 233, 237, 237, 239, 239, 242, 234,
  238, 242, 245, 246, 243, 261, 263, 262, 266, 263,
  266, 269, 261, 271, 282, 290, 282, 287, 269, 246,
  271, 285, 245, 262, 286, 286, 292, 284, 292, 283,
  281, 290, 298, 298, 298, 300, 280, 300, 301, 301,

  301, 279, 275, 273, 272, 270, 268, 267, 264, 260,
  258, 256, 253, 252, 250, 249, 248, 244, 241, 240,
  235, 232, 231, 227, 226, 225, 223, 222, 219, 218,
  217, 216, 214, 213, 210, 209, 208, 202, 191, 185,
  183, 181, 180, 179, 178, 177, 176, 175, 174, 173,
  172, 171, 170, 169, 168, 167, 165, 164, 163, 162,
  161, 160, 157, 143, 133, 131, 127, 119, 116, 115,
  114, 113, 111, 110, 109, 108, 107, 106, 104, 103,
  102, 101, 100, 99, 98, 97, 96, 92, 88, 82,
  80, 79, 75, 69, 62, 61, 60, 58, 52, 50,

  49, 46, 44, 42, 39, 38, 37, 36, 31, 30,
  29, 28, 27, 26, 25, 24, 23, 21, 15, 13,
  12, 10, 9, 7, 5, 297, 297, 297, 297, 297,
  297, 297, 297, 297, 297, 297, 297, 297, 297, 297,
  297, 297, 297, 297, 297, 297, 297, 297, 297, 297,
  297, 297, 297, 297, 297, 297, 297, 297, 297, 297,
  297, 297, 297, 297, 297, 297, 297, 297, 297, 297,
  297, 297, 297, 297, 297, 297, 297, 297, 297
};

static yy_state_type yy_last_accepting_state;
static char *yy_last_accepting_cpos;


#define REJECT reject_used_but_not_detected
#define yymore() yymore_used_but_not_detected
#define YY_MORE_ADJ 0
#define YY_RESTORE_YY_MORE_OFFSET
char *yytext;
#line 1 "scan.l"
#define INITIAL 0
#line 2 "scan.l"




#include "bcdefs.h"
#include "bc.h"
#include "global.h"
#include "proto.h"
#include <errno.h>



#ifdef SMALL_BUF
#undef YY_READ_BUF_SIZE
#define YY_READ_BUF_SIZE 512
#endif


#define DOT_IS_LAST


#undef yywrap
_PROTOTYPE (int yywrap, (void));

#if defined(LIBEDIT)


#include <histedit.h>


#undef  YY_INPUT
#define YY_INPUT(buf,result,max_size) \
		bcel_input((char *)buf, &result, max_size)


static const char *bcel_line = (char *) NULL;
static int bcel_len = 0;



char *null_prompt (EditLine * el)
{
  return "";
}




static void bcel_input (buf, result, max)
     char *buf;
     int *result;
     int max;
{
  if (!edit || yyin != stdin)
    {
      while ((*result = read (fileno (yyin), buf, max)) < 0)
	if (errno != EINTR)
	  {
	    yyerror ("read() in flex scanner failed");
	    exit (1);
	  }
      return;
    }


  if (bcel_len == 0)
    {
      bcel_line = el_gets (edit, &bcel_len);
      if (bcel_line == NULL)
	{

	  *result = 0;
	  bcel_len = 0;
	  return;
	}
      if (bcel_len != 0)
	history (hist, &histev, H_ENTER, bcel_line);
      fflush (stdout);
    }

  if (bcel_len <= max)
    {
      strncpy (buf, bcel_line, bcel_len);
      *result = bcel_len;
      bcel_len = 0;
    }
  else
    {
      strncpy (buf, bcel_line, max);
      *result = max;
      bcel_line += max;
      bcel_len -= max;
    }
}
#endif

#ifdef READLINE



#undef  YY_INPUT
#define YY_INPUT(buf,result,max_size) \
		rl_input((char *)buf, &result, max_size)


static char *rl_line = (char *) NULL;
static char *rl_start = (char *) NULL;
static int rl_len = 0;


extern FILE *rl_instream;
_PROTOTYPE (char *readline, (char *));



static void rl_input (buf, result, max)
     char *buf;
     int *result;
     int max;
{
  if (yyin != rl_instream)
    {
      while ((*result = read (fileno (yyin), buf, max)) < 0)
	if (errno != EINTR)
	  {
	    yyerror ("read() in flex scanner failed");
	    exit (1);
	  }
      return;
    }


  if (rl_len == 0)
    {
      if (rl_start)
	free (rl_start);
      rl_start = readline ("");
      if (rl_start == NULL)
	{

	  *result = 0;
	  rl_len = 0;
	  return;
	}
      rl_line = rl_start;
      rl_len = strlen (rl_line) + 1;
      if (rl_len != 1)
	add_history (rl_line);
      rl_line[rl_len - 1] = '\n';
      fflush (stdout);
    }

  if (rl_len <= max)
    {
      strncpy (buf, rl_line, rl_len);
      *result = rl_len;
      rl_len = 0;
    }
  else
    {
      strncpy (buf, rl_line, max);
      *result = max;
      rl_line += max;
      rl_len -= max;
    }
}
#endif

#if !defined(READLINE) && !defined(LIBEDIT)


#undef  YY_INPUT
#define YY_INPUT(buf,result,max_size) \
	while ( (result = read( fileno(yyin), (char *) buf, max_size )) < 0 ) \
	    if (errno != EINTR) \
		YY_FATAL_ERROR( "read() in flex scanner failed" );
#endif

#define slcomment 1

#line 809 "lex.yy.c"



#ifndef YY_SKIP_YYWRAP
#ifdef __cplusplus
extern "C" int yywrap YY_PROTO ((void));
#else
extern int yywrap YY_PROTO ((void));
#endif
#endif

#ifndef YY_NO_UNPUT
static void yyunput YY_PROTO ((int c, char *buf_ptr));
#endif

#ifndef yytext_ptr
static void yy_flex_strncpy YY_PROTO ((char *, yyconst char *, int));
#endif

#ifdef YY_NEED_STRLEN
static int yy_flex_strlen YY_PROTO ((yyconst char *));
#endif

#ifndef YY_NO_INPUT
#ifdef __cplusplus
static int yyinput YY_PROTO ((void));
#else
static int input YY_PROTO ((void));
#endif
#endif

#if YY_STACK_USED
static int yy_start_stack_ptr = 0;
static int yy_start_stack_depth = 0;
static int *yy_start_stack = 0;
#ifndef YY_NO_PUSH_STATE
static void yy_push_state YY_PROTO ((int new_state));
#endif
#ifndef YY_NO_POP_STATE
static void yy_pop_state YY_PROTO ((void));
#endif
#ifndef YY_NO_TOP_STATE
static int yy_top_state YY_PROTO ((void));
#endif

#else
#define YY_NO_PUSH_STATE 1
#define YY_NO_POP_STATE 1
#define YY_NO_TOP_STATE 1
#endif

#ifdef YY_MALLOC_DECL
YY_MALLOC_DECL
#else
#if __STDC__
#ifndef __cplusplus
#include <stdlib.h>
#endif
#else

#endif
#endif


#ifndef YY_READ_BUF_SIZE
#define YY_READ_BUF_SIZE 8192
#endif



#ifndef ECHO

#define ECHO (void) fwrite( yytext, yyleng, 1, yyout )
#endif


#ifndef YY_INPUT
#define YY_INPUT(buf,result,max_size) \
	if ( yy_current_buffer->yy_is_interactive ) \
		{ \
		int c = '*', n; \
		for ( n = 0; n < max_size && \
			     (c = getc( yyin )) != EOF && c != '\n'; ++n ) \
			buf[n] = (char) c; \
		if ( c == '\n' ) \
			buf[n++] = (char) c; \
		if ( c == EOF && ferror( yyin ) ) \
			YY_FATAL_ERROR( "input in flex scanner failed" ); \
		result = n; \
		} \
	else if ( ((result = fread( buf, 1, max_size, yyin )) == 0) \
		  && ferror( yyin ) ) \
		YY_FATAL_ERROR( "input in flex scanner failed" );
#endif


#ifndef yyterminate
#define yyterminate() return YY_NULL
#endif


#ifndef YY_START_STACK_INCR
#define YY_START_STACK_INCR 25
#endif


#ifndef YY_FATAL_ERROR
#define YY_FATAL_ERROR(msg) yy_fatal_error( msg )
#endif


#ifndef YY_DECL
#define YY_DECL int yylex YY_PROTO(( void ))
#endif


#ifndef YY_USER_ACTION
#define YY_USER_ACTION
#endif


#ifndef YY_BREAK
#define YY_BREAK break;
#endif

#define YY_RULE_SETUP \
	YY_USER_ACTION

YY_DECL
{
  register yy_state_type yy_current_state;
  register char *yy_cp, *yy_bp;
  register int yy_act;

#line 222 "scan.l"

#line 962 "lex.yy.c"

  if (yy_init)
    {
      yy_init = 0;

#ifdef YY_USER_INIT
      YY_USER_INIT;
#endif

      if (!yy_start)
	yy_start = 1;

      if (!yyin)
	yyin = stdin;

      if (!yyout)
	yyout = stdout;

      if (!yy_current_buffer)
	yy_current_buffer = yy_create_buffer (yyin, YY_BUF_SIZE);

      yy_load_buffer_state ();
    }

  while (1)
    {
      yy_cp = yy_c_buf_p;


      *yy_cp = yy_hold_char;


      yy_bp = yy_cp;

      yy_current_state = yy_start;
    yy_match:
      do
	{
	  register YY_CHAR yy_c = yy_ec[YY_SC_TO_UI (*yy_cp)];
	  if (yy_accept[yy_current_state])
	    {
	      yy_last_accepting_state = yy_current_state;
	      yy_last_accepting_cpos = yy_cp;
	    }
	  while (yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state)
	    {
	      yy_current_state = (int) yy_def[yy_current_state];
	      if (yy_current_state >= 298)
		yy_c = yy_meta[(unsigned int) yy_c];
	    }
	  yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned int) yy_c];
	  ++yy_cp;
	}
      while (yy_base[yy_current_state] != 526);

    yy_find_action:
      yy_act = yy_accept[yy_current_state];
      if (yy_act == 0)
	{
	  yy_cp = yy_last_accepting_cpos;
	  yy_current_state = yy_last_accepting_state;
	  yy_act = yy_accept[yy_current_state];
	}

      YY_DO_BEFORE_ACTION;


    do_action:


      switch (yy_act)
	{
	case 0:

	  *yy_cp = yy_hold_char;
	  yy_cp = yy_last_accepting_cpos;
	  yy_current_state = yy_last_accepting_state;
	  goto yy_find_action;

	case 1:
	  YY_RULE_SETUP
#line 223 "scan.l"
	  {
	    if (!std_only)
	      BEGIN (slcomment);
	    else
	      yyerror ("illegal character: #");
	  }
	YY_BREAK case 2:
	  YY_RULE_SETUP
#line 229 "scan.l"
	  {
	    BEGIN (INITIAL);
	  }
	YY_BREAK case 3:
	  YY_RULE_SETUP
#line 230 "scan.l"
	  {
	    line_no++;
	    BEGIN (INITIAL);
	    return (ENDOFLINE);
	  }
	YY_BREAK case 4:
	  YY_RULE_SETUP
#line 231 "scan.l"
	    return (Define);
	YY_BREAK case 5:
	  YY_RULE_SETUP
#line 232 "scan.l"
	    return (Break);
	YY_BREAK case 6:
	  YY_RULE_SETUP
#line 233 "scan.l"
	    return (Quit);
	YY_BREAK case 7:
	  YY_RULE_SETUP
#line 234 "scan.l"
	    return (Length);
	YY_BREAK case 8:
	  YY_RULE_SETUP
#line 235 "scan.l"
	    return (Return);
	YY_BREAK case 9:
	  YY_RULE_SETUP
#line 236 "scan.l"
	    return (For);
	YY_BREAK case 10:
	  YY_RULE_SETUP
#line 237 "scan.l"
	    return (If);
	YY_BREAK case 11:
	  YY_RULE_SETUP
#line 238 "scan.l"
	    return (While);
	YY_BREAK case 12:
	  YY_RULE_SETUP
#line 239 "scan.l"
	    return (Sqrt);
	YY_BREAK case 13:
	  YY_RULE_SETUP
#line 240 "scan.l"
	    return (Scale);
	YY_BREAK case 14:
	  YY_RULE_SETUP
#line 241 "scan.l"
	    return (Ibase);
	YY_BREAK case 15:
	  YY_RULE_SETUP
#line 242 "scan.l"
	    return (Obase);
	YY_BREAK case 16:
	  YY_RULE_SETUP
#line 243 "scan.l"
	    return (Auto);
	YY_BREAK case 17:
	  YY_RULE_SETUP
#line 244 "scan.l"
	    return (Else);
	YY_BREAK case 18:
	  YY_RULE_SETUP
#line 245 "scan.l"
	    return (Read);
	YY_BREAK case 19:
	  YY_RULE_SETUP
#line 246 "scan.l"
	    return (Halt);
	YY_BREAK case 20:
	  YY_RULE_SETUP
#line 247 "scan.l"
	    return (Last);
	YY_BREAK case 21:
	  YY_RULE_SETUP
#line 248 "scan.l"
	  {
#if defined(READLINE) || defined(LIBEDIT)
	    return (HistoryVar);
#else
	    yylval.s_value = strcopyof (yytext);
	    return (NAME);
#endif
	  }
	YY_BREAK case 22:
	  YY_RULE_SETUP
#line 256 "scan.l"
	    return (Warranty);
	YY_BREAK case 23:
	  YY_RULE_SETUP
#line 257 "scan.l"
	    return (Continue);
	YY_BREAK case 24:
	  YY_RULE_SETUP
#line 258 "scan.l"
	    return (Print);
	YY_BREAK case 25:
	  YY_RULE_SETUP
#line 259 "scan.l"
	    return (Limits);
	YY_BREAK case 26:
	  YY_RULE_SETUP
#line 260 "scan.l"
	  {
#ifdef DOT_IS_LAST
	    return (Last);
#else
	    yyerror ("illegal character: %s", yytext);
#endif
	  }
	YY_BREAK case 27:
	  YY_RULE_SETUP
#line 267 "scan.l"
	  {
	    yylval.c_value = yytext[0];
	    return ((int) yytext[0]);
	  }
	YY_BREAK case 28:
	  YY_RULE_SETUP
#line 269 "scan.l"
	  {
	    return (AND);
	  }
	YY_BREAK case 29:
	  YY_RULE_SETUP
#line 270 "scan.l"
	  {
	    return (OR);
	  }
	YY_BREAK case 30:
	  YY_RULE_SETUP
#line 271 "scan.l"
	  {
	    return (NOT);
	  }
	YY_BREAK case 31:
	  YY_RULE_SETUP
#line 272 "scan.l"
	  {
	    yylval.c_value = yytext[0];
	    return ((int) yytext[0]);
	  }
	YY_BREAK case 32:
	  YY_RULE_SETUP
#line 273 "scan.l"
	  {
	    yylval.c_value = yytext[0];
	    return (ASSIGN_OP);
	  }
	YY_BREAK case 33:
	  YY_RULE_SETUP
#line 274 "scan.l"
	  {
#ifdef OLD_EQ_OP
	    char warn_save;
	    warn_save = warn_not_std;
	    warn_not_std = TRUE;
	    warn ("Old fashioned =<op>");
	    warn_not_std = warn_save;
	    yylval.c_value = yytext[1];
#else
	    yylval.c_value = '=';
	    yyless (1);
#endif
	    return (ASSIGN_OP);
	  }
	YY_BREAK case 34:
	  YY_RULE_SETUP
#line 288 "scan.l"
	  {
	    yylval.s_value = strcopyof (yytext);
	    return (REL_OP);
	  }
	YY_BREAK case 35:
	  YY_RULE_SETUP
#line 289 "scan.l"
	  {
	    yylval.c_value = yytext[0];
	    return (INCR_DECR);
	  }
	YY_BREAK case 36:
	  YY_RULE_SETUP
#line 290 "scan.l"
	  {
	    line_no++;
	    return (ENDOFLINE);
	  }
	YY_BREAK case 37:
	  YY_RULE_SETUP
#line 291 "scan.l"
	  {
	    line_no++;
	  }
	YY_BREAK case 38:
	  YY_RULE_SETUP
#line 292 "scan.l"
	  {
	  }
	YY_BREAK case 39:
	  YY_RULE_SETUP
#line 293 "scan.l"
	  {
	    int c;

	    for (;;)
	      {
		while (((c = input ()) != '*') && (c != EOF))

		  if (c == '\n')
		    line_no++;
		if (c == '*')
		  {
		    while ((c = input ()) == '*');
		    if (c == '/')
		      break;
		    if (c == '\n')
		      line_no++;
		  }
		if (c == EOF)
		  {
		    fprintf (stderr, "EOF encountered in a comment.\n");
		    break;
		  }
	      }
	  }
	YY_BREAK case 40:
	  YY_RULE_SETUP
#line 314 "scan.l"
	  {
	    yylval.s_value = strcopyof (yytext);
	    return (NAME);
	  }
	YY_BREAK case 41:
	  YY_RULE_SETUP
#line 315 "scan.l"
	  {
	    unsigned char *look;
	    int count = 0;
	    yylval.s_value = strcopyof (yytext);
	    for (look = yytext; *look != 0; look++)
	      {
		if (*look == '\n')
		  line_no++;
		if (*look == '"')
		  count++;
	      }
	    if (count != 2)
	      yyerror ("NUL character in string.");
	    return (STRING);
	  }
	YY_BREAK case 42:
	  YY_RULE_SETUP
#line 327 "scan.l"
	  {
	    unsigned char *src, *dst;
	    int len;

	    len = strlen (yytext);
	    if (yytext[len - 1] == '.')
	      yytext[len - 1] = 0;

	    src = yytext;
	    dst = yytext;
	    while (*src == '0')
	      src++;
	    if (*src == 0)
	      src--;

	    while (*src != 0)
	      {
		if (*src == '\\')
		  {
		    src++;
		    src++;
		    line_no++;
		  }
		else
		  *dst++ = *src++;
	      }
	    *dst = 0;
	    yylval.s_value = strcopyof (yytext);
	    return (NUMBER);
	  }
	YY_BREAK case 43:
	  YY_RULE_SETUP
#line 354 "scan.l"
	  {
	    if (yytext[0] < ' ')
	      yyerror ("illegal character: ^%c", yytext[0] + '@');
	    else if (yytext[0] > '~')
	      yyerror ("illegal character: \\%03o", (int) yytext[0]);
	    else
	      yyerror ("illegal character: %s", yytext);
	  }
	YY_BREAK case 44:
	  YY_RULE_SETUP
#line 363 "scan.l"
	    ECHO;
	  YY_BREAK
#line 1361 "lex.yy.c"
	case YY_STATE_EOF (INITIAL):
	case YY_STATE_EOF (slcomment):
	  yyterminate ();

	case YY_END_OF_BUFFER:
	  {

	    int yy_amount_of_matched_text = (int) (yy_cp - yytext_ptr) - 1;


	    *yy_cp = yy_hold_char;
	    YY_RESTORE_YY_MORE_OFFSET if (yy_current_buffer->yy_buffer_status == YY_BUFFER_NEW)
	      {

		yy_n_chars = yy_current_buffer->yy_n_chars;
		yy_current_buffer->yy_input_file = yyin;
		yy_current_buffer->yy_buffer_status = YY_BUFFER_NORMAL;
	      }


	    if (yy_c_buf_p <= &yy_current_buffer->yy_ch_buf[yy_n_chars])
	      {
		yy_state_type yy_next_state;

		yy_c_buf_p = yytext_ptr + yy_amount_of_matched_text;

		yy_current_state = yy_get_previous_state ();



		yy_next_state = yy_try_NUL_trans (yy_current_state);

		yy_bp = yytext_ptr + YY_MORE_ADJ;

		if (yy_next_state)
		  {

		    yy_cp = ++yy_c_buf_p;
		    yy_current_state = yy_next_state;
		    goto yy_match;
		  }

		else
		  {
		    yy_cp = yy_c_buf_p;
		    goto yy_find_action;
		  }
	      }

	    else
	      switch (yy_get_next_buffer ())
		{
		case EOB_ACT_END_OF_FILE:
		  {
		    yy_did_buffer_switch_on_eof = 0;

		    if (yywrap ())
		      {

			yy_c_buf_p = yytext_ptr + YY_MORE_ADJ;

			yy_act = YY_STATE_EOF (YY_START);
			goto do_action;
		      }

		    else
		      {
			if (!yy_did_buffer_switch_on_eof)
			  YY_NEW_FILE;
		      }
		    break;
		  }

		case EOB_ACT_CONTINUE_SCAN:
		  yy_c_buf_p = yytext_ptr + yy_amount_of_matched_text;

		  yy_current_state = yy_get_previous_state ();

		  yy_cp = yy_c_buf_p;
		  yy_bp = yytext_ptr + YY_MORE_ADJ;
		  goto yy_match;

		case EOB_ACT_LAST_MATCH:
		  yy_c_buf_p = &yy_current_buffer->yy_ch_buf[yy_n_chars];

		  yy_current_state = yy_get_previous_state ();

		  yy_cp = yy_c_buf_p;
		  yy_bp = yytext_ptr + YY_MORE_ADJ;
		  goto yy_find_action;
		}
	    break;
	  }

	default:
	  YY_FATAL_ERROR ("fatal flex scanner internal error--no action found");
	}
    }
}




static int yy_get_next_buffer ()
{
  register char *dest = yy_current_buffer->yy_ch_buf;
  register char *source = yytext_ptr;
  register int number_to_move, i;
  int ret_val;

  if (yy_c_buf_p > &yy_current_buffer->yy_ch_buf[yy_n_chars + 1])
    YY_FATAL_ERROR ("fatal flex scanner internal error--end of buffer missed");

  if (yy_current_buffer->yy_fill_buffer == 0)
    {
      if (yy_c_buf_p - yytext_ptr - YY_MORE_ADJ == 1)
	{

	  return EOB_ACT_END_OF_FILE;
	}

      else
	{

	  return EOB_ACT_LAST_MATCH;
	}
    }




  number_to_move = (int) (yy_c_buf_p - yytext_ptr) - 1;

  for (i = 0; i < number_to_move; ++i)
    *(dest++) = *(source++);

  if (yy_current_buffer->yy_buffer_status == YY_BUFFER_EOF_PENDING)

    yy_current_buffer->yy_n_chars = yy_n_chars = 0;

  else
    {
      int num_to_read = yy_current_buffer->yy_buf_size - number_to_move - 1;

      while (num_to_read <= 0)
	{
#ifdef YY_USES_REJECT
	  YY_FATAL_ERROR ("input buffer overflow, can't enlarge buffer because scanner uses REJECT");
#else


	  YY_BUFFER_STATE b = yy_current_buffer;

	  int yy_c_buf_p_offset = (int) (yy_c_buf_p - b->yy_ch_buf);

	  if (b->yy_is_our_buffer)
	    {
	      int new_size = b->yy_buf_size * 2;

	      if (new_size <= 0)
		b->yy_buf_size += b->yy_buf_size / 8;
	      else
		b->yy_buf_size *= 2;

	      b->yy_ch_buf = (char *) yy_flex_realloc ((void *) b->yy_ch_buf, b->yy_buf_size + 2);
	    }
	  else

	    b->yy_ch_buf = 0;

	  if (!b->yy_ch_buf)
	    YY_FATAL_ERROR ("fatal error - scanner input buffer overflow");

	  yy_c_buf_p = &b->yy_ch_buf[yy_c_buf_p_offset];

	  num_to_read = yy_current_buffer->yy_buf_size - number_to_move - 1;
#endif
	}

      if (num_to_read > YY_READ_BUF_SIZE)
	num_to_read = YY_READ_BUF_SIZE;


      YY_INPUT ((&yy_current_buffer->yy_ch_buf[number_to_move]), yy_n_chars, num_to_read);

      yy_current_buffer->yy_n_chars = yy_n_chars;
    }

  if (yy_n_chars == 0)
    {
      if (number_to_move == YY_MORE_ADJ)
	{
	  ret_val = EOB_ACT_END_OF_FILE;
	  yyrestart (yyin);
	}

      else
	{
	  ret_val = EOB_ACT_LAST_MATCH;
	  yy_current_buffer->yy_buffer_status = YY_BUFFER_EOF_PENDING;
	}
    }

  else
    ret_val = EOB_ACT_CONTINUE_SCAN;

  yy_n_chars += number_to_move;
  yy_current_buffer->yy_ch_buf[yy_n_chars] = YY_END_OF_BUFFER_CHAR;
  yy_current_buffer->yy_ch_buf[yy_n_chars + 1] = YY_END_OF_BUFFER_CHAR;

  yytext_ptr = &yy_current_buffer->yy_ch_buf[0];

  return ret_val;
}




static yy_state_type yy_get_previous_state ()
{
  register yy_state_type yy_current_state;
  register char *yy_cp;

  yy_current_state = yy_start;

  for (yy_cp = yytext_ptr + YY_MORE_ADJ; yy_cp < yy_c_buf_p; ++yy_cp)
    {
      register YY_CHAR yy_c = (*yy_cp ? yy_ec[YY_SC_TO_UI (*yy_cp)] : 1);
      if (yy_accept[yy_current_state])
	{
	  yy_last_accepting_state = yy_current_state;
	  yy_last_accepting_cpos = yy_cp;
	}
      while (yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state)
	{
	  yy_current_state = (int) yy_def[yy_current_state];
	  if (yy_current_state >= 298)
	    yy_c = yy_meta[(unsigned int) yy_c];
	}
      yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned int) yy_c];
    }

  return yy_current_state;
}




#ifdef YY_USE_PROTOS
static yy_state_type yy_try_NUL_trans (yy_state_type yy_current_state)
#else
static yy_state_type yy_try_NUL_trans (yy_current_state)
     yy_state_type yy_current_state;
#endif
{
  register int yy_is_jam;
  register char *yy_cp = yy_c_buf_p;

  register YY_CHAR yy_c = 1;
  if (yy_accept[yy_current_state])
    {
      yy_last_accepting_state = yy_current_state;
      yy_last_accepting_cpos = yy_cp;
    }
  while (yy_chk[yy_base[yy_current_state] + yy_c] != yy_current_state)
    {
      yy_current_state = (int) yy_def[yy_current_state];
      if (yy_current_state >= 298)
	yy_c = yy_meta[(unsigned int) yy_c];
    }
  yy_current_state = yy_nxt[yy_base[yy_current_state] + (unsigned int) yy_c];
  yy_is_jam = (yy_current_state == 297);

  return yy_is_jam ? 0 : yy_current_state;
}


#ifndef YY_NO_UNPUT
#ifdef YY_USE_PROTOS
static void yyunput (int c, register char *yy_bp)
#else
static void yyunput (c, yy_bp)
     int c;
     register char *yy_bp;
#endif
{
  register char *yy_cp = yy_c_buf_p;


  *yy_cp = yy_hold_char;

  if (yy_cp < yy_current_buffer->yy_ch_buf + 2)
    {

      register int number_to_move = yy_n_chars + 2;
      register char *dest = &yy_current_buffer->yy_ch_buf[yy_current_buffer->yy_buf_size + 2];
      register char *source = &yy_current_buffer->yy_ch_buf[number_to_move];

      while (source > yy_current_buffer->yy_ch_buf)
	*--dest = *--source;

      yy_cp += (int) (dest - source);
      yy_bp += (int) (dest - source);
      yy_current_buffer->yy_n_chars = yy_n_chars = yy_current_buffer->yy_buf_size;

      if (yy_cp < yy_current_buffer->yy_ch_buf + 2)
	YY_FATAL_ERROR ("flex scanner push-back overflow");
    }

  *--yy_cp = (char) c;


  yytext_ptr = yy_bp;
  yy_hold_char = *yy_cp;
  yy_c_buf_p = yy_cp;
}
#endif


#ifdef __cplusplus
static int yyinput ()
#else
static int input ()
#endif
{
  int c;

  *yy_c_buf_p = yy_hold_char;

  if (*yy_c_buf_p == YY_END_OF_BUFFER_CHAR)
    {

      if (yy_c_buf_p < &yy_current_buffer->yy_ch_buf[yy_n_chars])

	*yy_c_buf_p = '\0';

      else
	{
	  int offset = yy_c_buf_p - yytext_ptr;
	  ++yy_c_buf_p;

	  switch (yy_get_next_buffer ())
	    {
	    case EOB_ACT_LAST_MATCH:



	      yyrestart (yyin);



	    case EOB_ACT_END_OF_FILE:
	      {
		if (yywrap ())
		  return EOF;

		if (!yy_did_buffer_switch_on_eof)
		  YY_NEW_FILE;
#ifdef __cplusplus
		return yyinput ();
#else
		return input ();
#endif
	      }

	    case EOB_ACT_CONTINUE_SCAN:
	      yy_c_buf_p = yytext_ptr + offset;
	      break;
	    }
	}
    }

  c = *(unsigned char *) yy_c_buf_p;
  *yy_c_buf_p = '\0';
  yy_hold_char = *++yy_c_buf_p;


  return c;
}


#ifdef YY_USE_PROTOS
void yyrestart (FILE * input_file)
#else
void yyrestart (input_file)
     FILE *input_file;
#endif
{
  if (!yy_current_buffer)
    yy_current_buffer = yy_create_buffer (yyin, YY_BUF_SIZE);

  yy_init_buffer (yy_current_buffer, input_file);
  yy_load_buffer_state ();
}


#ifdef YY_USE_PROTOS
void yy_switch_to_buffer (YY_BUFFER_STATE new_buffer)
#else
void yy_switch_to_buffer (new_buffer)
     YY_BUFFER_STATE new_buffer;
#endif
{
  if (yy_current_buffer == new_buffer)
    return;

  if (yy_current_buffer)
    {

      *yy_c_buf_p = yy_hold_char;
      yy_current_buffer->yy_buf_pos = yy_c_buf_p;
      yy_current_buffer->yy_n_chars = yy_n_chars;
    }

  yy_current_buffer = new_buffer;
  yy_load_buffer_state ();


  yy_did_buffer_switch_on_eof = 1;
}


#ifdef YY_USE_PROTOS
void yy_load_buffer_state (void)
#else
void yy_load_buffer_state ()
#endif
{
  yy_n_chars = yy_current_buffer->yy_n_chars;
  yytext_ptr = yy_c_buf_p = yy_current_buffer->yy_buf_pos;
  yyin = yy_current_buffer->yy_input_file;
  yy_hold_char = *yy_c_buf_p;
}


#ifdef YY_USE_PROTOS
YY_BUFFER_STATE yy_create_buffer (FILE * file, int size)
#else
YY_BUFFER_STATE yy_create_buffer (file, size)
     FILE *file;
     int size;
#endif
{
  YY_BUFFER_STATE b;

  b = (YY_BUFFER_STATE) yy_flex_alloc (sizeof (struct yy_buffer_state));
  if (!b)
    YY_FATAL_ERROR ("out of dynamic memory in yy_create_buffer()");

  b->yy_buf_size = size;


  b->yy_ch_buf = (char *) yy_flex_alloc (b->yy_buf_size + 2);
  if (!b->yy_ch_buf)
    YY_FATAL_ERROR ("out of dynamic memory in yy_create_buffer()");

  b->yy_is_our_buffer = 1;

  yy_init_buffer (b, file);

  return b;
}


#ifdef YY_USE_PROTOS
void yy_delete_buffer (YY_BUFFER_STATE b)
#else
void yy_delete_buffer (b)
     YY_BUFFER_STATE b;
#endif
{
  if (!b)
    return;

  if (b == yy_current_buffer)
    yy_current_buffer = (YY_BUFFER_STATE) 0;

  if (b->yy_is_our_buffer)
    yy_flex_free ((void *) b->yy_ch_buf);

  yy_flex_free ((void *) b);
}


#ifndef YY_ALWAYS_INTERACTIVE
#ifndef YY_NEVER_INTERACTIVE
extern int isatty YY_PROTO ((int));
#endif
#endif

#ifdef YY_USE_PROTOS
void yy_init_buffer (YY_BUFFER_STATE b, FILE * file)
#else
void yy_init_buffer (b, file)
     YY_BUFFER_STATE b;
     FILE *file;
#endif


{
  yy_flush_buffer (b);

  b->yy_input_file = file;
  b->yy_fill_buffer = 1;

#if YY_ALWAYS_INTERACTIVE
  b->yy_is_interactive = 1;
#else
#if YY_NEVER_INTERACTIVE
  b->yy_is_interactive = 0;
#else
  b->yy_is_interactive = file ? (isatty (fileno (file)) > 0) : 0;
#endif
#endif
}


#ifdef YY_USE_PROTOS
void yy_flush_buffer (YY_BUFFER_STATE b)
#else
void yy_flush_buffer (b)
     YY_BUFFER_STATE b;
#endif

{
  if (!b)
    return;

  b->yy_n_chars = 0;


  b->yy_ch_buf[0] = YY_END_OF_BUFFER_CHAR;
  b->yy_ch_buf[1] = YY_END_OF_BUFFER_CHAR;

  b->yy_buf_pos = &b->yy_ch_buf[0];

  b->yy_at_bol = 1;
  b->yy_buffer_status = YY_BUFFER_NEW;

  if (b == yy_current_buffer)
    yy_load_buffer_state ();
}


#ifndef YY_NO_SCAN_BUFFER
#ifdef YY_USE_PROTOS
YY_BUFFER_STATE yy_scan_buffer (char *base, yy_size_t size)
#else
YY_BUFFER_STATE yy_scan_buffer (base, size)
     char *base;
     yy_size_t size;
#endif
{
  YY_BUFFER_STATE b;

  if (size < 2 || base[size - 2] != YY_END_OF_BUFFER_CHAR || base[size - 1] != YY_END_OF_BUFFER_CHAR)

    return 0;

  b = (YY_BUFFER_STATE) yy_flex_alloc (sizeof (struct yy_buffer_state));
  if (!b)
    YY_FATAL_ERROR ("out of dynamic memory in yy_scan_buffer()");

  b->yy_buf_size = size - 2;
  b->yy_buf_pos = b->yy_ch_buf = base;
  b->yy_is_our_buffer = 0;
  b->yy_input_file = 0;
  b->yy_n_chars = b->yy_buf_size;
  b->yy_is_interactive = 0;
  b->yy_at_bol = 1;
  b->yy_fill_buffer = 0;
  b->yy_buffer_status = YY_BUFFER_NEW;

  yy_switch_to_buffer (b);

  return b;
}
#endif


#ifndef YY_NO_SCAN_STRING
#ifdef YY_USE_PROTOS
YY_BUFFER_STATE yy_scan_string (yyconst char *yy_str)
#else
YY_BUFFER_STATE yy_scan_string (yy_str)
     yyconst char *yy_str;
#endif
{
  int len;
  for (len = 0; yy_str[len]; ++len)
    ;

  return yy_scan_bytes (yy_str, len);
}
#endif


#ifndef YY_NO_SCAN_BYTES
#ifdef YY_USE_PROTOS
YY_BUFFER_STATE yy_scan_bytes (yyconst char *bytes, int len)
#else
YY_BUFFER_STATE yy_scan_bytes (bytes, len)
     yyconst char *bytes;
     int len;
#endif
{
  YY_BUFFER_STATE b;
  char *buf;
  yy_size_t n;
  int i;


  n = len + 2;
  buf = (char *) yy_flex_alloc (n);
  if (!buf)
    YY_FATAL_ERROR ("out of dynamic memory in yy_scan_bytes()");

  for (i = 0; i < len; ++i)
    buf[i] = bytes[i];

  buf[len] = buf[len + 1] = YY_END_OF_BUFFER_CHAR;

  b = yy_scan_buffer (buf, n);
  if (!b)
    YY_FATAL_ERROR ("bad buffer in yy_scan_bytes()");


  b->yy_is_our_buffer = 1;

  return b;
}
#endif


#ifndef YY_NO_PUSH_STATE
#ifdef YY_USE_PROTOS
static void yy_push_state (int new_state)
#else
static void yy_push_state (new_state)
     int new_state;
#endif
{
  if (yy_start_stack_ptr >= yy_start_stack_depth)
    {
      yy_size_t new_size;

      yy_start_stack_depth += YY_START_STACK_INCR;
      new_size = yy_start_stack_depth * sizeof (int);

      if (!yy_start_stack)
	yy_start_stack = (int *) yy_flex_alloc (new_size);

      else
	yy_start_stack = (int *) yy_flex_realloc ((void *) yy_start_stack, new_size);

      if (!yy_start_stack)
	YY_FATAL_ERROR ("out of memory expanding start-condition stack");
    }

  yy_start_stack[yy_start_stack_ptr++] = YY_START;

  BEGIN (new_state);
}
#endif


#ifndef YY_NO_POP_STATE
static void yy_pop_state ()
{
  if (--yy_start_stack_ptr < 0)
    YY_FATAL_ERROR ("start-condition stack underflow");

  BEGIN (yy_start_stack[yy_start_stack_ptr]);
}
#endif


#ifndef YY_NO_TOP_STATE
static int yy_top_state ()
{
  return yy_start_stack[yy_start_stack_ptr - 1];
}
#endif

#ifndef YY_EXIT_FAILURE
#define YY_EXIT_FAILURE 2
#endif

#ifdef YY_USE_PROTOS
static void yy_fatal_error (yyconst char msg[])
#else
static void yy_fatal_error (msg)
     char msg[];
#endif
{
  (void) fprintf (stderr, "%s\n", msg);
  exit (YY_EXIT_FAILURE);
}





#undef yyless
#define yyless(n) \
	do \
		{ \
		 \
		yytext[yyleng] = yy_hold_char; \
		yy_c_buf_p = yytext + n; \
		yy_hold_char = *yy_c_buf_p; \
		*yy_c_buf_p = '\0'; \
		yyleng = n; \
		} \
	while ( 0 )




#ifndef yytext_ptr
#ifdef YY_USE_PROTOS
static void yy_flex_strncpy (char *s1, yyconst char *s2, int n)
#else
static void yy_flex_strncpy (s1, s2, n)
     char *s1;
     yyconst char *s2;
     int n;
#endif
{
  register int i;
  for (i = 0; i < n; ++i)
    s1[i] = s2[i];
}
#endif

#ifdef YY_NEED_STRLEN
#ifdef YY_USE_PROTOS
static int yy_flex_strlen (yyconst char *s)
#else
static int yy_flex_strlen (s)
     yyconst char *s;
#endif
{
  register int n;
  for (n = 0; s[n]; ++n)
    ;

  return n;
}
#endif


#ifdef YY_USE_PROTOS
static void *yy_flex_alloc (yy_size_t size)
#else
static void *yy_flex_alloc (size)
     yy_size_t size;
#endif
{
  return (void *) malloc (size);
}

#ifdef YY_USE_PROTOS
static void *yy_flex_realloc (void *ptr, yy_size_t size)
#else
static void *yy_flex_realloc (ptr, size)
     void *ptr;
     yy_size_t size;
#endif
{

  return (void *) realloc ((char *) ptr, size);
}

#ifdef YY_USE_PROTOS
static void yy_flex_free (void *ptr)
#else
static void yy_flex_free (ptr)
     void *ptr;
#endif
{
  free (ptr);
}

#if YY_MAIN
int main ()
{
  yylex ();
  return 0;
}
#endif
#line 363 "scan.l"






int yywrap ()
{
  if (!open_new_file ())
    return (1);
  return (0);
}
